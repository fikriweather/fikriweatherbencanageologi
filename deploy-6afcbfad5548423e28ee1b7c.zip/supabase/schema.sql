-- Fikri Weather: schema untuk akun, percakapan privat, pengumuman, notifikasi.
create extension if not exists pgcrypto;

create table if not exists public.users (
  id uuid primary key default gen_random_uuid(),
  username text not null unique check (username = lower(username)),
  password_hash text not null,
  disabled boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.sessions (
  token_hash text primary key,
  principal text not null,
  role text not null check (role in ('user','admin')),
  user_id uuid references public.users(id) on delete cascade,
  expires_at timestamptz not null,
  created_at timestamptz not null default now()
);
create index if not exists sessions_expiry_idx on public.sessions(expires_at);

create table if not exists public.user_preferences (
  user_id uuid primary key references public.users(id) on delete cascade,
  notification_settings jsonb not null default '{"rain":false,"quake":false,"forecast5h":false,"today":false,"tomorrow":false,"announcement":true,"admin_reply":true}'::jsonb,
  sound_settings jsonb not null default '{"enabled":true,"volume":0.65,"style":"chime","customDataUrl":""}'::jsonb,
  location jsonb,
  updated_at timestamptz not null default now()
);

-- Riwayat tanyafikricuaca bersifat privat dan hanya dapat dibaca melalui Netlify Function.
create table if not exists public.assistant_conversations (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.users(id) on delete cascade,
  title text not null default 'Percakapan cuaca' check (char_length(title) between 1 and 120),
  messages jsonb not null default '[]'::jsonb check (case when jsonb_typeof(messages) = 'array' then jsonb_array_length(messages) <= 20 else false end),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists assistant_conversations_user_idx on public.assistant_conversations(user_id, updated_at desc);

create table if not exists public.suggestions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.users(id) on delete cascade,
  category text not null,
  status text not null default 'new' check (status in ('new','waiting_admin','replied','closed')),
  created_at timestamptz not null default now()
);
create index if not exists suggestions_user_idx on public.suggestions(user_id, created_at desc);

create table if not exists public.suggestion_messages (
  id uuid primary key default gen_random_uuid(),
  suggestion_id uuid not null references public.suggestions(id) on delete cascade,
  sender_role text not null check (sender_role in ('user','admin')),
  sender_user_id uuid references public.users(id) on delete set null,
  message text not null check (length(message) between 1 and 4000),
  created_at timestamptz not null default now()
);
create index if not exists suggestion_messages_thread_idx on public.suggestion_messages(suggestion_id, created_at);

create table if not exists public.announcements (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  body text not null default '',
  pinned boolean not null default false,
  media jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index if not exists announcements_created_idx on public.announcements(created_at desc);

create table if not exists public.user_notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.users(id) on delete cascade,
  category text not null,
  title text not null,
  body text not null default '',
  url text not null default '/',
  created_at timestamptz not null default now(),
  read_at timestamptz
);
create index if not exists user_notifications_user_idx on public.user_notifications(user_id, created_at desc);

create table if not exists public.push_subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.users(id) on delete cascade,
  endpoint text not null unique,
  subscription jsonb not null,
  created_at timestamptz not null default now()
);

-- Langganan push perangkat admin terpisah dari akun pengguna biasa.
create table if not exists public.admin_push_subscriptions (
  id uuid primary key default gen_random_uuid(),
  endpoint text not null unique,
  subscription jsonb not null,
  created_at timestamptz not null default now()
);

create table if not exists public.admin_notifications (
  id uuid primary key default gen_random_uuid(),
  category text not null,
  title text not null,
  body text not null default '',
  url text not null default '/#developer',
  created_at timestamptz not null default now(),
  read_at timestamptz
);
create index if not exists admin_notifications_created_idx on public.admin_notifications(created_at desc);

create table if not exists public.user_notification_state (
  user_id uuid not null references public.users(id) on delete cascade,
  category text not null,
  state_key text not null,
  last_sent_at timestamptz not null default now(),
  primary key (user_id, category)
);

create table if not exists public.app_settings (
  setting_key text primary key,
  value jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

-- Seluruh akses melalui Netlify Functions menggunakan service-role key di server.
-- Jangan aktifkan akses anon/auth langsung ke tabel privat.
alter table public.users enable row level security;
alter table public.sessions enable row level security;
alter table public.user_preferences enable row level security;
alter table public.assistant_conversations enable row level security;
alter table public.suggestions enable row level security;
alter table public.suggestion_messages enable row level security;
alter table public.announcements enable row level security;
alter table public.user_notifications enable row level security;
alter table public.push_subscriptions enable row level security;
alter table public.admin_push_subscriptions enable row level security;
alter table public.admin_notifications enable row level security;
alter table public.app_settings enable row level security;
alter table public.user_notification_state enable row level security;

revoke all on public.users, public.sessions, public.user_preferences, public.assistant_conversations, public.suggestions,
  public.suggestion_messages, public.announcements, public.user_notifications,
  public.push_subscriptions, public.admin_push_subscriptions, public.admin_notifications, public.app_settings from anon, authenticated;

-- Bucket publik hanya untuk file media pengumuman/suara; bucket ini tidak menyimpan data akun.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('fw-media','fw-media',true,3145728,
  array['image/png','image/jpeg','image/webp','audio/mpeg','audio/ogg','audio/wav','audio/webm','audio/mp4','audio/aac'])
on conflict (id) do update set public = excluded.public, file_size_limit = excluded.file_size_limit,
  allowed_mime_types = excluded.allowed_mime_types;
