-- Run once in the Supabase SQL Editor for an existing Fikri Weather database.
create table if not exists public.assistant_conversations (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.users(id) on delete cascade,
  title text not null default 'Percakapan cuaca' check (char_length(title) between 1 and 120),
  messages jsonb not null default '[]'::jsonb check (case when jsonb_typeof(messages) = 'array' then jsonb_array_length(messages) <= 20 else false end),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists assistant_conversations_user_idx on public.assistant_conversations(user_id, updated_at desc);
alter table public.assistant_conversations enable row level security;
revoke all on public.assistant_conversations from anon, authenticated;
