import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { createRequire } from 'node:module';
import vm from 'node:vm';
import { resolve } from 'node:path';

const root = resolve(new URL('..', import.meta.url).pathname);
const require = createRequire(import.meta.url);
const api = require(resolve(root, 'netlify/functions/mountain-data.js'));
const t = api._test;

assert.equal(t.insideIndonesia(-7.5, 110.4), true);
assert.equal(t.insideIndonesia(30, 110), false);
assert.equal(t.timezoneForLongitude(100), 'Asia/Jakarta');
assert.equal(t.timezoneForLongitude(120), 'Asia/Makassar');
assert.equal(t.timezoneForLongitude(135), 'Asia/Jayapura');
assert.equal(t.timezoneForLongitude(127.5), 'Asia/Jayapura');
assert.equal(t.timezoneForRegion('Maluku Utara'), 'Asia/Jayapura');
assert.equal(t.timezoneForRegion('Papua Pegunungan'), 'Asia/Jayapura');
assert.equal(t.timezoneForRegion('Sulawesi Selatan'), 'Asia/Makassar');
assert.equal(t.timezoneForRegion('Nusa Tenggara Timur'), 'Asia/Makassar');
assert.equal(t.timezoneForRegion('Kalimantan Timur'), 'Asia/Makassar');
assert.equal(t.timezoneForRegion('Kalimantan Barat'), 'Asia/Jakarta');
assert.equal(t.offsetForTimezone('Asia/Jakarta'), '+07:00');
assert.equal(t.offsetForTimezone('Asia/Makassar'), '+08:00');
assert.equal(t.offsetForTimezone('Asia/Jayapura'), '+09:00');
const peak = t.mountainFromNominatim({
  lat: '-7.54', lon: '110.44', osm_type: 'node', osm_id: 99, name: 'Merapi',
  class: 'natural', type: 'peak', extratags: { natural: 'peak', ele: '2910' },
  address: { state: 'DI Yogyakarta' }, display_name: 'Merapi, DI Yogyakarta'
});
assert.equal(peak.name, 'Merapi');
assert.equal(peak.elevation, 2910);
assert.equal(t.elevationValue('2910 m'), 2910);
assert.equal(peak.isVolcano, false);
assert.equal(t.mountainFromNominatim({ lat: '-6.2', lon: '106.8', class: 'place', type: 'city', name: 'Jakarta' }), null);
const volcano = t.mountainFromOverpass({ type: 'node', id: 3, lat: -8.1, lon: 112.9, tags: { natural: 'volcano', name: 'Semeru', ele: '3676' } });
assert.equal(volcano.isVolcano, true);
const route = t.routeFromRelation({ id: 2, tags: { name: 'Jalur Pendakian', route: 'hiking' }, members: [{ type: 'way', geometry: [{ lat: -7.5, lon: 110.4 }, { lat: -7.49, lon: 110.41 }] }, { type: 'node', lat: -7.49, lon: 110.41, tags: { name: 'Pos 1', tourism: 'information' } }] });
assert.equal(route.name, 'Jalur Pendakian');
assert.equal(route.segments[0].length, 2);
assert.equal(route.waypoints[0].name, 'Pos 1');
const mappedTrail = t.routeFromWay({ id: 4, type: 'way', tags: { highway: 'path', sac_scale: 'mountain_hiking', name: 'Jejak Pos' }, geometry: [{ lat: -7.5, lon: 110.4 }, { lat: -7.49, lon: 110.41 }] });
assert.equal(mappedTrail.kind, 'Jejak jalur OSM (bukan relasi rute resmi)');
const denseLine = Array.from({ length: 1800 }, (_, i) => ({ lat: -7.5 + i * 0.00001, lon: 110.4 + Math.sin(i / 25) * 0.001 + i * 0.00001 }));
const simplifiedLine = t.normalizeGeometry(denseLine);
assert.ok(simplifiedLine.length <= 240, 'Geometri jalur harus disederhanakan untuk performa peta');
assert.deepEqual(simplifiedLine[0], denseLine[0], 'Penyederhanaan jalur harus mempertahankan titik awal');
assert.deepEqual(simplifiedLine.at(-1), denseLine.at(-1), 'Penyederhanaan jalur harus mempertahankan titik akhir');
const hour = t.hourlyAt({ elevation: 2500, timezone: 'Asia/Jakarta', hourly: { time: ['2026-11-16T06:00'], temperature_2m: [12], precipitation_probability: [85] } }, '2026-11-16', '06:00');
assert.equal(hour.hour.temperature_2m, 12);
assert.equal(hour.hour.precipitation_probability, 85);

const rainfallSeries = Array.from({ length: 80 }, (_, i) => i < 72 ? 2 : 9);
const rolling = t.hourlyAt({ timezone: 'Asia/Jakarta', hourly: { time: Array.from({ length: 80 }, (_, i) => { const d = new Date(Date.UTC(2026, 10, 16, i)); return `${d.getUTCFullYear()}-${String(d.getUTCMonth()+1).padStart(2,'0')}-${String(d.getUTCDate()).padStart(2,'0')}T${String(d.getUTCHours()).padStart(2,'0')}:00`; }), precipitation: rainfallSeries } }, '2026-11-16', '00:00');
assert.equal(rolling.hour.precipitation_24h, 48, '24-hour precipitation is summed at the selected coordinate/time');
assert.equal(rolling.hour.precipitation_6h, 12, '6-hour precipitation is summed at the selected coordinate/time');
assert.equal(rolling.hour.precipitation_72h, 144, '72-hour forecast accumulation is summed when all hours exist');
const landslide72 = t.estimateMountainRisk('landslide', null, { rain24hMm: 0, rain6hMm: 0, rain72hMm: 129, slopeDegrees: 30, topographicPositionM: 0, nearestWaterMeters: null, soilMoisture: 0.38 });
assert.equal(landslide72.status, 'SIAGA', '72-hour forecast accumulation above 128mm supports steep-slope screening');
assert.equal(landslide72.rainfall72hMm, 129, '72-hour rainfall is shown in the screening result');

const html = await readFile(resolve(root, 'index.html'), 'utf8');
const helper = html.match(/function displayWeatherCondition\(value,rainProbability=null\)\{[^}]*\}/);
assert.ok(helper, 'displayWeatherCondition helper not found');
const context = {};
vm.runInNewContext(`${helper[0]}; this.convert = displayWeatherCondition;`, context);
assert.equal(context.convert('Mendung', 78), 'Mendung');
assert.equal(context.convert('Mendung', 79), 'Hujan ringan');
assert.equal(context.convert('Mendung', 90), 'Hujan ringan');
assert.equal(context.convert('Hujan sedang', 99), 'Hujan sedang');
assert.equal(context.convert('Cerah berawan', 99), 'Cerah berawan');
assert.equal(context.convert('Gerimis', 78), 'Mendung');
assert.equal(context.convert('Gerimis', 79), 'Hujan ringan');

const runtime = html.match(/<script id="fw-mountain-runtime">([\s\S]*?)<\/script>/);
assert.ok(runtime, 'mountain runtime not found');
const labelFn = runtime[1].match(/function mountainCodeLabel\(code,prob\)\{[^}]*\}/);
const normFn = runtime[1].match(/function normalizeCondition\(value,prob\)\{[^}]*\}/);
assert.ok(labelFn && normFn, 'mountain condition functions not found');
const mctx = { num: value => value !== null && value !== undefined && value !== '' && Number.isFinite(Number(value)) ? Number(value) : null };
vm.runInNewContext(`${labelFn[0]};${normFn[0]};this.code=mountainCodeLabel;this.normalize=normalizeCondition;`, mctx);
assert.equal(mctx.code(51, 78), 'Mendung');
assert.equal(mctx.code(51, 79), 'Hujan ringan');
assert.equal(mctx.code(61, 50), 'Hujan ringan');
assert.equal(mctx.normalize('Mendung', 78), 'Mendung');
assert.equal(mctx.normalize('Mendung', 79), 'Hujan ringan');
assert.equal(mctx.normalize('Hujan lebat', 99), 'Hujan lebat');
assert.equal(mctx.normalize('Berawan', 99), 'Berawan');

for (const marker of ['id="mountain"', 'data-page="mountain"', 'fwMountainMap', 'action=search', 'action=routes', "action:'weather'", 'mountain-data']) assert.ok(html.includes(marker), `Missing mountain UI marker: ${marker}`);
console.log('PENGUJIAN CUACA GUNUNG & LABEL MENDUNG: LULUS');
console.log('✓ Validasi koordinat Indonesia dan hasil katalog gunung');
console.log('✓ Pemrosesan relasi jalur hiking dan titik bernama');
console.log('✓ Pembacaan cuaca per titik dan timestamp pilihan');
console.log('✓ Ambang >78% hanya mengubah label Mendung menjadi Hujan ringan');
console.log('✓ Label hujan/cerah berawan lain tidak berubah');
console.log('✓ Menu, peta, pencarian, rute, dan prakiraan tersedia pada halaman terpisah');
