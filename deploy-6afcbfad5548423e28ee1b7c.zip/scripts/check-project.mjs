import { readFile, readdir } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import { resolve, join } from 'node:path';
import vm from 'node:vm';

const root = resolve(new URL('..', import.meta.url).pathname);
const checks = [];
const fail = message => { throw new Error(message); };
const index = await readFile(join(root, 'index.html'), 'utf8');
const matches = [...index.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script\s*>/gi)];
let inlineCount = 0;
for (const match of matches) {
  const attrs = match[1] || '';
  const source = match[2] || '';
  if (/\bsrc\s*=/.test(attrs) || (/\btype\s*=\s*["'](?:application\/ld\+json|importmap|text\/template)/i.test(attrs))) continue;
  if (!source.trim()) continue;
  try { new vm.Script(source, { filename: `index.html:inline-${inlineCount + 1}` }); }
  catch (error) { fail(`JavaScript inline ${inlineCount + 1} tidak valid: ${error.message}`); }
  inlineCount++;
}
checks.push(`${inlineCount} blok JavaScript inline lolos pemeriksaan sintaks`);

const adminPattern = /\b(?:FW_ADMIN_ACCESS_CODE|ADMIN_ACCESS_CODE)\b/i;
if (adminPattern.test(index)) fail('Ada kode admin/penanda rahasia yang masih tertanam di HTML publik.');
checks.push('Tidak ditemukan konstanta kode admin di HTML publik');

for (const path of ['manifest.webmanifest', 'service-worker.js', 'netlify.toml', 'netlify/functions/admin-auth.js', 'netlify/functions/air-quality.js', 'netlify/functions/point-forecast.js', 'netlify/functions/hazard-risk.js', 'netlify/functions/terrain-data.js', 'netlify/functions/tourism-search.js', 'netlify/functions/mountain-data.js', 'netlify/functions/flight-route-forecast.js', 'netlify/functions/road-route-forecast.js', 'netlify/functions/route-addresses.js', 'supabase/schema.sql', 'scripts/build-android.mjs', 'android/settings.gradle', 'android/build.gradle', 'android/app/build.gradle', 'android/app/src/main/AndroidManifest.xml', 'android/app/src/main/java/id/co/fikriweather/app/MainActivity.java']) {
  if (!existsSync(join(root, path))) fail(`File wajib hilang: ${path}`);
}
checks.push('File PWA, backend, database, dan build Android tersedia');

const pkg = JSON.parse(await readFile(join(root, 'package.json'), 'utf8'));
if (!String(pkg.engines?.node || '').includes('22')) fail('Versi Node.js minimum belum disetel ke 22.');
const gradle = await readFile(join(root, 'android/app/build.gradle'), 'utf8');
if (!gradle.includes('compileSdk 36') || !gradle.includes('minSdk 24') || !gradle.includes('FW_SITE_URL')) fail('Konfigurasi Android SDK atau URL website tidak lengkap.');
if (!gradle.includes(`versionName '${pkg.version}'`)) fail('Versi Android tidak sama dengan versi source package.json.');
checks.push('Konfigurasi Android WebView dan versi runtime konsisten');

const fnRoot = join(root, 'netlify/functions');
async function walk(dir) {
  const entries = await readdir(dir, { withFileTypes: true });
  for (const entry of entries) {
    const path = join(dir, entry.name);
    if (entry.isDirectory()) await walk(path);
    else if (/\.(?:js|cjs|mjs)$/.test(entry.name)) {
      const code = await readFile(path, 'utf8');
      // Syntax check as an ECMAScript script; Node-specific globals are not executed.
      try { new vm.Script(code, { filename: path }); }
      catch (error) { fail(`Sintaks backend bermasalah pada ${path}: ${error.message}`); }
    }
  }
}
await walk(fnRoot);
checks.push('Sintaks seluruh fungsi backend Netlify lolos pemeriksaan');

console.log('PEMERIKSAAN PROYEK FIKRI WEATHER: LULUS');
for (const item of checks) console.log(`✓ ${item}`);
