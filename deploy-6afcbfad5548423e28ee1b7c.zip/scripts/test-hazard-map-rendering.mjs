import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import vm from 'node:vm';
import { resolve, join } from 'node:path';

const root = resolve(new URL('..', import.meta.url).pathname);
const html = await readFile(join(root, 'index.html'), 'utf8');
const scriptMatch = html.match(/<script id="fw-v5-public-official-map-runtime">([\s\S]*?)<\/script>/);
assert.ok(scriptMatch, 'Runtime peta bahaya resmi harus tersedia');
const runtime = scriptMatch[1];
new vm.Script(runtime, { filename: 'fw-v5-public-official-map-runtime.js' });

// Verify every requested national theme is connected to its official BNPB layer.
for (const [key, service] of Object.entries({
  volcano: 'INDEKS_BAHAYA_GUNUNGAPI',
  landslide: 'INDEKS_BAHAYA_TANAHLONGSOR',
  quake: 'INDEKS_BAHAYA_GEMPABUMI',
  tsunami: 'INDEKS_BAHAYA_TSUNAMI',
  flood: 'INDEKS_BAHAYA_BANJIR'
})) {
  assert.match(runtime, new RegExp(`${key}:indexLayer\\('${service}'`), `Layer ${key} harus terhubung ke layanan InaRISK ${service}`);
  assert.ok(html.includes(`data-fw-${key === 'volcano' || key === 'quake' || key === 'tsunami' ? 'mbg' : 'risk'}-layer="${key}"`) || (key === 'landslide' && html.includes('data-fw-mbg-layer="landslide"') && html.includes('data-fw-risk-layer="landslide"')), `Tombol ${key} harus ada`);
}
assert.match(runtime, /history:\{url:ROOT\+'DIBI_Provinsi_2015_2024_Hidromet\/MapServer',layers:\[1\],kind:'map'/, 'Layer sejarah DIBI 2015–2024 harus tetap dipakai sebagai MapServer');

// Validate the true raster classification. The renderer maps the source's 0–1
// index values to three categories and leaves unmatched/NoData cells transparent.
assert.match(runtime, /rasterFunction:'Remap'/);
assert.match(runtime, /InputRanges:\[0,0\.3330001,0\.3330001,0\.6660001,0\.6660001,1\.000001\]/);
assert.match(runtime, /OutputValues:\[1,2,3\]/);
assert.match(runtime, /AllowUnmatched:false/);
assert.match(runtime, /Colormap:\[\[1,44,162,95\],\[2,240,195,66\],\[3,222,81,72\]\]/, 'Ramp raster harus hijau–kuning–merah');
assert.match(runtime, /params\.renderingRule=JSON\.stringify\(spec\.renderingRule\)/, 'REST export harus mengirim renderer raster ke server BNPB');
assert.match(runtime, /renderingRule:spec\.renderingRule/, 'Fallback Esri Leaflet juga harus memakai renderer yang sama');
assert.match(runtime, /format:'png32',transparent:'true'/, 'Layer harus diekspor sebagai PNG transparan');
assert.match(html, /fwMbgMapLegend[\s\S]*?RENDAH[\s\S]*?SEDANG[\s\S]*?TINGGI/, 'Peta geologi harus memiliki legenda tiga kelas');
assert.match(html, /fw-map-legend i\.low\{background:#2ca25f\}\.fw-map-legend i\.medium\{background:#f0c342\}\.fw-map-legend i\.high\{background:#de5148\}/, 'Swatch legenda harus sama dengan warna raster');

// Check fast interactions and protection from stale/failed network responses.
assert.match(runtime, /const seq=\+\+requestSeq\[kind\]/, 'Setiap klik harus memiliki nomor permintaan');
assert.match(runtime, /candidate!==loaded/, 'Layer lama yang terlambat selesai tidak boleh mengganti pilihan terbaru');
assert.match(runtime, /candidate!==failed/, 'Kegagalan permintaan lama tidak boleh menghapus layer baru');
assert.match(runtime, /if\(previous&&previous!==loaded&&m\.hasLayer\(previous\)\)m\.removeLayer\(previous\)/, 'Layer sebelumnya baru diganti setelah layer baru berhasil dimuat');
assert.match(runtime, /setTimeout\(\(\)=>\{if\(isCurrent\(\)&&!complete&&candidate===direct\)addEsriFallback\(direct\)\},6500\)/, 'Fallback peta harus dipicu dengan batas waktu yang terukur');
assert.match(runtime, /setTimeout\(\(\)=>drawLayer\(kind,activeKeys\[kind\]\),350\)/, 'Perubahan tampilan peta harus di-debounce saat peta digeser/diperbesar');
assert.match(runtime, /Math\.min\(1400,Math\.round\(size\.x\|\|900\)\)/, 'Resolusi ekspor dibatasi agar tidak terlalu berat pada perangkat');
assert.match(runtime, /Math\.min\(900,Math\.round\(size\.y\|\|560\)\)/, 'Tinggi ekspor dibatasi agar tidak terlalu berat pada perangkat');
assert.match(runtime, /m\.hasLayer\(pendingOverlays\[kind\]\)/, 'Permintaan layer tertunda harus dapat dibatalkan saat tombol diklik cepat');

// Ensure the edit stayed inside the two requested map experiences.
assert.match(runtime, /data-fw-mbg-layer/);
assert.match(runtime, /data-fw-risk-layer/);
assert.match(runtime, /data-fw-map-reset/);
assert.match(html, /fwRiskMapLegend[\s\S]*?Area NoData transparan/);

console.log('PEMERIKSAAN PETA BENCANA: LULUS');
console.log('✓ Lima indeks bahaya nasional terhubung ke layer InaRISK yang benar');
console.log('✓ Renderer raster server-side hijau–kuning–merah dan NoData transparan');
console.log('✓ Peta geologi dan peta risiko memiliki legenda yang cocok');
console.log('✓ Klik cepat, fallback, dan pergantian layer terlindungi dari respons usang');
console.log('✓ Ekspor dibatasi untuk menjaga responsivitas perangkat');
