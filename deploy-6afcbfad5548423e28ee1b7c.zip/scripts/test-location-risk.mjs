import assert from 'node:assert/strict';
import vm from 'node:vm';
import { readFile } from 'node:fs/promises';
import hazardRisk from '../netlify/functions/hazard-risk.js';
import bmkgAlerts from '../netlify/functions/bmkg-alerts.js';
import terrainData from '../netlify/functions/terrain-data.js';

const html = await readFile(new URL('../index.html', import.meta.url), 'utf8');
const panelStart = html.indexOf('<article class="card fw-live-risk" id="fwLocationRisk"');
const panelEnd = html.indexOf('<article class="card" id="fwVolcanoProfiles"', panelStart);
assert.ok(panelStart >= 0 && panelEnd > panelStart, 'Panel analisis lokasi harus ada');
const panel = html.slice(panelStart, panelEnd);
assert.doesNotMatch(panel, /tsunami/i, 'Analisis lokasi hanya menampilkan banjir dan longsor; tsunami harus dihapus dari panel');
assert.doesNotMatch(panel, /fwTsunami(Level|Why)|data-fw-risk-layer="tsunami"/, 'Tidak boleh ada elemen atau layer risiko tsunami pada panel lokasi');
assert.match(panel, /id="fwFloodLevel"/);
assert.match(panel, /id="fwSlideLevel"/);
assert.match(panel, /fwRiskMapLegend/, 'Legenda layer risiko tetap tersedia');
assert.match(panel, /Legenda status titik · indeks InaRISK/i, 'Legenda titik menggunakan status hasil Fikri Weather');
assert.match(panel, /SIAGA · 0,667–1,000/, 'Kelas InaRISK atas diterjemahkan menjadi SIAGA pada legenda status titik');

// Location-analysis runtime must not depend on separate earthquake dashboard helpers.
const riskRuntimeStart = html.indexOf('function parseRiskIso(value)');
const riskRuntimeEnd = html.indexOf('function renderRiskResults(rows)', riskRuntimeStart);
assert.ok(riskRuntimeStart >= 0 && riskRuntimeEnd > riskRuntimeStart);
const riskRuntime = html.slice(riskRuntimeStart, riskRuntimeEnd);
assert.doesNotMatch(riskRuntime, /quakeTsunamiLabel|quakeFeltLabel|source=quake|fwTsunami/i, 'Analisis lokasi tidak boleh memanggil fungsi gempa atau tsunami');

// Guard against the regression that blocked the risk-analysis click path:
// all three helpers must be defined inside the same IIFE as analyze().
const utilityStart = html.indexOf('function validCoords(lat,lon)');
const utilityEnd = html.indexOf('const volcanoes=', utilityStart);
assert.ok(utilityStart >= 0 && utilityEnd > utilityStart, 'Helper validasi koordinat, label lokasi, dan pencocokan peringatan harus didefinisikan lokal');
const riskUtilities = html.slice(utilityStart, utilityEnd);
const fakeLocationNode = { textContent: '' };
const riskUtilityFns = vm.runInNewContext(`${riskUtilities}; ({validCoords,updatePvmbgSelectedLocation,activeWarningFor})`, {
  Number, String, Array,
  $: id => id === 'fwPvmbgSelectedLocation' ? fakeLocationNode : null
});
assert.equal(riskUtilityFns.validCoords(-7.75, 110.36), true, 'Koordinat valid Indonesia harus lolos pemeriksaan sebelum analisis');
assert.equal(riskUtilityFns.validCoords('abc', 110.36), false, 'Koordinat nonnumerik harus ditolak');
assert.equal(riskUtilityFns.validCoords(40, 110.36), false, 'Koordinat di luar wilayah Indonesia harus ditolak');
riskUtilityFns.updatePvmbgSelectedLocation(-7.75, 110.36, 'Wonosari');
assert.match(fakeLocationNode.textContent, /Wonosari.*-7\.75000, 110\.36000/, 'Informasi titik pilihan harus diperbarui tanpa error');
assert.equal(riskUtilityFns.activeWarningFor([{event:'Flood',headline:'Flash flood warning'}], 'flood')?.event, 'Flood');
assert.equal(riskUtilityFns.activeWarningFor([{event:'Landslide',headline:'Gerakan tanah'}], 'landslide')?.event, 'Landslide');
assert.equal(riskUtilityFns.activeWarningFor([{event:'Thunderstorm',headline:'Hujan lebat'}], 'flood'), null, 'Peringatan hujan umum tidak boleh salah dicap sebagai peringatan banjir');
assert.match(riskRuntime, /archive-api\.open-meteo\.com\/v1\/archive/);
assert.match(riskRuntime, /const wibToday=/, 'Tanggal WIB harus ditentukan dalam ruang lingkup analyze');
assert.match(riskRuntime, /const shiftDate=\(date,delta\)/, 'Helper rentang tanggal historis harus tersedia dalam ruang lingkup analyze');
assert.match(riskRuntime, /start_date=\$\{shiftDate\(wibToday,-7\)\}&end_date=\$\{shiftDate\(wibToday,-1\)\}/, 'Historical API harus menggunakan rentang tanggal');
assert.match(riskRuntime, /past_days=7&forecast_days=4/, 'Forecast API harus menyediakan fallback tujuh hari');
assert.match(riskRuntime, /terrain-data\?points=/, 'Elevasi harus memiliki fallback DEM');
assert.match(riskRuntime, /activeWarningFor\(warnings,'flood'\)/, 'Peringatan banjir harus dicocokkan oleh helper lokal');
assert.match(riskRuntime, /activeWarningFor\(warnings,'landslide'\)/, 'Peringatan longsor harus dicocokkan oleh helper lokal');
assert.match(riskRuntime, /dailyValuesForDates\(historyDaily,expected7Days\)/, 'Akumulasi tujuh hari menggunakan tanggal berurutan dan tidak mengisi hari kosong dengan nol');

assert.equal(riskRuntime.includes('riskAnalysisPending'), false, 'Lock analisis lama tidak boleh menolak analisis yang baru dipilih');
assert.match(riskRuntime, /riskAnalysisController\.abort\(\)/, 'Analisis lokasi baru harus membatalkan permintaan lokasi sebelumnya');
assert.match(riskRuntime, /riskAnalysisSequence/, 'Hanya hasil analisis dengan nomor permintaan terbaru boleh memperbarui panel');
assert.match(riskRuntime, /fetchRiskJson\(urls\[0\],7000,controller\.signal\)/, 'Prakiraan cuaca harus memiliki timeout dan pembatalan per analisis');
assert.match(riskRuntime, /BMKG CAP is supplementary to the numeric screen/, 'Feed peringatan BMKG tidak boleh menahan hasil angka utama');
assert.match(riskRuntime, /fetchRiskJson\(urls\[2\],4500,controller\.signal\)/, 'Sumber elevasi utama memiliki batas waktu yang ketat');
assert.match(riskRuntime, /fetchRiskJson\(terrainUrl,3500,controller\.signal\)/, 'Fallback elevasi hanya berjalan ketika data utama tidak lengkap dan memiliki batas waktu');
assert.match(riskRuntime, /terrain-data\?points=/, 'Fallback elevasi harus tetap tersedia saat layanan utama gagal');
assert.match(riskRuntime, /analyzeButton\.disabled=false/, 'Tombol analisis tetap bisa ditekan saat analisis otomatis awal sedang berjalan');

// Exercise the cancellable, per-source timeout helper used only by location-risk analysis.
const fetchRiskHelper = html.match(/async function fetchRiskJson\(url,timeoutMs,parentSignal\)\{[\s\S]*?\n \}/)?.[0];
assert.ok(fetchRiskHelper, 'Helper fetch risiko dengan timeout dan pembatalan harus tersedia');
let abortObserved = false;
const fetchRiskContext = {
  AbortController, setTimeout, clearTimeout, Error,
  fetch: (_url, options) => new Promise((resolve, reject) => {
    if (options.signal.aborted) { abortObserved = true; reject(new Error('aborted')); return; }
    options.signal.addEventListener('abort', () => { abortObserved = true; reject(new Error('aborted')); }, { once: true });
  })
};
const fetchRiskForTest = vm.runInNewContext(`${fetchRiskHelper}; fetchRiskJson`, fetchRiskContext);
const parentAbort = new AbortController();
const cancelledFetch = fetchRiskForTest('/slow', 1000, parentAbort.signal);
parentAbort.abort();
await assert.rejects(cancelledFetch, /aborted/, 'Permintaan sumber harus berhenti saat lokasi baru dipilih');
assert.equal(abortObserved, true, 'Sinyal pembatalan harus diteruskan ke fetch sumber');
let timeoutObserved = false;
const timeoutFetch = vm.runInNewContext(`${fetchRiskHelper}; fetchRiskJson`, {
  AbortController, setTimeout, clearTimeout, Error,
  fetch: (_url, options) => new Promise((resolve, reject) => options.signal.addEventListener('abort', () => { timeoutObserved = true; reject(new Error('timed out')); }, { once: true }))
});
await assert.rejects(timeoutFetch('/timeout', 5), /timed out/, 'Permintaan yang melewati batas waktu harus berhenti sendiri');
assert.equal(timeoutObserved, true, 'Timeout per sumber harus benar-benar membatalkan fetch');

const extract = (pattern, label) => { const m = html.match(pattern); assert.ok(m, `${label} harus ada`); return m[0]; };
const numeric = value => value === null || value === undefined || value === '' || !Number.isFinite(Number(value)) ? null : Number(value);
const helpersStart = html.indexOf('function riskLabelFromIndex(value)');
const helpersEnd = html.indexOf('async function analyze(lat,lon,placeName=', helpersStart);
assert.ok(helpersStart >= 0 && helpersEnd > helpersStart, 'Helper risiko dan estimasi harus tersedia');
const riskHelpers = html.slice(helpersStart, helpersEnd);
const fns = vm.runInNewContext(`${riskHelpers}; ({riskLabelFromIndex,terrainMetricsFromSamples,dailyValuesForDates,estimateHazard,hazardStatus})`, { num: numeric, Number, Math, Date, Intl });
const dryMetrics = { rain24: 0, rain72: 0, past3: 0, past7: 0, maxHourly: 0, elevation: 450, slope: 2, relief: 2, depression: -1, soil: 0.19, soilPercentile: 10 };
const wetRiskMetrics = { rain24: 125, rain72: 220, past3: 180, past7: 280, maxHourly: 28, elevation: 3, slope: 28, relief: 100, depression: 6, soil: 0.43, soilPercentile: 94 };
const papuaMountainMetrics = { rain24: 2, rain72: 8, past3: 20, pastMaxDaily: 8, past7: 25, maxHourly: 0.5, elevation: 2600, slope: 25, relief: 80, depression: 4, soil: 0.20, soilPercentile: 15 };
const moderateMountainMetrics = { rain24: 0, rain72: 0, past3: 0, pastMaxDaily: 0, past7: 0, maxHourly: 0, elevation: 1500, slope: 9, relief: 20, depression: 0, soil: 0.18, soilPercentile: 15 };
const medanFlatWetMetrics = { rain24: 90, rain72: 140, past3: 90, pastMaxDaily: 50, past7: 180, maxHourly: 18, elevation: 25, slope: 1.5, relief: 5, depression: 1, soil: 0.34, soilPercentile: 70 };
assert.equal(fns.estimateHazard('flood', dryMetrics).label, 'NORMAL', 'Lokasi datar/kering dengan hujan rendah tidak dipaksa menjadi bahaya');
assert.equal(fns.estimateHazard('landslide', dryMetrics).label, 'NORMAL');
const validDaily = {time:['2026-11-07','2026-11-08','2026-11-09','2026-11-10','2026-11-11','2026-11-12','2026-11-13'],precipitation_sum:[1,2,3,4,5,6,7]};
assert.deepEqual(Array.from(fns.dailyValuesForDates(validDaily,validDaily.time)),[1,2,3,4,5,6,7]);
const missingDaily = {time:validDaily.time,precipitation_sum:[1,2,null,4,5,6,7]};
assert.deepEqual(Array.from(fns.dailyValuesForDates(missingDaily,validDaily.time)),[1,2,null,4,5,6,7], 'Hari yang hilang tidak boleh diam-diam dianggap hujan nol');
assert.equal(fns.estimateHazard('landslide', papuaMountainMetrics).label, 'BERPOTENSI', 'Medan pegunungan dengan lereng dan relief terukur tidak boleh dianggap datar hanya karena hujan sedang rendah');
assert.equal(fns.estimateHazard('landslide', moderateMountainMetrics).label, 'BERPOTENSI', 'Lereng atau relief yang nyata minimal harus masuk BERPOTENSI meskipun prakiraan hujan rendah');
assert.equal(fns.estimateHazard('landslide', medanFlatWetMetrics).label, 'NORMAL', 'Titik datar di Medan tidak otomatis menjadi berpotensi longsor hanya karena hujan/kelembapan');
assert.equal(fns.estimateHazard('flood', wetRiskMetrics).label, 'SIAGA', 'Kombinasi hujan tinggi dan topografi rendah meningkatkan skrining banjir');
assert.equal(fns.estimateHazard('landslide', wetRiskMetrics).label, 'BAHAYA', 'Kombinasi hujan tinggi dan lereng curam meningkatkan skrining longsor');
const observedHeavyRainMetrics = { ...wetRiskMetrics, rain24: 1, rain72: 3, past3: 180, pastMaxDaily: 70, past7: 260 };
assert.equal(fns.estimateHazard('landslide', observedHeavyRainMetrics).rainTrigger, true, 'Pemicu longsor mengenali hujan historis harian dan akumulasi 3 hari yang sama-sama melewati ambang');
assert.equal(fns.estimateHazard('flood', {}).ok, false, 'Tanpa indikator cuaca dan topografi, model tidak membuat angka');
assert.equal(fns.hazardStatus(null, 'flood', {}, null, fns.estimateHazard('flood', wetRiskMetrics)).label, 'SIAGA', 'Jika raster gagal, status berasal dari estimasi mandiri yang memiliki indikator cukup');
assert.equal(fns.hazardStatus(0.2, 'flood', {}, null, fns.estimateHazard('flood', wetRiskMetrics)).label, 'SIAGA', 'Pemicu hujan sangat kuat dapat menaikkan status dinamis walau indeks dasar rendah');
assert.equal(fns.hazardStatus(0.5, 'flood', {}, null, null).label, 'BERPOTENSI');
assert.equal(fns.hazardStatus(0.8, 'landslide', {}, null, null).label, 'SIAGA', 'Kelas raster TINGGI diterjemahkan menjadi SIAGA; BAHAYA tidak otomatis dari kelas dasar');
assert.equal(fns.hazardStatus(0.8, 'landslide', {}, null, fns.estimateHazard('landslide', papuaMountainMetrics)).label, 'SIAGA', 'Kawasan pegunungan dan kelas dasar tinggi naik menjadi SIAGA tanpa hujan pemicu ekstrem');
assert.equal(fns.hazardStatus(0.8, 'landslide', {}, null, fns.estimateHazard('landslide', medanFlatWetMetrics)).label, 'SIAGA', 'Kelas InaRISK tepat di titik tetap dihormati meskipun estimasi DEM lokal datar');
assert.equal(fns.hazardStatus(0.1, 'landslide', {}, null, fns.estimateHazard('landslide', medanFlatWetMetrics)).label, 'NORMAL', 'Lokasi datar dengan kelas dasar rendah tidak dipaksa menjadi potensi longsor oleh hujan umum');
assert.equal(fns.hazardStatus(null, 'flood', {}, null, null).label, 'DATA TIDAK CUKUP', 'Tanpa raster dan indikator cukup tidak dibuat nilai palsu');
assert.equal(fns.hazardStatus(0.2, 'flood', {}, { severity: 'Extreme', headline: 'Peringatan banjir' }, null).label, 'BAHAYA', 'Peringatan resmi yang cocok mengungguli kelas dasar');

const rt = hazardRisk._test;
assert.deepEqual(Object.keys(rt.LAYERS).sort(), ['flood', 'landslide']);
assert.equal(rt.LAYERS.flood.name, 'INDEKS_BAHAYA_BANJIR');
assert.equal(rt.LAYERS.flood.rasterFunction, undefined, 'Layanan ini hanya mendeklarasikan raster function None; jangan kirim nama fungsi yang tidak tersedia');
assert.equal(rt.LAYERS.landslide.name, 'INDEKS_BAHAYA_TANAHLONGSOR');
assert.equal(rt.LAYERS.landslide.rasterFunction, undefined, 'Layer longsor menggunakan default mosaic pixel tanpa fungsi raster rekaan');
const projected = rt.toWorldMercator3395(3.19287, 98.50918);
assert.ok(Math.abs(projected.x - 10965991.756) < 1, 'Longitude Berastagi diproyeksikan ke EPSG:3395');
assert.ok(Math.abs(projected.y - 353234.604) < 1, 'Latitude Berastagi diproyeksikan ke EPSG:3395');
assert.equal(rt.extractIndex({ value: 0.42 }), 0.42);
assert.equal(rt.extractIndex({ value: '0.842', processedValues: ['0.000'] }), 0.842, 'Nilai mosaic hasil identify harus menjadi sumber utama');
assert.equal(rt.extractIndex({ value: '0.000', processedValues: ['0.842'] }), 0, 'Nilai mosaic 0 yang sah tidak boleh diganti oleh nilai alternatif');
assert.equal(rt.extractIndex({ value: 'NoData', processedValues: ['0.842'] }), null, 'NoData eksplisit pada nilai mosaic tidak boleh diganti oleh nilai alternatif');
assert.equal(rt.extractIndex({ value: '0.42', properties: { Values: ['0.91'] } }), 0.42, 'Nilai katalog sumber tidak boleh menimpa hasil mosaic');
assert.equal(rt.extractIndex({ pixelValues: '0.42' }), null, 'Pixel value tanpa output mosaic yang jelas tidak boleh dipakai');
assert.equal(rt.extractIndex({ processedValues: ['0.91'] }), 0.91, 'Nonstandard response hanya dipakai jika nilai mosaic tidak disediakan');
assert.equal(rt.extractIndex({ value: null, processedValues: null }), null, 'NoData tidak boleh diubah menjadi nol');
assert.equal(rt.level(0).status, 'NORMAL');
assert.equal(rt.level(0.333).status, 'NORMAL');
assert.equal(rt.level(0.334).status, 'BERPOTENSI');
assert.equal(rt.level(0.5).status, 'BERPOTENSI');
assert.equal(rt.level(0.666).status, 'BERPOTENSI');
assert.equal(rt.level(0.667).status, 'SIAGA');
assert.equal(rt.level(0.8).status, 'SIAGA');
assert.equal(rt.level(null).status, 'DATA BELUM TERSEDIA');
const exactPoint = rt.summarizeNeighborhood([0.84]);
assert.equal(exactPoint.value, 0.84, 'Satu sampel harus menjadi nilai piksel tepat titik pilihan');
assert.equal(exactPoint.centerValue, 0.84);
assert.equal(exactPoint.maxNearbyValue, null, 'Satu sampel tidak boleh diklaim mewakili piksel sekitar');
assert.equal(exactPoint.sampleCount, 1);
const area = rt.summarizeNeighborhood([0.05, 0.82, 0.70, 0.78, 0.00, 0.79, null, 0.75, 0.80]);
assert.equal(area.value, 0, 'Indeks utama harus sama dengan piksel tepat di koordinat terpilih');
assert.equal(area.centerValue, 0, 'Nilai piksel pusat tetap menjadi indeks utama');
assert.equal(area.maxNearbyValue, 0.82, 'Nilai tertinggi sekitar ditampilkan sebagai konteks, bukan mengganti piksel titik');
assert.equal(area.sampleCount, 8);
assert.equal(fns.hazardStatus(area.value, 'landslide', area, null, null).label, 'NORMAL', 'Status resmi harus mengikuti nilai piksel tepat di titik, bukan mengganti titik dengan sel tetangga');
assert.equal(fns.hazardStatus(0, 'flood', { centerValue: 0, maxNearbyValue: 0.84, sampleCount: 9 }, null, null).label, 'NORMAL', 'Nilai sel tetangga tidak boleh menggantikan hasil piksel tepat pada titik pilihan');

// Check local terrain from a 3x3 DEM grid. Flat plains must remain flat;
// a rising surface must produce measurable slope and relief.
const flatTerrain = fns.terrainMetricsFromSamples(Array(9).fill(24), 3.6, 0.001);
assert.equal(flatTerrain.elevation, 24);
assert.ok(flatTerrain.slope < 0.01, 'DEM datar tidak boleh menghasilkan lereng semu');
assert.equal(flatTerrain.relief, 0, 'Relief pada grid datar harus nol');
const risingDem = [100,120,140,110,130,150,120,140,160];
const mountainTerrain = fns.terrainMetricsFromSamples(risingDem, -4.1, 0.001);
assert.ok(mountainTerrain.slope > 5, 'Perubahan elevasi terarah harus terbaca sebagai lereng');
assert.equal(mountainTerrain.elevation, 130, 'Elevasi tetap diambil dari sampel pusat yang sesuai koordinat pilihan');
assert.equal(mountainTerrain.relief, 60, 'Relief lokal dihitung dari sembilan sampel DEM');

// Verify the real identify request uses the native InaRISK projection and 100 m pixel.
const originalFetch = globalThis.fetch;
let identifyUrl = '';
globalThis.fetch = async input => {
  identifyUrl = String(input);
  return { ok: true, status: 200, json: async () => ({ value: '0.456', processedValues: ['0.000'] }) };
};
try {
  assert.equal(await rt.identify(rt.LAYERS.flood, 3.19287, 98.50918), 0.456);
  const request = new URL(identifyUrl);
  assert.equal(request.searchParams.get('sr'), '3395');
  assert.equal(JSON.parse(request.searchParams.get('geometry')).spatialReference.wkid, 3395);
  assert.equal(JSON.parse(request.searchParams.get('pixelSize')).x, 100);
  assert.equal(request.searchParams.has('renderingRule'), false, 'Identify harus memakai default image mosaic karena metadata raster hanya mengiklankan None');
  assert.equal(request.searchParams.get('returnPixelValues'), 'false', 'Identify harus membaca nilai mosaic, bukan nilai masing-masing sumber katalog');
  let pointCalls = 0;
  globalThis.fetch = async input => { pointCalls++; identifyUrl = String(input); return { ok:true, status:200, json:async()=>({value:'0.842'}) }; };
  const exactRaster = await rt.identifyNeighborhood(rt.LAYERS.flood, 3.19287, 98.50918);
  assert.equal(exactRaster.value, 0.842);
  assert.equal(exactRaster.sampleCount, 1);
  assert.equal(exactRaster.sampleRadiusM, 0);
  assert.equal(pointCalls, 1, 'Satu jenis bahaya hanya membutuhkan satu permintaan raster untuk titik yang dipilih');
} finally {
  globalThis.fetch = originalFetch;
}

const bt = bmkgAlerts._test;
assert.equal(bt.validRss('<rss version="2.0"><channel><title>BMKG</title></channel></rss>'), true);
assert.equal(bt.validRss('<html><body>temporary error</body></html>'), false);
assert.equal(bt.rssItems('<rss><channel><item><title>Alert</title></item></channel></rss>').length, 1);
assert.equal(bt.emptyFeedResult('Berastagi', 3.19, 98.50).matchStatus, 'no_active_warnings');
assert.equal(terrainData._test.validPoint({ lat: 3.19287, lon: 98.50918 }), true);
assert.equal(terrainData._test.validPoint({ lat: 55, lon: 98.5 }), false);

console.log('TES REGRESI RISIKO LOKASI FIKRI WEATHER: LULUS');
console.log('✓ Panel analisis hanya berisi banjir dan longsor, tanpa tsunami');
console.log('✓ Tidak ada dependensi fungsi tsunami/gempa dalam analisis lokasi');
console.log('✓ Histori Open-Meteo memakai rentang tanggal yang valid dan fallback 7 hari');
console.log('✓ Estimasi mandiri memakai indikator lokasi; Medan datar dan Papua pegunungan dibedakan oleh DEM setempat');
console.log('✓ Status raster TINGGI menjadi SIAGA; BAHAYA memerlukan pemicu hujan berat atau peringatan resmi');
console.log('✓ Kemiringan dan relief dihitung dari kisi DEM 3×3 berpusat pada titik pilihan, dengan jarak sampel sekitar 100 m');
console.log('✓ Akumulasi hujan historis memakai hari berurutan; hari kosong tetap tidak tersedia, bukan nol');
console.log('✓ Nilai mosaic Identify diprioritaskan; titik yang dipilih dibaca langsung tanpa mengganti nilai dengan piksel sekitar');
console.log('✓ InaRISK memakai dua layer renderer resmi dan hanya dua permintaan tepat titik (satu per layer)');
console.log('✓ BMKG RSS kosong yang valid dibedakan dari feed rusak');
console.log('✓ Fallback elevasi memvalidasi koordinat Indonesia');
