import assert from 'node:assert/strict';
import vm from 'node:vm';
import { createRequire } from 'node:module';
import { readFile } from 'node:fs/promises';

const require = createRequire(import.meta.url);
const air = require('../netlify/functions/air-quality.js');
const hazard = require('../netlify/functions/hazard-risk.js');
const point = require('../netlify/functions/point-forecast.js');
const tourism = require('../netlify/functions/tourism-search.js');
const publicData = require('../netlify/functions/public-data.js');
const flight = require('../netlify/functions/flight-route-forecast.js');
const road = require('../netlify/functions/road-route-forecast.js');
assert.equal(road._test.weatherTextFromCode(51), 'Mendung', 'Fallback kode cuaca rute harus menampilkan Mendung');
const drizzleBmkg = road._test.parseBmkg({ data: [{ cuaca: [[{ utc_datetime: '2026-11-14 09:00:00', weather_desc: 'Gerimis', t: 28, hu: 85, ws: 4 }]] }] });
assert.equal(drizzleBmkg[0].condition, 'Mendung', 'Deskripsi Gerimis BMKG pada rute harus ditampilkan sebagai Mendung');
assert.equal(drizzleBmkg[0].conditionRaw, 'Gerimis', 'Deskripsi mentah tetap disimpan untuk evaluasi internal');
const routeAddresses = require('../netlify/functions/route-addresses.js');
const event = queryStringParameters => ({ queryStringParameters: queryStringParameters || {} });
const post = points => ({ httpMethod: 'POST', body: JSON.stringify({ points }) });

// Flight route forecast validation and multi-model aggregation.
const flightMissing = await flight.handler(post([]));
assert.equal(flightMissing.statusCode, 400, 'Rute penerbangan harus memiliki minimal dua titik');
const flightOutside = await flight.handler(post([
  { id: 'P1', lat: 40, lon: 110, eta: new Date(Date.now() + 3600000).toISOString() },
  { id: 'P2', lat: -6, lon: 106, eta: new Date(Date.now() + 7200000).toISOString() }
]));
assert.equal(flightOutside.statusCode, 400, 'Titik rute penerbangan harus berada di cakupan Indonesia');
const flightBadEta = await flight.handler(post([
  { id: 'P1', lat: -6, lon: 106, eta: 'bukan-waktu' },
  { id: 'P2', lat: -7, lon: 110, eta: new Date(Date.now() + 7200000).toISOString() }
]));
assert.equal(flightBadEta.statusCode, 400, 'ETA penerbangan yang tidak valid harus ditolak');

const airBad = await air.handler(event({ lat: 'invalid', lon: '110.36' }));
assert.equal(airBad.statusCode, 400, 'Air quality harus menolak koordinat tidak valid');

const hazardBad = await hazard.handler(event({ lat: '40', lon: '110' }));
assert.equal(hazardBad.statusCode, 400, 'Analisis InaRISK harus menolak lokasi di luar Indonesia');
const hazardFns = hazard._test;
assert.equal(hazardFns.level(0.2).status, 'NORMAL', 'Indeks rendah InaRISK menjadi NORMAL');
assert.equal(hazardFns.level(0.5).status, 'BERPOTENSI', 'Indeks sedang InaRISK menjadi BERPOTENSI');
assert.equal(hazardFns.level(0.8).status, 'SIAGA', 'Indeks tinggi InaRISK menjadi status SIAGA, bukan BAHAYA otomatis');
assert.equal(hazardFns.level(null).status, 'DATA BELUM TERSEDIA', 'Indeks kosong tidak boleh dianggap NORMAL');
assert.equal(hazardFns.extractIndex({ value: '0.735' }), 0.735, 'Nilai pixel raster harus dapat dibaca');
const hazardOriginalFetch = global.fetch;
try {
  let hazardFetchCount = 0;
  const center = hazardFns.toWorldMercator3395(-8.00123, 110.35123);
  global.fetch = async url => {
    hazardFetchCount++;
    const text = String(url);
    const name = text.includes('/INDEKS_BAHAYA_BANJIR/') ? 'flood' : 'landslide';
    const point = JSON.parse(new URL(text).searchParams.get('geometry'));
    const isCenter = Math.abs(point.x - center.x) < 1 && Math.abs(point.y - center.y) < 1;
    // The Identify `value` is the requested renderer's mosaic pixel. Test the center independently from nearby high cells.
    const mosaicValue = name === 'flood' ? '0.2' : (isCenter ? '0.000' : '0.790');
    return { ok: true, status: 200, json: async () => ({ value: mosaicValue, processedValues: ['0.999'] }) };
  };
  const hazardGood = await hazard.handler(event({ lat: '-8.00123', lon: '110.35123' }));
  const hazardBody = JSON.parse(hazardGood.body);
  assert.equal(hazardGood.statusCode, 200, 'Endpoint InaRISK harus mengembalikan data saat pixel tersedia');
  assert.equal(hazardBody.hazards.flood.status, 'NORMAL');
  assert.equal(hazardBody.hazards.landslide.status, 'NORMAL');
  assert.equal(hazardBody.hazards.landslide.value, 0, 'Indeks utama mengikuti piksel tepat di koordinat terpilih');
  assert.equal(hazardBody.hazards.landslide.centerValue, 0, 'Nilai pusat harus sama dengan nilai utama');
  assert.equal(hazardBody.hazards.landslide.maxNearbyValue, null, 'Endpoint titik tidak mencampurkan piksel tetangga');
  assert.equal(hazardBody.hazards.landslide.sampleCount, 1, 'Satu piksel tepat pada titik dipakai untuk setiap layer');
  assert.equal(hazardBody.hazards.tsunami, undefined, 'Endpoint lokasi hanya mengambil indeks banjir dan longsor');
  assert.equal(hazardFetchCount, 2, 'Endpoint hanya meminta satu piksel untuk banjir dan satu untuk longsor');
  const hazardCache = await hazard.handler(event({ lat: '-8.00123', lon: '110.35123' }));
  assert.equal(JSON.parse(hazardCache.body).availableCount, 2);
  assert.equal(hazardFetchCount, 2, 'Cache lokasi harus mencegah permintaan raster berulang');

  // Missing mosaic output must stay unavailable; an alternative/candidate value is not a substitute.
  global.fetch = async () => {
    hazardFetchCount++;
    return { ok: true, status: 200, json: async () => ({ value: 'NoData', processedValues: ['0.900'] }) };
  };
  const hazardUnavailable = await hazard.handler(event({ lat: '-8.00135', lon: '110.35135' }));
  const unavailableBody = JSON.parse(hazardUnavailable.body);
  assert.equal(unavailableBody.availableCount, 0, 'Semua raster NoData harus ditandai tidak tersedia');
  assert.equal(unavailableBody.hazards.flood.status, 'DATA BELUM TERSEDIA');
  assert.equal(unavailableBody.hazards.landslide.status, 'DATA BELUM TERSEDIA');
} finally { global.fetch = hazardOriginalFetch; }

const pointMissing = await point.handler(event({}));
assert.equal(pointMissing.statusCode, 400, 'Prakiraan destinasi harus menolak koordinat kosong');
const pointOutside = await point.handler(event({ lat: '40', lon: '110', date: '2026-11-13', time: '09:00' }));
assert.equal(pointOutside.statusCode, 400, 'Prakiraan destinasi membatasi koordinat ke Indonesia');
const pointInvalidTime = await point.handler(event({ lat: '-7.8', lon: '110.3', date: '2026-11-13', time: '09:30' }));
assert.equal(pointInvalidTime.statusCode, 400, 'Prakiraan destinasi harus menolak jam bukan awal jam');

const tourismEmpty = await tourism.handler(event({ q: ' ' }));
assert.equal(tourismEmpty.statusCode, 400, 'Pencarian wisata harus meminta kata pencarian');

// Exercise the actual BMKG coordinate parser used by earthquake markers.
const html = await readFile(new URL('../index.html', import.meta.url), 'utf8');
const coordSource = html.match(/function parseCoord\(value\)\{[\s\S]*?\n\}/)?.[0];
assert.ok(coordSource, 'Parser koordinat gempa harus tersedia');
const parseCoord = vm.runInNewContext(`${coordSource}; parseCoord`);
assert.equal(parseCoord('7.25 LS'), -7.25, 'LS harus menjadi lintang negatif');
assert.equal(parseCoord('6,5 LU'), 6.5, 'LU harus menjadi lintang positif dan koma desimal didukung');
assert.equal(parseCoord('110.37 BT'), 110.37, 'BT harus menjadi bujur positif');
assert.equal(parseCoord('95.2 BB'), -95.2, 'BB harus menjadi bujur negatif');
assert.equal(parseCoord("7° 30' 0\" LS"), -7.5, 'Koordinat derajat-menit-detik harus diproses');
assert.equal(parseCoord('-7.25'), -7.25, 'Koordinat desimal bertanda harus dipertahankan');
assert.ok(Number.isNaN(parseCoord('koordinat tidak tersedia')), 'Teks bukan koordinat tidak boleh diubah menjadi angka');
const numericHelperSource = html.match(/const num=value=>value===null\|\|value===undefined\|\|value===''\|\|!Number\.isFinite\(Number\(value\)\)\?null:Number\(value\);/)?.[0];
assert.ok(numericHelperSource, 'Helper num harus berada di scope dashboard cuaca utama, bukan hanya modul terpisah');
const safeNum = vm.runInNewContext(`${numericHelperSource}; num`);
assert.equal(safeNum(null), null, 'Nilai null tidak boleh diubah menjadi nol');
const displayConditionSource = html.match(/function displayWeatherCondition\(value,rainProbability=null\)\{[^\n]*\}/)?.[0];
const wmoMainSource = html.match(/function wmo\(code\)\{[^\n]*\}/)?.[0];
const iconMainSource = html.match(/function weatherIcon\(code,desc=''{1}\)\{[^\n]*\}/)?.[0];
assert.ok(displayConditionSource && wmoMainSource && iconMainSource, 'Pemetaan label kondisi cuaca harus tersedia');
const displayFns = vm.runInNewContext(`${displayConditionSource}; ${wmoMainSource}; ${iconMainSource}; ({displayWeatherCondition,wmo,weatherIcon})`);
for (const code of [51,53,55,56,57]) {
  assert.equal(displayFns.wmo(code), 'Mendung', `Kode WMO ${code} harus tampil sebagai Mendung`);
  assert.equal(displayFns.weatherIcon(code, 'Mendung'), '☁️', `Kode WMO ${code} harus memakai ikon awan`);
}
assert.equal(displayFns.displayWeatherCondition('Gerimis ringan'), 'Mendung', 'Label sumber Gerimis harus ditampilkan sebagai Mendung');
assert.equal(displayFns.displayWeatherCondition('Hujan ringan', 99), 'Hujan ringan', 'Label hujan ringan tidak boleh ikut diubah');
assert.equal(displayFns.displayWeatherCondition('Mendung', 78), 'Mendung', 'Ambang harus lebih dari 78%, bukan sama dengan 78%');
assert.equal(displayFns.displayWeatherCondition('Mendung', 79), 'Hujan ringan', 'Mendung dengan peluang hujan di atas 78% harus menjadi Hujan ringan');
assert.equal(displayFns.displayWeatherCondition('Hujan lebat', 99), 'Hujan lebat', 'Label hujan yang sudah ada tidak boleh ditimpa peluang hujan');
assert.equal(displayFns.displayWeatherCondition('Cerah berawan', 99), 'Cerah berawan', 'Label non-mendung tidak boleh diubah oleh peluang hujan');
const rainIconSource = html.match(/const rainIcon=code=>\{[^\n]*\}/)?.[0];
assert.ok(rainIconSource, 'Ikon kondisi jemuran harus tersedia');
const rainIcon = vm.runInNewContext(`${rainIconSource}; rainIcon`);
for (const code of [51,53,55,56,57]) assert.equal(rainIcon(code), '☁️', `Kode WMO ${code} pada jemuran harus memakai ikon mendung`);
assert.equal(safeNum('28.5'), 28.5, 'Helper numerik harus mengonversi data API ke angka');

// Check route samples preserve both endpoints and chronological distance order.
const kmSource = html.match(/function km\(a,b\)\{[^\n]*\}/)?.[0];
const sampleSource = html.match(/function sampleRoutePoints\(coords,count\)\{[\s\S]*?\n\}/)?.[0];
assert.ok(kmSource && sampleSource, 'Fungsi sampel rute harus tersedia');
const sampleRoutePoints = vm.runInNewContext(`${kmSource}\n${sampleSource}; sampleRoutePoints`);
const routePoints = [[-7.80, 110.30], [-7.79, 110.31], [-7.78, 110.32], [-7.77, 110.33]];
const samples = sampleRoutePoints(routePoints, 4);
assert.deepEqual(Array.from(samples[0].p), routePoints[0], 'Sampel pertama harus sama dengan titik berangkat');
assert.deepEqual(Array.from(samples.at(-1).p), routePoints.at(-1), 'Sampel terakhir harus mempertahankan titik tujuan');
assert.ok(samples.every((x, i) => i === 0 || x.fraction >= samples[i - 1].fraction), 'Fraksi jarak sampel rute harus berurutan');
assert.ok(samples.length <= 48, 'Jumlah sampel cuaca rute harus tetap dibatasi untuk perangkat Android');
const denseSamples = sampleRoutePoints(routePoints, 24);
assert.equal(denseSamples.length, 24, 'Rute panjang harus dapat menampilkan hingga puluhan titik cuaca');
assert.ok(denseSamples.every((x, i) => i === 0 || x.distanceKm > denseSamples[i - 1].distanceKm), 'Jarak titik cuaca harus meningkat secara konsisten');
assert.ok(denseSamples.some((x, i) => i > 0 && i < denseSamples.length - 1 && x.p[0] !== routePoints[0][0]), 'Sampel harus diinterpolasi sepanjang bentuk polyline, bukan hanya mengambil vertex asli');

// Mock BMKG feeds to verify the Netlify proxy normalizes all three public feeds.
const originalFetch = global.fetch;
try {
  const eta1 = Math.ceil((Date.now() + 2 * 3600000) / 3600000) * 3600000;
  const eta2 = eta1 + 3600000;
  const routePoints = [
    { id: 'P1', lat: -6.1256, lon: 106.6559, eta: new Date(eta1).toISOString() },
    { id: 'P2', lat: -7.9053, lon: 110.0574, eta: new Date(eta2).toISOString() }
  ];
  let flightFetchCount = 0;
  global.fetch = async url => {
    flightFetchCount++;
    const params = new URL(String(url)).searchParams;
    const model = params.get('models') || 'best';
    const probability = model === 'ecmwf_ifs025' ? 40 : model === 'gfs_seamless' ? 50 : 30;
    const hourlyFor = eta => ({
      time: [new Date(Math.floor(eta / 3600000) * 3600000).toISOString().slice(0, 16)],
      temperature_2m: [28], relative_humidity_2m: [82], precipitation_probability: [probability],
      precipitation: [0.2], weather_code: [61], wind_speed_10m: [9], wind_direction_10m: [270],
      wind_gusts_10m: [14], visibility: [8000], cloud_cover: [85], pressure_msl: [1008], cape: [120]
    });
    const latCount = String(params.get('latitude') || '').split(',').length;
    const raw = routePoints.slice(0, latCount).map(p => ({ hourly: hourlyFor(Date.parse(p.eta)) }));
    return { ok: true, status: 200, json: async () => raw };
  };
  const flightGood = await flight.handler(post(routePoints));
  assert.equal(flightGood.statusCode, 200, 'Prakiraan rute harus berhasil saat sumber model tersedia');
  const flightBody = JSON.parse(flightGood.body);
  assert.equal(flightBody.points.length, 2, 'Semua titik rute harus dipertahankan');
  assert.equal(flightBody.points[0].precipitation_probability_pct, 40, 'Peluang hujan harus dihitung dari rata-rata model yang tersedia');
  assert.deepEqual(flightBody.meta.models_used.sort(), ['Best Match', 'ECMWF IFS', 'NCEP GFS'].sort(), 'Sumber multi-model harus dicantumkan');
  assert.equal(flightBody.points[1].temperature_c, 28, 'Variabel suhu titik tujuan harus dipetakan');
  const countAfterSuccess = flightFetchCount;
  const flightCached = await flight.handler(post(routePoints));
  assert.equal(JSON.parse(flightCached.body).meta.cache, 'hit', 'Respons rute yang identik harus memakai cache singkat');
  assert.equal(flightFetchCount, countAfterSuccess, 'Cache harus mengurangi permintaan API yang berulang');

  // Per-field fallback: Best Match may omit a field while ECMWF/GFS still provide it.
  const fieldFallbackPoints = [
    { id: 'F1', lat: -6.2, lon: 106.8, eta: new Date(Date.now() + 6 * 3600000).toISOString() },
    { id: 'F2', lat: -7.1, lon: 110.4, eta: new Date(Date.now() + 7 * 3600000).toISOString() }
  ];
  let bestMatchParameterWasOmitted = false;
  global.fetch = async url => {
    const params = new URL(String(url)).searchParams;
    if (!params.has('models')) bestMatchParameterWasOmitted = true;
    const model = params.get('models') || 'best';
    const latCount = String(params.get('latitude') || '').split(',').length;
    const raw = fieldFallbackPoints.slice(0, latCount).map(point => {
      const t = new Date(Math.floor(Date.parse(point.eta) / 3600000) * 3600000).toISOString().slice(0, 16);
      return { hourly: { time: [t], temperature_2m: [model === 'best' ? null : 29], relative_humidity_2m: [80], precipitation_probability: [25], precipitation: [0], weather_code: [model === 'best' ? null : 1], wind_speed_10m: [8], wind_direction_10m: [270], wind_gusts_10m: [12], visibility: [9000], cloud_cover: [20], pressure_msl: [1010], cape: [0] } };
    });
    return { ok: true, status: 200, json: async () => raw };
  };
  const flightFieldFallback = await flight.handler(post(fieldFallbackPoints));
  const fallbackPoint = JSON.parse(flightFieldFallback.body).points[0];
  assert.equal(fallbackPoint.temperature_c, 29, 'Field kosong pada Best Match harus diisi dari model berikutnya yang tersedia');
  assert.equal(fallbackPoint.field_sources.temperature, 'ECMWF IFS', 'Sumber nilai pelengkap per field harus dicatat');
  assert.ok(bestMatchParameterWasOmitted, 'Best Match harus dipanggil tanpa query models=null');

  global.fetch = async () => ({ ok: false, status: 503, json: async () => ({}) });
  const flightUnavailable = await flight.handler(post([
    { id: 'FAIL1', lat: -3, lon: 100, eta: new Date(Date.now() + 4 * 3600000).toISOString() },
    { id: 'FAIL2', lat: -4, lon: 101, eta: new Date(Date.now() + 5 * 3600000).toISOString() }
  ]));
  assert.equal(flightUnavailable.statusCode, 502, 'Jika semua model gagal, backend harus menyatakan data tidak tersedia');
  assert.equal(JSON.parse(flightUnavailable.body).ok, false, 'Kegagalan model tidak boleh diubah menjadi data cuaca buatan');

  // Road trip route forecast: dense multi-coordinate points, per-field fallback and BMKG priority.
  const roadMissing = await road.handler(post([]));
  assert.equal(roadMissing.statusCode, 400, 'Analisis rute darat harus menolak daftar titik kosong');
  const roadOutside = await road.handler(post([
    { id: 'R1', lat: 30, lon: 110, eta: new Date(Date.now() + 3600000).toISOString() },
    { id: 'R2', lat: -7, lon: 110, eta: new Date(Date.now() + 7200000).toISOString() }
  ]));
  assert.equal(roadOutside.statusCode, 400, 'Titik rute darat harus berada di wilayah Indonesia');
  const roadTooMany = await road.handler(post(Array.from({ length: 49 }, (_, i) => ({ id: 'R' + i, lat: -6, lon: 106 + i * .01, eta: new Date(Date.now() + 4 * 3600000).toISOString() }))));
  assert.equal(roadTooMany.statusCode, 400, 'Jumlah titik rute darat tidak boleh melebihi 48');

  const roadEta1 = Math.ceil((Date.now() + 3 * 3600000) / 3600000) * 3600000;
  const roadEta2 = roadEta1 + 3600000;
  const roadPoints = [
    { id: 'ROAD1', lat: -7.7558, lon: 110.3608, eta: new Date(roadEta1).toISOString(), adm4: '34.04.06.2001' },
    { id: 'ROAD2', lat: -7.7926, lon: 110.3657, eta: new Date(roadEta2).toISOString() }
  ];
  let roadFetchCount = 0;
  global.fetch = async url => {
    roadFetchCount++;
    const source = String(url);
    if (source.includes('api.bmkg.go.id')) {
      return { ok: true, status: 200, json: async () => ({ data: [{ cuaca: [[{
        utc_datetime: new Date(roadEta1).toISOString().slice(0, 19).replace('T', ' '),
        t: 27, hu: 88, ws: 12, wd: 'Barat', weather_desc: 'Hujan Ringan', vs_text: '5 km', tcc: 90
      }]] }] }) };
    }
    const params = new URL(source).searchParams;
    const model = params.get('models') || 'best';
    const latCount = String(params.get('latitude') || '').split(',').length;
    const probability = model === 'ecmwf_ifs025' ? 40 : model === 'gfs_seamless' ? 60 : 20;
    const values = roadPoints.slice(0, latCount).map(point => ({ hourly: {
      time: [new Date(Math.floor(Date.parse(point.eta) / 3600000) * 3600000).toISOString().slice(0, 16)],
      temperature_2m: [model === 'best' ? 29 : 30], apparent_temperature: [31], relative_humidity_2m: [75],
      precipitation_probability: [probability], precipitation: [0.8], weather_code: [61],
      wind_speed_10m: [10], wind_direction_10m: [270], wind_gusts_10m: [14], visibility: [9000],
      cloud_cover: [70], pressure_msl: [1008]
    } }));
    return { ok: true, status: 200, json: async () => values };
  };
  const roadGood = await road.handler(post(roadPoints));
  assert.equal(roadGood.statusCode, 200, 'Prakiraan rute darat harus berhasil dengan model dan BMKG');
  const roadBody = JSON.parse(roadGood.body);
  assert.equal(roadBody.points.length, 2, 'Semua titik rute harus dikembalikan');
  assert.equal(roadBody.points[0].temperature_c, 27, 'Nilai suhu BMKG harus mengungguli model pada ADM4 yang tervalidasi');
  assert.equal(roadBody.points[0].condition, 'Hujan Ringan', 'Deskripsi kondisi cuaca BMKG harus dipertahankan');
  assert.equal(roadBody.points[0].field_sources.temperature, 'BMKG', 'Sumber tiap field harus mencatat BMKG');
  assert.equal(roadBody.points[1].temperature_c, 29, 'Lokasi tanpa BMKG harus memakai Best Match');
  assert.equal(roadBody.points[1].field_sources.temperature, 'Best Match', 'Fallback harus mencatat model asal');
  assert.equal(roadBody.points[1].precipitation_probability_pct, 40, 'Peluang hujan harus dirata-ratakan dari model yang tersedia');
  const roadFetchCountAfterGood = roadFetchCount;
  const roadCached = await road.handler(post(roadPoints));
  assert.equal(JSON.parse(roadCached.body).meta.cache, 'hit', 'Cache rute darat harus menyimpan hasil per rute/ETA/ADM4');
  assert.equal(roadFetchCount, roadFetchCountAfterGood, 'Cache rute darat harus mengurangi permintaan model berulang');

  const maxRoadEta = new Date(Math.ceil((Date.now() + 5 * 3600000) / 3600000) * 3600000).toISOString();
  const maxRoadPoints = Array.from({ length: 48 }, (_, i) => ({ id: 'MAX' + i, lat: -6.5 - (i % 10) * .02, lon: 100 + i * .35, eta: maxRoadEta }));
  global.fetch = async url => {
    const params = new URL(String(url)).searchParams;
    const count = String(params.get('latitude') || '').split(',').length;
    const time = maxRoadEta.slice(0, 16);
    return { ok: true, status: 200, json: async () => Array.from({ length: count }, () => ({ hourly: { time: [time], temperature_2m: [28], relative_humidity_2m: [80], precipitation_probability: [35], precipitation: [0.4], weather_code: [61], wind_speed_10m: [9], wind_direction_10m: [260], wind_gusts_10m: [12], visibility: [8000], cloud_cover: [80], pressure_msl: [1009] } })) };
  };
  const roadMax = await road.handler(post(maxRoadPoints));
  assert.equal(roadMax.statusCode, 200, 'Backend cuaca rute harus menerima hingga 48 titik dalam satu batch');
  assert.equal(JSON.parse(roadMax.body).points.length, 48, 'Backend harus mengembalikan seluruh 48 titik cuaca');

  const addressBad = await routeAddresses.handler({ httpMethod: 'POST', body: JSON.stringify({ points: [{ id: 'A', lat: 40, lon: 110 }] }) });
  assert.equal(addressBad.statusCode, 400, 'Reverse geocoding rute harus menolak lokasi di luar Indonesia');
  global.fetch = async () => ({ ok: true, status: 200, json: async () => ({ display_name: 'Jalan Magelang, Sinduadi, Mlati, Sleman, DI Yogyakarta, Indonesia', address: { road: 'Jalan Magelang', village: 'Sinduadi', county: 'Sleman', state: 'DI Yogyakarta' } }) });
  const addressGood = await routeAddresses.handler({ httpMethod: 'POST', body: JSON.stringify({ points: [{ id: 'ADDR1', lat: -7.7558, lon: 110.3608 }] }) });
  assert.equal(addressGood.statusCode, 200, 'Reverse geocoding harus mengembalikan nama wilayah saat provider tersedia');
  assert.equal(JSON.parse(addressGood.body).locations[0].road, 'Jalan Magelang', 'Nama jalan dari OSM harus ditampilkan');
  assert.match(JSON.parse(addressGood.body).locations[0].locality, /Sinduadi/, 'Nama desa/kecamatan harus ikut dicantumkan');

  global.fetch = async url => ({
    ok: true,
    status: 200,
    json: async () => ({ Infogempa: { gempa: [{ Magnitude: '4.2', Wilayah: String(url) }] } })
  });
  const quakeProxy = await publicData.handler(event({ source: 'quakes' }));
  assert.equal(quakeProxy.statusCode, 200, 'Proxy daftar gempa harus mengembalikan sukses saat feed tersedia');
  const quakeBody = JSON.parse(quakeProxy.body);
  assert.equal(quakeBody.feeds.length, 3, 'Proxy harus memeriksa tiga feed publik BMKG');
  assert.ok(quakeBody.feeds.every(feed => feed.ok && feed.data?.Infogempa?.gempa), 'Setiap feed sukses harus membawa data BMKG');
  global.fetch = async () => ({ ok: false, status: 503, json: async () => ({}) });
  const quakeFail = await publicData.handler(event({ source: 'quakes' }));
  assert.equal(quakeFail.statusCode, 502, 'Proxy harus menyatakan gagal bila seluruh feed BMKG gagal');
} finally {
  global.fetch = originalFetch;
}

assert.match(html, /\.fw-load-indicator\{position:fixed;top:/, 'Indikator proses harus berada di bagian atas');
assert.match(html, /function actionCard[\s\S]*?replace\('<\/article>'/, 'Tombol CTA harus berada di dalam kartu rekomendasi');
assert.match(html, /L\.esri\.dynamicMapLayer/, 'Layer BNPB harus memakai ArcGIS dynamic map layer bila plugin tersedia');
assert.match(html, /L\.imageOverlay\(exportUrl\(spec,m\.getBounds\(\),m\.getSize\(\)\),m\.getBounds\(\)/, 'Layer bahaya harus memakai ekspor REST WGS84 berukuran sesuai tampilan peta');
assert.match(html, /bboxSR:'4326',imageSR:'4326'/, 'BBox fallback harus menggunakan koordinat WGS84');
assert.match(html, /INDEKS_BAHAYA_BANJIR/, 'Layer raster banjir nasional harus terdaftar');
assert.match(html, /INDEKS_BAHAYA_TANAHLONGSOR/, 'Layer raster tanah longsor nasional harus terdaftar');
assert.match(html, /INDEKS_BAHAYA_TSUNAMI/, 'Layer tsunami nasional harus terdaftar');
assert.match(html, /INDEKS_BAHAYA_GEMPABUMI/, 'Layer gempa memakai indeks bahaya nasional resmi');
assert.match(html, /function drawLayer[\s\S]*?L\.imageOverlay\(exportUrl\(spec,m\.getBounds\(\),m\.getSize\(\)\),m\.getBounds\(\)[\s\S]*?addEsriFallback/, 'Peta mengutamakan REST export langsung dengan ArcGIS Leaflet sebagai fallback');
assert.match(html, /function identifyActiveLayer[\s\S]*?L\.esri\.identifyImage[\s\S]*?L\.esri\.identifyFeatures/, 'Peta menampilkan nilai raster atau atribut provinsi saat lokasi di dalam layer ditekan');
assert.match(html, /INDEKS_BAHAYA_BANJIR/, 'Raster banjir harus memakai ImageServer nasional yang aktif');
assert.match(html, /INDEKS_BAHAYA_TANAHLONGSOR/, 'Raster longsor harus memakai ImageServer nasional yang aktif');
assert.match(html, /id="fwRiskMapLegend"[\s\S]*?0–0,333[\s\S]*?0,334–0,666[\s\S]*?0,667–1,000/, 'Legenda kelas raster nasional harus terlihat');
assert.ok(html.includes('Persiapan Berkegiatan di Luar') && html.includes('id="fwDashKit"'), 'Judul persiapan kegiatan luar ruang harus berubah');
assert.match(html, /end=now\+5\*3600000/, 'Perlengkapan harus menyesuaikan cuaca untuk horizon dekat');
assert.match(html, /const uvLabel=!dayLight\?'Tidak diperlukan pada waktu ini':uv===null\?'Data UV belum tersedia'/, 'Perlengkapan UV tidak boleh disarankan saat rentang aktivitas malam');
assert.match(html, /#fwRiskMapLegend\{position:static!important/, 'Legenda panel risiko harus berada di bawah peta, bukan menutup raster');
assert.match(html, /function loadLaundry[\s\S]*?Hindari \/ segera angkat[\s\S]*?Waspada \/ lambat kering[\s\S]*?Relatif Mendukung/, 'Rekomendasi jemuran harus menyediakan tiga status yang kontekstual');
assert.match(html, /function activitySlots[\s\S]*?running:\[\[4,11\],\[15,21\]\][\s\S]*?jogging:\[\[4,12\],\[15,22\]\]/, 'Aktivitas harus memeriksa jendela pagi dan sore/malam');
assert.match(html, /DIBI_Provinsi_2015_2024_Hidromet\/MapServer/, 'Layer histori memakai layanan nasional tingkat provinsi yang tersedia');
assert.ok(html.includes('data-fw-open-page=') && html.includes('navTo(b.dataset.fwOpenPage)'), 'Navigasi CTA harus terhubung ke menu yang sudah ada');
assert.match(html, /id="fwTourismCategory"[\s\S]*?value="hot_spring"[\s\S]*?value="village"/, 'Kategori wisata harus mencakup ragam destinasi');
assert.match(html, /id="fwRadarNationalFrame"[\s\S]*?https:\/\/www\.bmkg\.go\.id\/cuaca\/radar/, 'Radar BMKG nasional harus ditanamkan di halaman');
assert.match(html, /id="fwRadarYogyaFrame"[\s\S]*?https:\/\/stamet-yogya\.bmkg\.go\.id\/area-hujan\//, 'Radar BMKG Yogyakarta harus ditanamkan di halaman');
assert.match(html, /id="fwAirRefresh"/, 'Pengguna harus dapat memperbarui data kualitas udara');
assert.match(html, /function renderQuakeMap[\s\S]*?L\.circleMarker[\s\S]*?marker\.bindPopup/, 'Titik gempa harus dapat ditekan untuk melihat informasi');
assert.match(html, /fillColor:major\?'#ef4444':'#ffd43b'/, 'Warna marker gempa harus membedakan M≥5 dan M<5');
assert.match(html, /renderer:L\.svg\(\)/, 'Marker gempa harus memakai renderer SVG yang terlihat di atas peta');
assert.match(html, /function loadQuakeList[\s\S]*?source=quakes/, 'Daftar gempa harus memakai proxy Netlify');
assert.match(html, /function activitySlots[\s\S]*?kind==='running'[\s\S]*?kind==='cycling'/, 'Waktu aktivitas harus dihitung dari prakiraan, bukan string statis');
assert.match(html, /Waktu alternatif: \$\{windowText\(second\)\}/, 'Kartu aktivitas harus menampilkan waktu alternatif dengan rentang satu jam');
assert.match(html, /fw-activity-compact\{width:182px/, 'Kartu aktivitas harus ringkas di Android');
assert.match(html, /function sampleRoutePoints[\s\S]*?out\[out\.length-1\]=[\s\S]*?fraction:1,distanceKm:total/, 'Sampel cuaca rute harus mempertahankan titik tujuan dan menginterpolasi jarak');
assert.match(html, /Math\.min\(48,Math\.max\(6,Math\.ceil\(totalKm\/18\)\+1\)\)/, 'Rute jalan harus dianalisis dengan titik rapat hingga 48 titik');
assert.match(html, /road-route-forecast/, 'Prakiraan rute jalan harus memakai backend batch');
assert.match(html, /route-addresses/, 'Nama lokasi sepanjang rute harus diambil dari reverse geocoding server');
assert.match(html, /function addWeatherMarker[\s\S]*?L\.divIcon/, 'Setiap titik rute harus memiliki marker bernomor');
assert.match(html, /function weatherRisk[\s\S]*?return 'unknown'/, 'Warna titik harus membedakan hijau, kuning, merah, dan abu-abu');
const roadWeatherNumSource = html.match(/const weatherNum=value=>[^;]+;/)?.[0];
const roadWeatherRiskSource = html.match(/function weatherRisk\(w\)\{[\s\S]*?\n\}/)?.[0];
const roadConditionSource = html.match(/function routeCondition\(w\)\{[^\n]*\}/)?.[0];
const roadRainIntensitySource = html.match(/function rainIntensity\(w\)\{[^\n]*\}/)?.[0];
const roadCodeTextSource = html.match(/const wmoText=code=>[^;]+;/)?.[0];
assert.ok(roadWeatherNumSource && roadWeatherRiskSource && roadConditionSource && roadRainIntensitySource && roadCodeTextSource, 'Klasifikasi risiko dan intensitas hujan titik rute harus tersedia');
const roadRiskFns = vm.runInNewContext(`${roadWeatherNumSource}; ${roadCodeTextSource}; ${displayConditionSource}; ${roadConditionSource}; ${roadWeatherRiskSource}; ${roadRainIntensitySource}; ({weatherRisk,rainIntensity,wmoText})`);
assert.equal(roadRiskFns.weatherRisk({available:true,precipitation_probability_pct:95,precipitation_mm:0.1,weather_code:61}), 'high', 'Peluang hujan sangat tinggi harus berwarna merah');
assert.equal(roadRiskFns.weatherRisk({available:true,precipitation_probability_pct:55,precipitation_mm:0.8,weather_code:61}), 'mid', 'Hujan ringan dengan probabilitas menengah harus berwarna kuning');
assert.equal(roadRiskFns.weatherRisk({available:true,precipitation_probability_pct:5,precipitation_mm:0,weather_code:2}), 'low', 'Cuaca minim indikasi hujan harus berwarna hijau');
assert.equal(roadRiskFns.weatherRisk({available:false,precipitation_probability_pct:null,precipitation_mm:null,weather_code:null}), 'unknown', 'Semua nilai kosong harus berwarna abu-abu');
assert.equal(roadRiskFns.rainIntensity({weather_code:61}), 'Hujan ringan', 'Kode WMO 61 harus dibaca sebagai hujan ringan');
assert.equal(roadRiskFns.rainIntensity({weather_code:65}), 'Hujan lebat', 'Kode WMO 65 harus dibaca sebagai hujan lebat');
assert.equal(roadRiskFns.rainIntensity({weather_code:51}), 'Mendung', 'Label kode gerimis pada rute harus ditampilkan sebagai mendung');
assert.equal(roadRiskFns.rainIntensity({weather_code:51,precipitation_probability_pct:79}), 'Hujan ringan', 'Label mendung pada rute berubah hanya bila probabilitas hujan di atas 78%');
assert.equal(roadRiskFns.rainIntensity({weather_code:61,precipitation_probability_pct:99}), 'Hujan ringan', 'Kode hujan yang sudah hujan ringan tetap hujan ringan');
assert.equal(roadRiskFns.weatherRisk({available:true,precipitation_probability_pct:40,precipitation_mm:0.2,weather_code:51}), 'mid', 'Sinyal presipitasi kode gerimis tetap dihitung dalam risiko hujan meski label UI menjadi mendung');
assert.equal(roadRiskFns.wmoText(null), null, 'Kode cuaca kosong tidak boleh keliru dibaca sebagai cerah');
assert.match(html, /function findNearbySafeStops[\s\S]*?overpass-api\.de/, 'Saran tempat singgah harus memakai data lokasi OpenStreetMap');
assert.match(html, /steps=true/, 'Geometri rute harus menyertakan instruksi ruas untuk menampilkan nama jalan');

assert.match(html, /id="fwFlightPlanner"[\s\S]*?id="fwFlightFrom"[\s\S]*?id="fwFlightTo"[\s\S]*?id="fwFlightDeparture"[\s\S]*?id="fwFlightDuration"/, 'Perencana penerbangan harus memiliki bandara, tanggal, jam, dan durasi');
assert.match(html, /id="fwFlightMap"[\s\S]*?id="fwFlightRows"/, 'Perencana penerbangan harus menampilkan peta dan tabel titik');
assert.match(html, /flight-route-forecast/, 'Frontend harus meminta backend prakiraan rute');
assert.match(html, /METAR[\s\S]*?TAF/, 'Laporan METAR/TAF bandara harus ditampilkan terpisah dari model');
assert.match(html, /type=metar&amp;ids=|type=metar&amp;ids|type=metar/, 'Observasi METAR bandara terdekat harus dapat dipakai sebagai pembanding kondisi terkini');
assert.match(html, /diinterpolasi dari data per jam/, 'Data minutely-15 Indonesia tidak boleh diklaim sebagai observasi langsung');
assert.match(html, /function metarCondition\(report\)/, 'Decoder fenomena cuaca METAR harus tersedia');
const riskSource = html.match(/function riskFor\(p\)\{[^\n]*\}/)?.[0];
assert.ok(riskSource, 'Klasifikasi cuaca titik rute harus tersedia');
const riskFor = vm.runInNewContext(`${riskSource}; riskFor`);
assert.equal(riskFor({ available: true, precipitation_probability_pct: 20, precipitation_mm: 0, visibility_m: null, weather_code: 2 }).key, 'low', 'Nilai visibility null tidak boleh dibaca sebagai nol dan memicu risiko tinggi palsu');
assert.equal(riskFor({ available: true, precipitation_probability_pct: null, precipitation_mm: null, visibility_m: null, weather_code: null }).key, 'unknown', 'Data yang tidak tersedia harus ditandai unknown, bukan dianggap cerah atau berbahaya');
assert.equal(riskFor({ available: true, precipitation_probability_pct: 80, precipitation_mm: 1.2, visibility_m: 2500, weather_code: 95 }).key, 'high', 'Sinyal hujan lebat/petir harus ditandai sebagai indikasi risiko tinggi');
assert.equal(riskFor({ available: true, precipitation_probability_pct: null, precipitation_mm: 0, visibility_m: null, weather_code: 0 }).key, 'low', 'Sinyal cerah dan tidak ada hujan tetap dapat ditandai hijau meski probabilitas/visibilitas tidak dikirim');
assert.match(html, /adaptiveAdm4:true/, 'Hasil pemetaan BMKG yang kosong harus memakai cache pendek');
assert.match(html, /firstFallbackCurrentValue\('weather_code'/, 'Kode cuaca kategori tidak boleh dirata-ratakan');
const currentFallbackSource = html.match(/function nearestHourlyCurrentValue\(hourly,field\)[\s\S]*?(?=function fallbackDailyValue)/)?.[0];
assert.ok(currentFallbackSource, 'Fallback current harus membaca slot hourly utama dan provider alternatif');
const parseLocalSource = html.match(/function parseLocal\(s\)\{[^\n]*\}/)?.[0];
const currentFallbackContext = { S: { o: { hourly: { time: [new Date(Date.now()+7*3600000).toISOString().slice(0, 16)], temperature_2m: [27], weather_code: [61], wind_direction_10m: [270] } }, fallbackRuns: [{ current: { temperature_2m: 35, weather_code: 95, wind_direction_10m: 10 }, hour: { time: [new Date(Date.now()+7*3600000).toISOString().slice(0, 16)], temperature_2m: [35], weather_code: [95], wind_direction_10m: [10] } }] }, console };
const currentFallbackFns = vm.runInNewContext(`${parseLocalSource}; ${currentFallbackSource}; ({fallbackCurrentValue,firstFallbackCurrentValue})`, currentFallbackContext);
assert.equal(currentFallbackFns.fallbackCurrentValue('temperature_2m', null), 27, 'Slot hourly Best Match harus dipakai sebelum provider alternatif');
assert.equal(currentFallbackFns.firstFallbackCurrentValue('weather_code', null), 61, 'Kode cuaca kategori harus memilih nilai primary, bukan rata-rata model');
assert.match(html, /const sources=\[\{name:S\.o\?\.__fwSource/, 'Prakiraan harian harus membaca model alternatif yang tersedia');
assert.match(html, /modelCode=firstModelValueAt\('weather_code'/, 'Variabel yang kosong pada slot BMKG harus dilengkapi dari model');
assert.match(html, /segmentColor=\{low:'#16834b',mid:'#d59a16',high:'#c33737',unknown:'#758397'\}/, 'Garis lintasan harus memvisualisasikan status cuaca per segmen');
const metarDecoderSource = html.match(/function metarCondition\(report\)\{[\s\S]*?\n\}/)?.[0];
const metarCondition = vm.runInNewContext(`${metarDecoderSource}; metarCondition`);
assert.deepEqual(Array.from(metarCondition({ rawOb: 'METAR WAHH 121430Z 27005KT 4000 -RA BKN015 26/25 Q1013' })), ['Hujan ringan', '🌧️'], 'METAR -RA harus dikenali sebagai hujan ringan');
assert.deepEqual(Array.from(metarCondition({ rawOb: 'METAR WAHH 121430Z 27005KT 4000 +TSRA BKN015 26/25 Q1013' })), ['Hujan disertai petir', '⛈️'], 'METAR TSRA harus dikenali sebagai hujan disertai petir');
assert.deepEqual(Array.from(metarCondition({ rawOb: 'METAR WAHH 121430Z 27005KT 4000 -DZ BKN015 26/25 Q1013' })), ['Mendung', '☁️'], 'Kode fenomena DZ ditampilkan sebagai Mendung');
assert.deepEqual(Array.from(metarCondition({ rawOb: 'METAR WAHH 121430Z 27005KT 9999 SCT020 27/23 Q1013' })), ['Cerah berawan', '⛅'], 'Cloud layer METAR harus dibaca jika tidak ada fenomena hujan');
assert.match(html, /currentWeatherSource/, 'Sumber dan keterbatasan kondisi terkini harus ditampilkan');

const dashStart = html.indexOf('<section id="dashboard"');
const forecastStart = html.indexOf('<section id="forecast"', dashStart);
assert.ok(dashStart >= 0 && forecastStart > dashStart, 'Halaman Dashboard harus ditemukan');
assert.ok(!html.slice(dashStart, forecastStart).includes('fwTourismForm'), 'Dashboard hanya menampilkan pintasan, bukan form pencarian wisata');
assert.match(html, /<section id="tourism" class="page"/, 'Pencarian wisata harus berada di menu khusus');

// Coordinate-specific main weather model and guarded atmospheric fallbacks.
assert.match(html, /const PROB_MODELS=\[\{id:'ecmwf_ifs',name:'ECMWF IFS'\}/, 'ECMWF IFS harus menjadi model utama yang dipilih secara eksplisit');
const normalizeRainSource = html.match(/function normalizeRain\(v\)\{[^\n]*\}/)?.[0];
assert.ok(normalizeRainSource, 'Normalisasi peluang hujan harus tersedia');
const normalizeRain = vm.runInNewContext(`${normalizeRainSource}; normalizeRain`);
assert.equal(normalizeRain(null), null, 'Probabilitas null tidak boleh dikonversi menjadi 0%');
assert.equal(normalizeRain(undefined), null, 'Probabilitas yang hilang tidak boleh dikonversi menjadi 0%');
assert.equal(normalizeRain(0), 0, 'Peluang 0% yang benar harus tetap dipertahankan');
assert.equal(normalizeRain(100), 100, 'Peluang 100% yang benar harus tetap dipertahankan');
assert.match(html, /id:'ncep_gfs_seamless',name:'NCEP GFS'/, 'ID API GFS harus valid');
assert.match(html, /id:'icon_seamless',name:'DWD ICON'/, 'ICON harus tetap tersedia sebagai pembanding');
const weatherModelCatalog = html.slice(html.indexOf('const PROB_MODELS='), html.indexOf('async function loadFallbackModels'));
assert.ok(weatherModelCatalog, 'Katalog model dashboard cuaca harus tersedia');
assert.doesNotMatch(weatherModelCatalog, /id:'gfs_seamless'/, 'ID GFS lama yang tidak valid tidak boleh dipakai pada mesin dashboard cuaca');

assert.match(html, /models:'ecmwf_ifs'/, 'Permintaan utama harus mengunci model ECMWF pada koordinat pilihan');
assert.match(html, /async function loadFallbackModels\(location=.*revision=/, 'Permintaan model pembanding harus menerima snapshot koordinat dan revisi lokasi');
assert.match(html, /const requestLat=location\.lat,requestLon=location\.lon/, 'Fallback harus memakai koordinat snapshot, bukan membaca lokasi global yang dapat berubah');
assert.match(html, /if\(revision!==\(S\.locationRevision\|\|0\)\)return/, 'Respons model pembanding lama tidak boleh menimpa hasil koordinat terbaru');
assert.match(html, /loadFallbackModels\(location,requestRevision,requestSignal\)/, 'Pemanggil harus mengikat fetch model ke revisi koordinat permintaan');
assert.match(html, /async function getJson\(url,timeout=12000,externalSignal=null\)/, 'Pengambilan data harus mendukung pembatalan permintaan lama');
assert.match(html, /getJson\(base,12000,requestSignal\)/, 'Fetch ECMWF harus dapat dibatalkan saat koordinat berganti');
assert.match(html, /loadFallbackModels\(location,requestRevision,requestSignal\)/, 'Fetch model pembanding harus dapat dibatalkan saat koordinat berganti');
assert.match(html, /S\.weatherRequestController\?\.abort\(\)/, 'Pemilihan lokasi baru harus membatalkan permintaan cuaca yang masih berjalan');
assert.match(html, /cloud_cover_high,uv_index,freezing_level_height,cape/, 'GFS harus diminta untuk indeks UV dan freezing level');
assert.match(html, /convective_cloud_base,convective_cloud_top,freezing_level_height,cape/, 'ICON harus diminta untuk tinggi dasar dan puncak awan serta freezing level');
assert.match(html, /const lean=isIcon[\s\S]*?convective_cloud_base,convective_cloud_top,freezing_level_height,cape/, 'Retry ICON harus memakai parameter inti yang didukung ICON');
assert.match(html, /const leanDaily=isIcon\?'sunrise,sunset':'sunrise,sunset,uv_index_max'/, 'Retry GFS harus mempertahankan UV maksimum harian; retry ICON hanya meminta variabel harian yang didukung');
assert.match(html, /Belum ada model yang mengeluarkan probabilitas valid/, 'Rincian peluang hujan harus tetap tampil dengan status data tidak tersedia');
assert.match(html, /Tidak tersedia dari model/, 'Puncak awan tidak boleh diisi dengan angka rekaan');
assert.match(html, /cloudBaseM:modelCloudBase\?\?lcl/, 'Tinggi dasar awan memakai model ICON atau estimasi LCL yang diberi label');

assert.match(html, /latitude:String\(location\.lat\),longitude:String\(location\.lon\)/, 'Permintaan utama harus memakai koordinat terpilih, bukan nama kota');
assert.match(html, /function fallbackAt\(field,t,original\)\{const base=original===null/, 'Nilai utama harus dipakai sebelum fallback model');
assert.match(html, /function modelValueAt\(field,t\)\{for\(const run of S\.fallbackRuns\)/, 'Variabel yang hilang memakai fallback pertama dengan sumber yang jelas, bukan rata-rata lintas model');
assert.match(html, /cloudCover:bmkgCloud!==null&&bmkgCloud!==undefined/, 'Tutupan awan null dari BMKG tidak boleh menjadi angka 0%');
assert.match(html, /function dewPointFromTempRH\(temp,rh\)/, 'Titik embun harus dapat dihitung dari suhu dan kelembapan yang valid');
assert.match(html, /function estimateLclBase\(temp,dewPoint\)/, 'Dasar awan estimasi harus menggunakan LCL dan diberi label estimasi');
assert.match(html, /id="fwAtmosSurfacePressure"/, 'Panel tekanan permukaan harus tersedia');
assert.match(html, /id="fwAtmosUv"/, 'Panel indeks UV harus tersedia');
assert.match(html, /id="fwAtmosCloudLayers"/, 'Panel lapisan awan rendah, menengah, dan tinggi harus tersedia');
assert.match(html, /id="fwAtmosCloudTop"/, 'Kolom puncak awan harus tetap menampilkan status bila model tidak menyediakannya');
assert.match(html, /renderAtmosphereSummary\(\)/, 'Panel parameter atmosfer harus diperbarui setelah data dimuat');
assert.match(html, /<th>UV maksimum<\/th>/, 'Tabel harian harus menyertakan UV maksimum');

const dewPointBlock = html.match(/function dewPointFromTempRH\(temp,rh\)\{[\s\S]*?\n\}/)?.[0];
const lclBlock = html.match(/function estimateLclBase\(temp,dewPoint\)\{[\s\S]*?\n\}/)?.[0];
assert.ok(dewPointBlock && lclBlock, 'Rumus titik embun dan LCL harus dapat diuji');
const thermo = vm.runInNewContext(`${dewPointBlock}; ${lclBlock}; ({dewPointFromTempRH,estimateLclBase})`);
const dewPoint = thermo.dewPointFromTempRH(30, 70);
assert.ok(dewPoint > 23 && dewPoint < 25, 'Rumus titik embun harus menghasilkan rentang fisik wajar untuk 30°C dan RH 70%');
assert.ok(thermo.estimateLclBase(30, dewPoint) > 600 && thermo.estimateLclBase(30, dewPoint) < 900, 'Estimasi LCL harus berada pada rentang wajar untuk kondisi uji');
assert.equal(thermo.dewPointFromTempRH(30, 0), null, 'RH nol tidak boleh menghasilkan titik embun palsu');

console.log('UJI EKSTENSI DASHBOARD: LULUS');
console.log('✓ Validasi koordinat kualitas udara dan destinasi');
console.log('✓ Parser koordinat gempa: LS/LU/BB/BT, desimal koma, dan DMS');
console.log('✓ Proxy tiga feed gempa BMKG, termasuk status gagal');
console.log('✓ Titik gempa interaktif dan warna berdasarkan magnitudo');
console.log('✓ Layer BNPB ArcGIS dengan fallback WGS84');
console.log('✓ Kartu aktivitas kompak dengan rentang waktu dan alternatif');
console.log('✓ Sampel rute interpolasi rapat mempertahankan titik awal dan tujuan hingga 48 titik');
console.log('✓ Prakiraan rute darat batch, sumber BMKG prioritas, fallback model, dan cache');
console.log('✓ Reverse geocoding rute menampilkan nama jalan dan wilayah');
console.log('✓ Decoder METAR membedakan hujan, petir, dan lapisan awan');
console.log('✓ Perencana penerbangan: validasi waktu/koordinat, fallback per field, multi-model, cache, dan kegagalan provider');
console.log('✓ Perencana rute penerbangan pada menu bandara dan 43 pilihan bandara');
console.log('✓ Prioritas BMKG, pelengkap model untuk slot/variabel kosong, dan marker/segmen rute berwarna');
console.log('✓ Radar BMKG tertanam, navigasi wisata, dan validasi kategori');
