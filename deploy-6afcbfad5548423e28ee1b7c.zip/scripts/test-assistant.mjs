import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

process.env.TZ = 'Asia/Jakarta';
const fixedNow = Date.parse('2026-11-12T03:00:00.000Z');
Date.now = () => fixedNow;
const assistant = await import('../netlify/functions/assistant.js');
const { normalize, classify, answerQuestion, filterHours, resolveFollowUp, weatherConditionFromCode, cleanCondition, cleanContext, compassFromDegrees } = assistant._test;

const hourly = Array.from({ length: 96 }, (_, i) => {
  const time = new Date(fixedNow + i * 60 * 60 * 1000).toISOString();
  const wet = i === 18 || i === 19 || i === 30;
  return {
    time,
    condition: wet ? 'Hujan Ringan' : 'Cerah Berawan',
    temp: 25 + (i % 7),
    feels: 28,
    humidity: wet ? 91 : 76,
    rain: wet ? 72 : 12,
    precip: wet ? 0.8 : 0,
    wind: 12,
    visibility: 6500,
    uv: i % 24 >= 10 && i % 24 <= 13 ? 7 : 2,
    cloud: wet ? 90 : 45,
    pressure: 1008 + (i % 4),
    windDirDeg: 90 + (i % 4) * 45,
    gust: 18 + (i % 3),
    code: wet ? 61 : 2,
  };
});
const daily = Array.from({ length: 16 }, (_, i) => {
  const d = new Date(fixedNow + i * 86400000);
  const day = new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Jakarta', year: 'numeric', month: '2-digit', day: '2-digit' }).format(d);
  return { day, condition: i === 1 ? 'Hujan Ringan' : 'Cerah Berawan', lo: 22, hi: 31, p: i === 1 ? 70 : 15, rain: i === 1 ? 4.2 : 0, wind: 14, hum: 78, uv: 6 };
});
const context = {
  location: 'Sinduadi, Mlati, Sleman, DI Yogyakarta',
  current: { condition: 'Cerah Berawan', temp: 29, feels: 31, humidity: 79, rain: 0, wind: 10, windDir: 'Timur', windDirDeg: 90, gust: 16, code: 2, visibility: 8, pressure: 1009, uv: 5, cloud: 45 },
  hourly,
  daily,
  fetchedAt: new Date(fixedNow).toISOString(),
};

const cases = [
  ['Apakah hari ini hujan?', 'rain'],
  ['Besok pagi bagaimana?', 'rain'],
  ['Perlu bawa payung?', 'equipment'],
  ['Kalau naik motor aman nggak?', 'travel'],
  ['Kapan cocok jogging?', 'jogging'],
  ['Apakah besok cocok menjemur?', 'laundry'],
  ['Bagaimana cuaca 10 hari ke depan?', 'forecast10'],
  ['Bagaimana prakiraan cuaca 4 hari ke depan?', 'forecast4'],
  ['Bagaimana cuaca 15 hari ke depan?', 'forecast15'],
  ['Bagaimana cuaca selama seminggu?', 'forecast7'],
  ['Kenapa kelembapan tinggi?', 'humidity'],
  ['Kapan tanaman harus disiram?', 'agriculture'],
  ['Bagaimana kondisi UV siang nanti?', 'uv'],
  ['Bagaimana kalau sore?', 'rain'],
  ['Apa yang harus saya bawa besok?', 'equipment'],
];
for (const [question, expected] of cases) {
  const history = question === 'Bagaimana kalau sore?'
    ? [{ role: 'user', content: 'Besok hujan nggak?' }, { role: 'assistant', content: 'Saya periksa prakiraan besok.' }]
    : [];
  const normalized = normalize(resolveFollowUp(question, history));
  assert.equal(classify(normalized), expected, `Intent gagal untuk: ${question}`);
  const answer = answerQuestion(question, context, history);
  assert.ok(typeof answer === 'string' && answer.length > 25, `Jawaban kosong untuk: ${question}`);
  assert.doesNotMatch(answer, /undefined|null°C|null%/i, `Jawaban mengandung nilai kosong untuk: ${question}`);
}


const expandedCases = [
  ['Berapa tekanan udara saat ini?', 'pressure'],
  ['Berapa jarak pandang sekarang?', 'visibility'],
  ['Bagaimana tutupan awan hari ini?', 'cloud'],
  ['Apakah besok cerah atau mendung?', 'condition'],
  ['Bagaimana arah angin hari ini?', 'windDirection'],
  ['Apakah udara sehat di lokasi ini?', 'air'],
  ['Apakah ada kabut di sini?', 'visibility'],
  ['Apakah ada petir hari ini?', 'lightning'],
  ['Apa itu titik embun?', 'dewpoint'],
  ['Apa itu ENSO dan dampaknya terhadap hujan Indonesia?', 'explain'],
  ['Apa itu MJO?', 'explain'],
  ['Jelaskan perbedaan DALR dan MALR', 'explain'],
  ['Apa itu angin geostrofik?', 'explain'],
  ['Apa itu jet stream?', 'explain'],
  ['Bagaimana hujan orografis terbentuk?', 'explain'],
  ['Bagaimana status gunung Merapi?', 'mountain'],
  ['Apakah ada peringatan dini BMKG?', 'alerts'],
  ['Dari mana sumber data prakiraan?', 'source'],
];
for (const [question, expected] of expandedCases) {
  assert.equal(classify(normalize(question)), expected, `Intent tambahan gagal untuk: ${question}`);
  const answer = answerQuestion(question, context, []);
  assert.ok(typeof answer === 'string' && answer.length > 25, `Jawaban tambahan kosong untuk: ${question}`);
  assert.doesNotMatch(answer, /undefined|null°C|null%/i, `Jawaban tambahan mengandung nilai kosong untuk: ${question}`);
}
const pressureAnswer = answerQuestion('Berapa tekanan udara saat ini?', context, []);
assert.match(pressureAnswer, /1009\.0 hPa/);
const visibilityAnswer = answerQuestion('Berapa jarak pandang sekarang?', context, []);
assert.match(visibilityAnswer, /8\.0 km/);
const dewpointAnswer = answerQuestion('Berapa titik embun saat ini?', context, []);
assert.match(dewpointAnswer, /titik embun.*°C/i);
const temperatureFallback = answerQuestion('Berapa suhu sekarang?', { location: 'Lokasi uji', current: {}, hourly }, []);
assert.match(temperatureFallback, /suhu yang tersedia/);
const humidityFallback = answerQuestion('Berapa kelembapan sekarang?', { location: 'Lokasi uji', current: {}, hourly }, []);
assert.match(humidityFallback, /kelembapan relatif yang tersedia/i);
const noAlertData = answerQuestion('Apakah ada peringatan dini BMKG?', { location: 'Lokasi uji', hourly, daily }, []);
assert.match(noAlertData, /belum menerima isi peringatan aktif/i);
const alertData = answerQuestion('Apakah ada peringatan dini BMKG?', { location: 'Lokasi uji', hourly, daily, alerts: ['Hujan lebat di wilayah uji sampai pukul 18.00 WIB'] }, []);
assert.match(alertData, /Hujan lebat di wilayah uji/);
const sourceData = answerQuestion('Dari mana sumber data prakiraan?', { location: 'Lokasi uji', hourly, daily, source: 'Open-Meteo ECMWF' }, []);
assert.match(sourceData, /Open-Meteo ECMWF/);


// Additional accuracy regressions for derived weather labels, matching scales and vector direction.
assert.equal(weatherConditionFromCode(0), 'Cerah');
assert.equal(weatherConditionFromCode(3), 'Berawan');
assert.equal(weatherConditionFromCode(45), 'Berkabut');
assert.equal(weatherConditionFromCode(61), 'Hujan ringan');
assert.equal(weatherConditionFromCode(95), 'Badai petir');
assert.equal(weatherConditionFromCode(999), '');
assert.equal(cleanCondition('Tidak diketahui', 95), 'Badai petir');
assert.equal(cleanCondition('Mendung', 95), 'Mendung');
assert.equal(compassFromDegrees(135), 'Tenggara');
const derivedCondition = answerQuestion('Bagaimana kondisi cuaca sekarang?', { location: 'Lokasi WMO', current: { code: 3 }, hourly: [], daily: [] }, []);
assert.match(derivedCondition, /Berawan/);
const europeanAqi = answerQuestion('Bagaimana kualitas udara?', { location: 'Lokasi AQI', air: { europeanAqi: 120, source: 'Open-Meteo CAMS', resolutionKm: 45 } }, []);
assert.match(europeanAqi, /European AQI 120 \(skala EEA/);
assert.doesNotMatch(europeanAqi, /Tidak sehat/ , 'European AQI tidak boleh diberi kategori dengan ambang US AQI.');
const directionHourly = [{ time: new Date(fixedNow + 3600000).toISOString(), wind: 5, windDirDeg: 135, gust: 12 }];
const directionAnswer = answerQuestion('Bagaimana arah angin?', { location: 'Lokasi angin', current: {}, hourly: directionHourly }, []);
assert.match(directionAnswer, /Tenggara/);
const cleanCodeContext = cleanContext({ current: { condition: 'Tidak diketahui', code: 95 }, hourly: [{ time: new Date(fixedNow + 3600000).toISOString(), condition: '—', code: 61 }] });
assert.equal(cleanCodeContext.current.condition, 'Badai petir');
assert.equal(cleanCodeContext.hourly[0].condition, 'Hujan ringan');

assert.equal(hourly.length, 96);
assert.equal(daily.length, 16);

const fourDayAnswer = answerQuestion('Bagaimana prakiraan cuaca 4 hari ke depan?', context, []);
assert.match(fourDayAnswer, /^Prakiraan 4 hari/);
assert.match(fourDayAnswer, /Rincian per jam tersedia sampai 96 jam/);
const fifteenDayAnswer = answerQuestion('Bagaimana cuaca 15 hari ke depan?', context, []);
assert.match(fifteenDayAnswer, /^Prakiraan hari ini \+ 15 hari ke depan/);
assert.equal((fifteenDayAnswer.match(/\n/g) || []).length >= 15, true, 'Prakiraan hari ini + 15 hari tidak mencakup seluruh tanggal.');
const sevenDayAnswer = answerQuestion('Bagaimana cuaca selama seminggu?', context, []);
assert.match(sevenDayAnswer, /^Prakiraan 7 hari/);
assert.equal((sevenDayAnswer.match(/\n/g) || []).length >= 6, true, 'Ringkasan 7 hari tidak lengkap.');
const followup = resolveFollowUp('Bagaimana kalau sore?', [{ role: 'user', content: 'Besok hujan nggak?' }]);
const followupRows = filterHours(normalize(followup), hourly).rows;
assert.ok(followupRows.length > 0, 'Konteks follow-up tidak menghasilkan slot cuaca.');
assert.ok(followupRows.every(row => row.local.hour >= 15 && row.local.hour < 18), 'Follow-up sore tidak tersaring ke rentang sore.');
assert.ok(followupRows.every(row => row.local.date === '2026-11-13'), 'Follow-up tidak mempertahankan tanggal besok.');

const noDataAnswer = answerQuestion('Besok hujan nggak?', { location: 'Lokasi uji', hourly: [], daily: [] }, []);
assert.match(noDataAnswer, /belum tersedia|tidak tersedia/i, 'Asisten seharusnya menandai data kosong, bukan mengarang angka.');

const page = await readFile(new URL('../index.html', import.meta.url), 'utf8');
assert.match(page, /@media\(min-width:1024px\)\{#fwTanyaFab\{left:auto;right:22px/);
assert.match(page, /@media\(max-width:560px\).*#fwTanyaPanel/s);
assert.match(page, /grid-template-columns:248px minmax\(0,1fr\)/, 'Desktop sidebar layout must remain available');

const source = await readFile(new URL('../netlify/functions/assistant.js', import.meta.url), 'utf8');
assert.doesNotMatch(source, /api\.openai\.com|OPENAI_API_KEY/i, 'Asisten tidak boleh bergantung pada OpenAI API.');

console.log('UJI TANYAFIKRICUACA: LULUS');
console.log(`✓ ${cases.length} skenario intent dasar dan jawaban (termasuk prakiraan 4, 7, 10, dan 15 hari)`);
console.log(`✓ ${expandedCases.length} skenario tambahan: tekanan, jarak pandang, awan, arah angin, petir, titik embun, ENSO, MJO, DALR/MALR, gunung, peringatan, dan sumber data`);
console.log('✓ Fallback suhu/kelembapan dari slot per jam dan peringatan kosong tidak disalahartikan sebagai nihil');
console.log('✓ 96 slot jam dan hari ini + 15 hari prakiraan terstruktur');
console.log('✓ Konteks pertanyaan lanjutan (besok → sore)');
console.log('✓ Kode cuaca WMO, arah angin, dan skala AQI terpisah diuji; data kosong tidak diisi angka buatan');
console.log('✓ Tidak ada ketergantungan OpenAI API');
