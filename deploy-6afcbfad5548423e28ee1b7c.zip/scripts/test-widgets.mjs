import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = join(fileURLToPath(new URL('..', import.meta.url)));
const read = path => readFile(join(root, path), 'utf8');
const html = await read('index.html');
const repo = await read('android/app/src/main/java/id/co/fikriweather/app/widgets/WidgetDataRepository.java');
const provider = await read('android/app/src/main/java/id/co/fikriweather/app/widgets/FikriWidgetProvider.java');
const bridge = await read('android/app/src/main/java/id/co/fikriweather/app/widgets/WidgetLocationBridge.java');
const manifest = await read('android/app/src/main/AndroidManifest.xml');
const serviceWorker = await read('service-worker.js');
const pkg = JSON.parse(await read('package.json'));
const activity = await read('android/app/src/main/java/id/co/fikriweather/app/MainActivity.java');

assert.match(html, /Cuaca 4 Hari &amp; 15 Hari|Cuaca 4 Hari & 15 Hari/);
assert.match(html, /Prakiraan 4 Hari/);
assert.match(html, /Hari Ini \+ 15 Hari ke Depan/);
assert.match(html, /hours:96/);
assert.match(html, /S\.data\.slice\(0,96\)/);
assert.match(html, /forecast_days=16/);
assert.match(html, /async function loadFifteenDay\(/);
assert.match(html, /useBMKGCurrent=!!\(nearest&&bmkgAgeMinutes<=90\)/);
assert.doesNotMatch(html, /updateNearestMetar|applyNearestMetar|Observasi METAR WAHI|observasi METAR WAHI/);
assert.match(html, /Airport METAR observations remain available only inside Bandara\/Penerbangan/);

assert.match(repo, /CACHE_TTL_MS = 10 \* 60 \* 1000L/);
assert.match(repo, /Math\.abs\(currentBmkg\.epochMs - now\) <= 90 \* 60 \* 1000L/);
assert.match(repo, /Math\.abs\(bm\.epochMs - target\) <= 20 \* 60 \* 1000L/);
assert.match(repo, /location_mode/);
assert.match(repo, /setUseCaches\(false\)/);
assert.match(repo, /snapshot_location_key/);
assert.doesNotMatch(repo, /java\.time\.|Instant\.|LocalDateTime\./);
assert.match(repo, /api.open-meteo.com/);
assert.match(provider, /ACTION_PREVIOUS/);
assert.match(provider, /WidgetRefreshUtil\.requestAll\(context, true\)/);
assert.match(provider, /applyHazardStyle/);
assert.doesNotMatch(html, /if\(X&&!bm\)\{x\.condition=c;x\.icon=i;\}/);
assert.match(activity, /SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR/);
assert.match(activity, /rgb\(242, 248, 253\)/);
assert.match(provider, /widget_card_warm/);
assert.match(provider, /ACTION_NEXT/);
assert.match(provider, /Math\.min\(8, old \+ 4\)/);
assert.match(bridge, /saveLocation\(double latitude, double longitude, String place, String adm4, String mode\)/);
assert.match(bridge, /requestAll\(appContext, false\)/);
for (const receiver of ['WeatherWidgetProvider','GeoWidgetProvider','ComboWidgetProvider','NowWidgetProvider']) {
  assert.match(manifest, new RegExp(`android:name="\\.widgets\\.${receiver}"`));
}
for (const [file, cell, height] of [
  ['widget_weather_info.xml','2','136dp'],['widget_geo_info.xml','2','136dp'],
  ['widget_combo_info.xml','3','196dp'],['widget_now_info.xml','1','58dp']
]) {
  const xml = await read(`android/app/src/main/res/xml/${file}`);
  assert.match(xml, new RegExp(`android:targetCellWidth="4"`));
  assert.match(xml, new RegExp(`android:targetCellHeight="${cell}"`));
  assert.match(xml, new RegExp(`android:minHeight="${height}"`));
  assert.match(xml, /android:updatePeriodMillis="1800000"/);
}
const weatherLayout = await read('android/app/src/main/res/layout/widget_fikri_weather.xml');
for (const id of ['forecastCard0','forecastCard1','forecastCard2','forecastCard3']) assert.ok(weatherLayout.includes(`@+id/${id}`));
assert.match(weatherLayout, /android:singleLine="true" android:ellipsize="end"/);
assert.match(weatherLayout, /forecastCondition0[^>]*android:textSize="6sp"/);
assert.ok(weatherLayout.includes('android:id="@+id/widgetSource" android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="1dp" android:text="BMKG · data belum tersedia" android:textColor="#64819A" android:textSize="6sp"'));
assert.equal(pkg.version, '2.4.9');
assert.match(serviceWorker, /fikri-weather-shell-v14/);
console.log('WIDGET & FORECAST CHECKS: LULUS');
console.log('✓ Empat widget launcher terdaftar dengan ukuran 4×2, 4×2, 4×3, dan 4×1');
console.log('✓ Pembaruan otomatis 30 menit, tombol refresh dan halaman prakiraan 4 kartu');
console.log('✓ Sinkronisasi BMKG/model dan pembatasan METAR dari ringkasan');
console.log('✓ Prakiraan 96 jam dan hari ini + 15 hari memakai label sumber');
console.log('✓ Lokasi GPS/manual dan invalidasi cache lokasi');
