import assert from 'node:assert/strict';
import vm from 'node:vm';
import { readFile } from 'node:fs/promises';

const html = await readFile(new URL('../index.html', import.meta.url), 'utf8');
const extract = (pattern, label) => {
  const match = html.match(pattern);
  assert.ok(match, `${label} harus tersedia di index.html`);
  return match[0];
};

// Preserve the separate earthquake information card: the felt-earthquake feed must not be mapped to tsunami status.
const originSource = extract(/function quakeOriginDate\(x\)\{[\s\S]*?\n\}/, 'Parser waktu gempa');
const quakeOriginDate = vm.runInNewContext(`${originSource}; quakeOriginDate`);
const origin = quakeOriginDate({ Tanggal: '13 Nov 2026', Jam: '14:31:39 WIB' });
assert.ok(origin && Number.isFinite(origin.getTime()));
const received = new Date('2026-11-13T15:33:36+07:00');
assert.equal(received.getTime() - origin.getTime(), 3_717_000, 'Selisih waktu gempa pada screenshot harus 1 jam 1 menit 57 detik');
const originIso = quakeOriginDate({ DateTime: '2026-11-13T07:31:39Z', Tanggal: '13 Nov 2026', Jam: '14:31:39 WIB' });
assert.equal(originIso.getTime(), origin.getTime());
const tsunamiSource = extract(/function quakeTsunamiLabel\(x\)\{[\s\S]*?\n\}/, 'Parser status tsunami pada panel gempa');
const feltSource = extract(/function quakeFeltLabel\(x\)\{[\s\S]*?\n\}/, 'Parser gempa dirasakan');
const quakeLabels = vm.runInNewContext(`${tsunamiSource}\n${feltSource}; ({quakeTsunamiLabel, quakeFeltLabel})`);
const felt = 'Gempa ini dirasakan untuk diteruskan pada masyarakat';
assert.match(quakeLabels.quakeTsunamiLabel({ Potensi: felt }), /tidak dicantumkan/i);
assert.equal(quakeLabels.quakeFeltLabel({ Potensi: felt }), felt);
assert.equal(quakeLabels.quakeTsunamiLabel({ Potensi: 'Tidak berpotensi tsunami' }), 'Tidak berpotensi tsunami');

console.log('TES REGRESI PANEL GEMPA TERPISAH: LULUS');
console.log('✓ Waktu gempa singkatan bulan WIB dihitung dengan benar');
console.log('✓ Informasi gempa dirasakan tidak dianggap sebagai peringatan tsunami');
console.log('✓ Panel risiko lokasi tidak menggunakan parser ini (diuji pada test-location-risk.mjs)');
