import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { createRequire } from 'node:module';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, '..');
const require = createRequire(import.meta.url);
const mountain = require(path.join(root, 'netlify/functions/mountain-data.js'))._test;
const magmaModule = require(path.join(root, 'netlify/functions/mountain-volcano.js'));
const publicDataModule = require(path.join(root, 'netlify/functions/public-data.js'));
const magma = magmaModule._test;
const html = await readFile(path.join(root, 'index.html'), 'utf8');
const news = await readFile(path.join(root, 'netlify/functions/news.js'), 'utf8');
const backend = await readFile(path.join(root, 'netlify/functions/mountain-data.js'), 'utf8');
const volcanoBackend = await readFile(path.join(root, 'netlify/functions/mountain-volcano.js'), 'utf8');
const volcanoService = await readFile(path.join(root, 'netlify/functions/lib/magma-volcano.cjs'), 'utf8');

// Snapshot structure and status distribution verified from the official MAGMA list on 16 Nov 2026.
const levelRows = [
  ['Level IV (Awas)', []],
  ['Level III (Siaga)', [
    'Anak Krakatau - Lampung',
    'Merapi - Daerah Istimewa Yogyakarta dan Jawa Tengah',
    'Semeru - Jawa Timur'
  ]],
  ['Level II (Waspada)', [
    'Anak Ranakah - Nusa Tenggara Timur', 'Awu - Sulawesi Utara', 'Banda Api - Maluku',
    'Bromo - Jawa Timur', 'Dempo - Sumatera Selatan', 'Dukono - Maluku Utara',
    'Gamalama - Maluku Utara', 'Gamkonora - Maluku Utara', 'Ibu - Maluku Utara',
    'Ili Lewotolok - Nusa Tenggara Timur', 'Iya - Nusa Tenggara Timur',
    'Karangetang - Sulawesi Utara', 'Kerinci - Jambi, Sumatera Barat',
    'Lewotobi Laki-laki - Nusa Tenggara Timur', 'Lokon - Sulawesi Utara',
    'Marapi - Sumatera Barat', 'Raung - Jawa Timur', 'Rinjani - Nusa Tenggara Barat',
    'Sangeangapi - Nusa Tenggara Barat', 'Sinabung - Sumatera Utara',
    'Slamet - Jawa Tengah', 'Soputan - Sulawesi Utara',
    'Sorikmarapi - Sumatera Utara', 'Tambora - Nusa Tenggara Barat'
  ]],
  ['Level I (Normal)', [
    'Agung - Bali', 'Ambang - Sulawesi Utara', 'Arjuno Welirang - Jawa Timur',
    'Batur - Bali', 'Batutara - Nusa Tenggara Timur', 'Bur Ni Telong - Aceh',
    'Ciremai - Jawa Barat', 'Colo - Sulawesi Tengah', 'Dieng - Jawa Tengah',
    'Ebulobo - Nusa Tenggara Timur', 'Egon - Nusa Tenggara Timur',
    'Galunggung - Jawa Barat', 'Gede - Jawa Barat', 'Guntur - Jawa Barat',
    'Hobal - Nusa Tenggara Timur', 'Ijen - Jawa Timur', 'Ile Werung - Nusa Tenggara Timur',
    'Ili Boleng - Nusa Tenggara Timur', 'Inielika - Nusa Tenggara Timur',
    'Inierie - Nusa Tenggara Timur', 'Kaba - Bengkulu', 'Kelimutu - Nusa Tenggara Timur',
    'Kelud - Jawa Timur', 'Kie Besi - Maluku Utara', 'Lamongan - Jawa Timur',
    'Lereboleng - Nusa Tenggara Timur', 'Lewotobi Perempuan - Nusa Tenggara Timur',
    'Mahawu - Sulawesi Utara', 'Papandayan - Jawa Barat', 'Peut Sague - Daerah Istimewa Aceh',
    'Rokatenda - Nusa Tenggara Timur', 'Ruang - Sulawesi Utara', 'Salak - Jawa Barat',
    'Seulawah Agam - Daerah Istimewa Aceh', 'Sirung - Nusa Tenggara Timur',
    'Sumbing - Jawa Tengah', 'Sundoro - Jawa Tengah', 'Talang - Sumatera Barat',
    'Tandikat - Sumatera Barat', 'Tangkoko - Sulawesi Utara',
    'Tangkuban Parahu - Jawa Barat', 'Wurlali - Maluku'
  ]]
];
let counter = 0;
const rows = levelRows.map(([level, names]) => {
  const heading = `<tr><td colspan="3"><a class="tx-inverse tx-14 tx-medium d-block">${level}</a></td></tr>`;
  const entries = names.map(name => `<tr><td>${++counter}</td><td>${name}</td><td><a href="/v1/gunung-api/laporan/${counter}?sig=test">Lihat laporan</a></td></tr>`).join('');
  return heading + entries;
}).join('');
const fixture = `<div class="table-responsive"><table><tbody>${rows}</tbody></table></div>`;
const reports = magma.parseMagma(fixture);
assert.equal(reports.length, 69, 'MAGMA table parser captures all 69 monitored volcano entries in the official list snapshot');
assert.equal(reports.filter(report => report.level === 'Level III (Siaga)').length, 3, 'snapshot has three Level III entries');
assert.equal(reports.filter(report => report.level === 'Level II (Waspada)').length, 24, 'snapshot has twenty-four Level II entries');
assert.equal(reports.filter(report => report.level === 'Level I (Normal)').length, 42, 'snapshot has forty-two Level I entries');
const merapi = reports.find(report => magma.normalize(report.name) === 'merapi');
assert.ok(merapi, 'Merapi row is found in official activity table');
assert.equal(merapi.level, 'Level III (Siaga)', 'Merapi retains Level III (Siaga)');
assert.ok(merapi.reportUrl.includes('/v1/gunung-api/laporan/'), 'Official report link is retained');
assert.ok(reports.find(report => report.name === 'Bromo')?.level.includes('Level II'), 'Bromo remains Level II');
assert.ok(reports.find(report => report.name === 'Sundoro')?.aliases.includes('Sindoro'), 'Sindoro/Sundoro alias is normalized');

const recentFixture = `<html><body>
<div class="timeline-item"><p class="timeline-date">Senin, 16 November 2026</p><div class="timeline-time">12:00-18:00 WIB</div><p class="timeline-title"><a href="/v1/gunung-api/detail/1">Merapi</a> Level III (Siaga)</p><p class="timeline-text">Asap kawah tidak teramati.</p><a class="btn btn-sm btn-outline-primary" href="/v1/gunung-api/laporan/214152?signature=test">Lihat Detail</a></div>
<div class="timeline-item"><p class="timeline-date">Senin, 16 November 2026</p><div class="timeline-time">06:00-12:00 WIB</div><p class="timeline-title"><a href="/v1/gunung-api/detail/2">Ibu</a> Level II (Waspada)</p><p class="timeline-text">Asap kawah rendah.</p><a href="/v1/gunung-api/laporan/214057?signature=test">Lihat Detail</a></div>
${' '.repeat(1100)}</body></html>`;
const recent = magma.parseRecentActivityReports(recentFixture);
assert.equal(recent.length, 2, 'recent MAGMA report parser captures each available current report');
assert.equal(recent.find(item => item.name === 'Merapi')?.level, 'Level III (Siaga)', 'recent report retains the official Merapi level');
assert.ok(recent.find(item => item.name === 'Merapi')?.date?.includes('16 November 2026'), 'recent report retains its official report date');
assert.ok(magma.buildStatus(reports.slice(0, 12)).complete === false, 'partial status lists are never considered complete');

const originalFetch = globalThis.fetch;
try {
  globalThis.fetch = async () => ({ ok: true, text: async () => fixture });
  const response = await magmaModule.handler({ queryStringParameters: {} });
  const payload = JSON.parse(response.body);
  assert.equal(response.statusCode, 200, 'complete PVMBG table is served successfully');
  assert.equal(payload.complete, true, '69-row list is marked complete');
  assert.equal(payload.reports.find(report => report.name === 'Merapi').level, 'Level III (Siaga)');
  magma.clearCacheForTests();
  globalThis.fetch = async url => String(url).includes('/v1/gunung-api/laporan')
    ? ({ ok: true, text: async () => recentFixture })
    : ({ ok: true, text: async () => `<html>${' '.repeat(1100)}</html>` });
  const partialResponse = await magmaModule.handler({ queryStringParameters: {} });
  const partialPayload = JSON.parse(partialResponse.body);
  assert.equal(partialResponse.statusCode, 200, 'official recent-report fallback remains available when full level list cannot be parsed');
  assert.equal(partialPayload.complete, false, 'recent-report fallback is explicitly not a complete country-wide list');
  assert.equal(partialPayload.partial, true, 'recent-report fallback is labelled partial');
  assert.equal(partialPayload.reports.find(report => report.name === 'Merapi')?.level, 'Level III (Siaga)', 'partial fallback still provides a verified report level');
  const partialDetailHtml = `<html><body><h2>Level III (Siaga)</h2><h3>Pengamatan Visual</h3><p>Asap kawah tidak teramati.</p><h3>Keterangan Lainnya</h3><p>${'Rincian resmi. '.repeat(120)}</p><h3>Klimatologi</h3><p>Cuaca cerah.</p><h3>Pengamatan Kegempaan</h3><p>Gempa vulkanik terekam.</p><h3>Rekomendasi</h3><p>Ikuti rekomendasi PVMBG.</p>${' '.repeat(1200)}</body></html>`;
  globalThis.fetch = async url => String(url).includes('/v1/gunung-api/laporan/214152')
    ? ({ ok: true, text: async () => partialDetailHtml })
    : ({ ok: true, text: async () => recentFixture });
  const partialDetailResponse = await magmaModule.handler({ queryStringParameters: { detail: 'Merapi' } });
  const partialDetailPayload = JSON.parse(partialDetailResponse.body);
  assert.equal(partialDetailResponse.statusCode, 200, 'a report in the partial official feed can still open its official detail');
  assert.equal(partialDetailPayload.complete, false, 'a detail opened from a partial feed remains marked incomplete');
  assert.equal(partialDetailPayload.partial, true, 'a detail opened from a partial feed retains its partial-source label');
  assert.equal(partialDetailPayload.report.level, 'Level III (Siaga)', 'detail view retains the official report level');
  const sharedPartialResponse = await publicDataModule.handler({ queryStringParameters: { source: 'volcano' } });
  const sharedPartialPayload = JSON.parse(sharedPartialResponse.body);
  assert.equal(sharedPartialResponse.statusCode, 200, 'the shared public-data endpoint serves the same official volcano feed');
  assert.equal(sharedPartialPayload.partial, true, 'the shared public-data endpoint preserves partial-feed metadata');
  const sharedPartialDetailResponse = await publicDataModule.handler({ queryStringParameters: { source: 'volcano', detail: 'Merapi' } });
  const sharedPartialDetailPayload = JSON.parse(sharedPartialDetailResponse.body);
  assert.equal(sharedPartialDetailResponse.statusCode, 200, 'the shared public-data endpoint can load details from the partial feed');
  assert.equal(sharedPartialDetailPayload.complete, false, 'the shared endpoint does not label partial detail as complete');
  assert.equal(sharedPartialDetailPayload.partial, true, 'the shared endpoint preserves partial detail metadata');
  magma.clearCacheForTests();
assert.equal(magma.buildStatus(reports.slice(0, 12)).complete, false, 'partial PVMBG list is never marked complete');
assert.ok(volcanoService.includes('reports.length >= 60'), 'shared PVMBG service enforces a complete official list');
assert.ok(volcanoBackend.includes('magma.getStatus'), 'dedicated endpoint delegates to the shared PVMBG status service');
assert.ok(html.includes('d.complete===true') && html.includes('d.partial===true'), 'UI accepts complete lists or explicitly partial official reports without promoting partial data to complete');
assert.ok(html.includes('d.reports.length>=60'), 'UI applies the same conservative minimum row count as the service for complete lists');
} finally {
  globalThis.fetch = originalFetch;
}

const flood = mountain.estimateMountainRisk('flood', null, {
  rain24hMm: 125, rain6hMm: 45, slopeDegrees: 4,
  topographicPositionM: -12, nearestWaterMeters: 120, soilMoisture: 0.42
});
assert.equal(flood.status, 'SIAGA', 'high-rain flood screening combines water proximity and local topography');
assert.ok(flood.reasons.length >= 2, 'flood explanation contains supporting indicators');
assert.equal(flood.rainfall6hMm, 45, '6-hour rainfall is preserved');

const landslide = mountain.estimateMountainRisk('landslide', null, {
  rain24hMm: 82, rain6hMm: 30, slopeDegrees: 37,
  topographicPositionM: 6, nearestWaterMeters: null, soilMoisture: 0.40
});
assert.equal(landslide.status, 'SIAGA', 'steep slope, strong rain, and wet soil trigger landslide screening');
const drySteepMerapi = mountain.estimateMountainRisk('landslide', null, {
  slopeDegrees: 37, localReliefM: 90, topographicPositionM: 6
});
assert.equal(drySteepMerapi.status, 'KERENTANAN DASAR TINGGI', 'steep volcanic terrain must not default to NORMAL without rainfall triggers');
assert.ok(drySteepMerapi.susceptibilityScore >= 70, 'steep terrain produces a high baseline susceptibility score');
const wetSteepMerapi = mountain.estimateMountainRisk('landslide', null, {
  slopeDegrees: 37, localReliefM: 90, topographicPositionM: 6,
  rain24hMm: 60, rain6hMm: 5, rain72hMm: 80
});
assert.equal(wetSteepMerapi.status, 'SIAGA', 'steep volcanic terrain and rainfall above the threshold trigger SIAGA');
const dryFlat = mountain.estimateMountainRisk('landslide', null, {
  slopeDegrees: 5, localReliefM: 10, topographicPositionM: 1
});
assert.equal(dryFlat.status, 'NORMAL', 'low-susceptibility terrain without triggers can remain NORMAL');
const valleyFlood = mountain.estimateMountainRisk('flood', null, {
  slopeDegrees: 4, topographicPositionM: -12, nearestWaterMeters: 120,
  rain24hMm: 40, rain6hMm: 12, rain72hMm: 80, soilMoisture: 0.38
});
assert.equal(valleyFlood.status, 'SIAGA', 'low valley near mapped drainage with rain and wet soil raises flood screening');

const itinerary = mountain.computeItinerary(
  [
    { id: 'start', lat: -7.5, lon: 110.4, distanceAlongRouteKm: 0 },
    { id: 'mid', lat: -7.51, lon: 110.41, distanceAlongRouteKm: 1.2 },
    { id: 'summit', lat: -7.52, lon: 110.42, distanceAlongRouteKm: 2.4 }
  ],
  [1500, 1800, 2200],
  '2026-11-16', '01:00', 'Asia/Jakarta', 2
);
assert.equal(itinerary.points[0].arrivalTime, '01:00');
assert.ok(itinerary.points[1].arrivalTime !== '01:00', 'waypoint ETA advances after departure');
assert.ok(itinerary.points[2].arrivalMinutes > itinerary.points[1].arrivalMinutes, 'ETA is cumulative through itinerary');

const mappedPath = mountain.routeFromWay({
  id: 99, type: 'way', tags: { highway: 'path', name: 'Jejak menuju puncak' },
  geometry: [{ lat: -7.4, lon: 110.2 }, { lat: -7.401, lon: 110.201 }, { lat: -7.402, lon: 110.202 }]
});
assert.ok(mappedPath, 'mapped highway=path is accepted for route rendering');
assert.equal(mappedPath.kind, 'Jejak jalur OSM (bukan relasi rute resmi)');
const vehicleTrack = mountain.routeFromWay({ id: 100, type: 'way', tags: { highway: 'track' }, geometry: [{ lat: -7.4, lon: 110.2 }, { lat: -7.401, lon: 110.201 }, { lat: -7.402, lon: 110.202 }] });
assert.equal(vehicleTrack, null, 'unclassified vehicle tracks are not presented as hiking trails');
const footTrack = mountain.routeFromWay({ id: 101, type: 'way', tags: { highway: 'track', foot: 'yes' }, geometry: [{ lat: -7.4, lon: 110.2 }, { lat: -7.401, lon: 110.201 }, { lat: -7.402, lon: 110.202 }] });
assert.ok(footTrack, 'track ways require a mapped pedestrian-access tag or hiking difficulty tag');

assert.ok(!/id="fwMountainPace"/.test(html), 'no walking speed input remains in mountain UI');
assert.ok(html.includes('const fractions=[0,1/7,2/7,3/7,4/7,5/7,6/7,1]'), 'mapped route is sampled at eight points following real route geometry');
assert.ok(html.includes('function routePointsAreaFallback()') && html.includes('radius 600 m'), 'when OSM routes are unavailable, seven clearly labelled area-analysis points are rendered rather than a fake route');
assert.ok(html.includes('fwMountainEnvironmentCoverageNote') && html.includes('TITIK AREA DIANALISIS'), 'the user can identify exactly which point set was analysed');
assert.ok(html.includes('const wildlifeProfile=selected?mountainWildlifeProfiles.find'), 'wildlife warnings also appear in the advice panel');
assert.ok(html.includes('KERENTANAN DASAR TINGGI'), 'high terrain susceptibility can appear as an explicit warning');
assert.ok(html.includes('window.fwGetVolcanoStatus?await window.fwGetVolcanoStatus(false)'), 'mountain UI reuses the shared PVMBG status snapshot');
assert.ok(html.includes("getJson('/.netlify/functions/mountain-volcano'"), 'mountain UI retains the dedicated PVMBG endpoint fallback');
assert.ok(html.includes('d.complete===true') && html.includes('d.partial===true'), 'incomplete PVMBG responses are only displayed as explicitly partial reports, never as NORMAL');
assert.ok(html.includes("limit:'20'"), 'mountain news requests a larger feed');
assert.ok(!/Kecepatan rencana:/.test(html), 'walking speed is not shown in UI');
assert.ok(html.includes('const initialWeather=loadWeather();await Promise.allSettled([routeLoad,initialWeather])'), 'initial weather loads while route lookup runs, avoiding route-search blocking');
assert.ok(backend.includes('tempo pendakian perencanaan internal'), 'ETA description does not refer to a user-selected walking speed');
assert.ok(backend.includes('out body geom;'), 'Overpass route query uses valid geometry output syntax');
assert.ok(backend.includes('pos pendakian|pos registrasi|gerbang pendakian'), 'Route lookup also checks mapped basecamp/entry access objects');
assert.ok(backend.includes('routing.openstreetmap.de/routed-foot'), 'Walking route fallback requires a successful OSM foot-network geometry');
assert.ok(backend.includes('relation(17254520);relation(17254538);relation(17254521);'), 'Merapi fallback requests the three verified OSM hiking relations by ID instead of inventing a route');
assert.ok(backend.includes("routed?.code === 'Ok'"), 'No synthetic route line is accepted without a successful router result');
assert.ok(backend.includes('out center tags;'), 'Overpass search/water query uses valid center output syntax');
assert.ok(news.includes('PVMBG MAGMA aktivitas status gunung api'), 'mountain news covers volcanic activity');
assert.ok(news.includes('jalur pendakian gunung dibuka ditutup'), 'mountain news covers route openings and closures');
assert.ok(news.includes('kecelakaan cuaca ekstrem evakuasi'), 'mountain news covers incidents and safety');

console.log('Mountain accuracy regression tests passed: current-format PVMBG parser, ETA, OSM paths, water/hazard screening, UI, and mountain news.');
