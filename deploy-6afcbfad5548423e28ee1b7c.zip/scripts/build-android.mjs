import { spawnSync } from 'node:child_process';
import { existsSync } from 'node:fs';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(fileURLToPath(new URL('..', import.meta.url)));
const rawUrl = String(process.env.FW_SITE_URL || '').trim();
if (!rawUrl) {
  console.error('FW_SITE_URL wajib diisi, contoh: https://fikri-weather.netlify.app');
  process.exit(1);
}
let site;
try { site = new URL(rawUrl); } catch {
  console.error('FW_SITE_URL bukan alamat yang valid.');
  process.exit(1);
}
if (site.protocol !== 'https:' || !site.hostname || site.username || site.password || site.search || site.hash || !['', '/'].includes(site.pathname)) {
  console.error('Gunakan origin HTTPS website saja, tanpa path, query, atau fragmen.');
  process.exit(1);
}

const androidDir = resolve(root, 'android');
if (!existsSync(resolve(androidDir, 'app/src/main/java/id/co/fikriweather/app/MainActivity.java'))) {
  console.error('Proyek Android tidak lengkap: MainActivity.java tidak ditemukan.');
  process.exit(1);
}
if (Number(process.versions.node.split('.')[0]) < 22) {
  console.error('Gunakan Node.js 22 atau lebih baru.');
  process.exit(1);
}

const gradle = process.platform === 'win32' ? 'gradle.bat' : 'gradle';
console.log(`Membangun Fikri Weather untuk website: ${site.origin}`);
const result = spawnSync(gradle, ['--no-daemon', 'assembleDebug'], {
  cwd: root,
  stdio: 'inherit',
  env: { ...process.env, FW_SITE_URL: site.origin },
  shell: process.platform === 'win32'
});
if (result.error) throw result.error;
if (result.status !== 0) process.exit(result.status || 1);
const apk = resolve(androidDir, 'app/build/outputs/apk/debug/app-debug.apk');
if (!existsSync(apk)) {
  console.error('Gradle selesai tetapi APK tidak ditemukan.');
  process.exit(1);
}
console.log(`\nAPK berhasil dibuat: ${apk}`);
