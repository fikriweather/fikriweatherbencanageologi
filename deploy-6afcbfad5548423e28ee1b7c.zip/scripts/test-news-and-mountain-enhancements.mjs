import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { createRequire } from 'node:module';
import { resolve } from 'node:path';

const root = resolve(new URL('..', import.meta.url).pathname);
const require = createRequire(import.meta.url);
const mountain = require(resolve(root, 'netlify/functions/mountain-data.js'))._test;
const news = require(resolve(root, 'netlify/functions/news.js'))._test;
const html = await readFile(resolve(root, 'index.html'), 'utf8');

// Itinerary time uses the route's cumulative mapped distance, not straight-line chords.
const points = [
  { lat: -7.5, lon: 110.4, distanceAlongRouteKm: 0 },
  { lat: -7.51, lon: 110.42, distanceAlongRouteKm: 2 },
  { lat: -7.52, lon: 110.44, distanceAlongRouteKm: 3 }
];
const itinerary = mountain.computeItinerary(points, [1000, 1600, 1200], '2026-11-15', '06:00', 'Asia/Jakarta', 2);
assert.equal(itinerary.summary.totalDistanceKm, 3);
assert.equal(itinerary.summary.positiveAscentM, 600);
assert.equal(itinerary.points[0].arrivalTime, '06:00');
assert.equal(itinerary.points[1].arrivalTime, '08:00');
assert.equal(itinerary.points[2].arrivalTime, '08:30');
assert.equal(itinerary.points[2].segmentDistanceKm, 1);
assert.equal(mountain.addLocalMinutes('2026-11-15', '23:00', 120).date, '2026-11-16');
assert.equal(mountain.addLocalMinutes('2026-11-15', '23:00', 120).time, '01:00');

// Static InaRISK susceptibility must not be mistaken for an active alert.
assert.equal(mountain.classifyBaseline(0.1).status, 'RENDAH');
assert.equal(mountain.classifyBaseline(0.5).status, 'SEDANG');
assert.equal(mountain.classifyBaseline(0.9).status, 'TINGGI');
assert.equal(mountain.combineMountainRisk(0.9, null).status, 'KERAWANAN DASAR TINGGI');
assert.equal(mountain.combineMountainRisk(0.9, 30).status, 'BERPOTENSI');
assert.equal(mountain.combineMountainRisk(0.9, 60).status, 'SIAGA');
assert.equal(mountain.combineMountainRisk(0.5, 30).status, 'BERPOTENSI');
assert.equal(mountain.combineMountainRisk(0.5, 60).status, 'BERPOTENSI');
assert.equal(mountain.combineMountainRisk(0.5, 110).status, 'SIAGA');
assert.equal(mountain.combineMountainRisk(0.1, 10).status, 'NORMAL');
assert.match(mountain.combineMountainRisk(null, 60).status, /DATA INARISK TIDAK TERSEDIA/);
assert.equal(mountain.combineMountainRisk(null, null).status, 'DATA TIDAK TERSEDIA');

// RSS parser keeps source identity, timestamp, direct article link and official-source marker.
const xml = `<?xml version="1.0"?><rss><channel><item><title>BMKG &amp; Hujan Lebat</title><link>https://news.google.com/rss/articles/example</link><description><![CDATA[<p>Prakiraan hujan di sejumlah wilayah.</p>]]></description><pubDate>Sun, 15 Nov 2026 10:00:00 GMT</pubDate><source url="https://www.bmkg.go.id/">BMKG</source></item></channel></rss>`;
const parsed = news.parseFeed(xml, 'cuaca');
assert.equal(parsed.length, 1);
assert.equal(parsed[0].title, 'BMKG & Hujan Lebat');
assert.equal(parsed[0].publisher, 'BMKG');
assert.equal(parsed[0].domain, 'bmkg.go.id');
assert.equal(parsed[0].official, true);
const withImage = news.parseFeed(xml.replace('</source>', '</source><media:content url="https://cdn.example.test/photo.jpg" type="image/jpeg" />'), 'cuaca');
assert.equal(withImage[0].image, 'https://cdn.example.test/photo.jpg');
assert.match(parsed[0].summary, /Prakiraan hujan/);
assert.equal(news.queries('semua', '', '').length, 3);

// The two new news surfaces and the mountain additions are present and wired.
for (const marker of [
  'data-page="news"', 'id="news"', 'id="fwSummaryWeatherNews"', 'id="fwSummaryDisasterNews"',
  'id="fwNewsCategory"', 'id="fwNewsRegion"', 'id="fwNewsSearch"', 'id="fwNewsList"',
  'id="fwMountainNewsLoad"', 'id="fwMountainHazardPoints"', 'id="fwMountainWildlife"',
  'action:\'hazards\'', 'distanceAlongRouteKm', 'Macan tutul Jawa', 'susceptibilityScore',
  'BELUM TERVERIFIKASI', 'NORMAL</span>'
]) assert.ok(html.includes(marker), `Missing implementation marker: ${marker}`);
const runtime = html.match(/<script id="fw-news-runtime">([\s\S]*?)<\/script>/);
assert.ok(runtime, 'News UI runtime is missing');
assert.match(runtime[1], /loadSummaryNews/);
assert.match(runtime[1], /loadNewsPage/);
assert.match(runtime[1], /Promise\.allSettled/);
assert.equal((html.match(/function routeDifficultyLabel\(/g) || []).length, 1, 'Route difficulty helper should not be duplicated');
assert.ok(!html.includes('fwMountainWaterPoints'), 'Water storage card is removed from mountain UI');
assert.ok(!html.includes('fwMountainEnvironmentBtn'), 'Water analysis button is removed from mountain UI');
assert.match(html, /void analyzeMountainEnvironment\(\)/, 'Hazard analysis starts automatically after per-point forecasts load');
assert.match(html, /fw-mountain-risk-box/, 'Risk panel renders compact per-point risk scores');
assert.match(html, /function riskColor\(status\)/, 'Topographic map pins use hazard risk colors');
assert.match(html, /rain72hMm:num\(r\.hour\?\.precipitation_72h\)/, '72-hour rainfall is sent to the hazard screen');
assert.ok(!html.includes('BMKG cocok untuk'), 'The old BMKG match-count sentence is removed');
assert.match(html, /BELUM TERVERIFIKASI/, 'Unmatched volcano status is not guessed as Level I');

// New function rejects unsupported categories rather than returning invented content.
const invalid = await require(resolve(root, 'netlify/functions/news.js')).handler({ queryStringParameters: { category: 'invented' } });
assert.equal(invalid.statusCode, 400);

console.log('UJI BERITA & PENGEMBANGAN CUACA GUNUNG: LULUS');
console.log('✓ ETA mengikuti jarak sepanjang jalur dan perubahan elevasi yang tersedia');
console.log('✓ Kategori InaRISK dibedakan dari pemicu hujan; data hilang tidak diubah menjadi nol');
console.log('✓ Parser berita menyimpan penerbit, tautan, tanggal, dan penanda sumber resmi');
console.log('✓ Ringkasan, menu BERITA, berita gunung, analisis risiko per titik dan peringatan satwa tersedia');
console.log('✓ Handler berita menolak kategori tidak dikenal');
