'use strict';

const CACHE = new Map();
const json = (statusCode, body, cache = 'no-store') => ({
  statusCode,
  headers: {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': cache,
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
    'X-Content-Type-Options': 'nosniff'
  },
  body: JSON.stringify(body)
});
const finite = value => value !== null && value !== undefined && value !== '' && Number.isFinite(Number(value));
const number = value => finite(value) ? Number(value) : null;
const isoHour = ms => new Date(ms).toISOString().slice(0, 13) + ':00';
const ADM4_RE = /^\d{2}\.\d{2}\.\d{2}\.\d{4}$/;

function validatePoint(point, index, now) {
  if (!point || typeof point !== 'object') throw new Error(`Titik ${index + 1} tidak valid.`);
  const lat = number(point.lat), lon = number(point.lon), eta = Date.parse(point.eta);
  if (lat === null || lon === null || Math.abs(lat) > 90 || Math.abs(lon) > 180) {
    throw new Error(`Koordinat titik ${index + 1} tidak valid.`);
  }
  if (lat < -12.5 || lat > 7.5 || lon < 93 || lon > 143) {
    throw new Error(`Titik ${index + 1} berada di luar cakupan rute Indonesia.`);
  }
  if (!Number.isFinite(eta) || eta < now - 30 * 60 * 1000 || eta > now + 10 * 86400000) {
    throw new Error(`Waktu titik ${index + 1} harus berada dari 30 menit lalu hingga 10 hari ke depan.`);
  }
  const adm4 = ADM4_RE.test(String(point.adm4 || '')) ? String(point.adm4) : null;
  return { id: String(point.id || `R${index + 1}`).slice(0, 24), lat, lon, eta, eta_iso: new Date(eta).toISOString(), adm4 };
}

async function fetchModel(points, model) {
  const params = new URLSearchParams({
    latitude: points.map(point => point.lat.toFixed(4)).join(','),
    longitude: points.map(point => point.lon.toFixed(4)).join(','),
    hourly: 'temperature_2m,relative_humidity_2m,apparent_temperature,precipitation_probability,precipitation,weather_code,wind_speed_10m,wind_direction_10m,wind_gusts_10m,visibility,cloud_cover,pressure_msl',
    forecast_days: '10',
    timezone: 'UTC',
    wind_speed_unit: 'kmh'
  });
  if (model?.id) params.set('models', model.id);
  const response = await fetch(`https://api.open-meteo.com/v1/forecast?${params}`, {
    headers: { Accept: 'application/json', 'User-Agent': 'FikriWeather/2.4.4 road-route-weather' },
    signal: AbortSignal.timeout(22000)
  });
  if (!response.ok) throw new Error(`${model?.name || 'Best Match'} HTTP ${response.status}`);
  const raw = await response.json();
  const list = Array.isArray(raw) ? raw : [raw];
  if (list.length !== points.length) throw new Error('Jumlah titik respons prakiraan tidak cocok dengan rute.');
  return list;
}

function findHour(hourly, targetMs) {
  const times = Array.isArray(hourly?.time) ? hourly.time : [];
  let bestIndex = -1, bestDelta = Infinity;
  for (let i = 0; i < times.length; i++) {
    const parsed = Date.parse(`${times[i]}Z`);
    if (!Number.isFinite(parsed)) continue;
    const delta = Math.abs(parsed - targetMs);
    if (delta < bestDelta) { bestDelta = delta; bestIndex = i; }
  }
  if (bestIndex < 0 || bestDelta > 90 * 60 * 1000) return null;
  return { index: bestIndex, time: times[bestIndex], delta_minutes: Math.round(bestDelta / 60000) };
}

function fieldValue(hourly, field, index) { return number(hourly?.[field]?.[index]); }
function bmkgTimestamp(row) {
  const utc = String(row?.utc_datetime || '').trim();
  const local = String(row?.local_datetime || '').trim();
  if (utc) return Date.parse(/(?:Z|[+-]\d{2}:?\d{2})$/i.test(utc) ? utc.replace(' ', 'T') : utc.replace(' ', 'T') + 'Z');
  if (local) return Date.parse(/(?:Z|[+-]\d{2}:?\d{2})$/i.test(local) ? local.replace(' ', 'T') : local.replace(' ', 'T') + '+07:00');
  return NaN;
}
function parseBmkg(payload) {
  return (payload?.data || []).flatMap(item => Array.isArray(item?.cuaca) ? item.cuaca.flat() : []).map(row => ({
    at: bmkgTimestamp(row),
    temp: number(row?.t),
    humidity: number(row?.hu),
    wind: number(row?.ws),
    windDirection: String(row?.wd || '').trim(),
    condition: /\bgerimis\b|\bdrizzle\b/i.test(String(row?.weather_desc || '')) ? 'Mendung' : String(row?.weather_desc || '').trim(),
    conditionRaw: String(row?.weather_desc || '').trim(),
    visibility: String(row?.vs_text || '').trim(),
    cloud: number(row?.tcc),
    source: 'BMKG'
  })).filter(row => Number.isFinite(row.at));
}
function nearestBmkg(rows, targetMs) {
  if (!rows?.length) return null;
  let previous = null, previousMs = -Infinity, nearest = null, delta = Infinity;
  for (const row of rows) {
    if (row.at <= targetMs && row.at > previousMs) { previous = row; previousMs = row.at; }
    const d = Math.abs(row.at - targetMs);
    if (d < delta) { delta = d; nearest = row; }
  }
  if (previous && targetMs - previousMs <= 3 * 3600000) return previous;
  return delta <= 90 * 60000 ? nearest : null;
}
async function fetchBmkg(adm4) {
  const response = await fetch(`https://api.bmkg.go.id/publik/prakiraan-cuaca?adm4=${encodeURIComponent(adm4)}`, {
    headers: { Accept: 'application/json', 'User-Agent': 'FikriWeather/2.4.4 route-weather BMKG-priority' },
    signal: AbortSignal.timeout(9000)
  });
  if (!response.ok) throw new Error(`BMKG HTTP ${response.status}`);
  return parseBmkg(await response.json());
}
function weatherTextFromCode(code) {
  if (code === null || code === undefined || code === '') return null;
  const c = Number(code);
  if (c === 0) return 'Cerah';
  if (c === 1 || c === 2) return 'Cerah berawan';
  if (c === 3) return 'Berawan';
  if (c === 45 || c === 48) return 'Berkabut';
  if ([51, 53, 55, 56, 57].includes(c)) return 'Mendung';
  if ([61, 63, 65, 66, 67, 80, 81, 82].includes(c)) return 'Hujan';
  if ([95, 96, 99].includes(c)) return 'Hujan disertai petir';
  return 'Kondisi tidak diketahui';
}
function visibilityMeters(text) {
  const raw = String(text || '').trim().toLowerCase();
  if (!raw || /tidak diketahui|unknown|tidak tersedia/.test(raw)) return null;
  const match = raw.replace(',', '.').match(/[0-9]+(?:\.[0-9]+)?/);
  if (!match) return null;
  const value = Number(match[0]);
  if (!Number.isFinite(value)) return null;
  return /km/.test(raw) ? value * 1000 : value;
}

exports.handler = async event => {
  if (event.httpMethod === 'OPTIONS') return json(204, {});
  if (event.httpMethod && event.httpMethod !== 'POST') return json(405, { ok: false, error: 'Gunakan metode POST untuk analisis cuaca perjalanan darat.' });

  let body;
  try { body = JSON.parse(event.body || '{}'); }
  catch { return json(400, { ok: false, error: 'Isi permintaan bukan JSON yang valid.' }); }

  const incoming = body?.points;
  if (!Array.isArray(incoming) || incoming.length < 2 || incoming.length > 48) {
    return json(400, { ok: false, error: 'Rute memerlukan 2 sampai 48 titik cuaca.' });
  }
  const now = Date.now();
  let points;
  try { points = incoming.map((point, index) => validatePoint(point, index, now)); }
  catch (error) { return json(400, { ok: false, error: error.message }); }

  const cacheKey = points.map(point => `${point.lat.toFixed(3)},${point.lon.toFixed(3)},${isoHour(point.eta)}:${point.adm4 || '-'}`).join('|');
  const cached = CACHE.get(cacheKey);
  if (cached && now - cached.at < 5 * 60 * 1000) {
    return json(200, { ...cached.value, meta: { ...cached.value.meta, cache: 'hit' } }, 'public, max-age=120, stale-while-revalidate=120');
  }

  const models = [
    { id: null, name: 'Best Match' },
    { id: 'ecmwf_ifs025', name: 'ECMWF IFS' },
    { id: 'gfs_seamless', name: 'NCEP GFS' }
  ];
  const codes = [...new Set(points.map(point => point.adm4).filter(Boolean))];
  const [modelSettled, bmkgSettled] = await Promise.all([
    Promise.allSettled(models.map(model => fetchModel(points, model))),
    Promise.allSettled(codes.map(async code => [code, await fetchBmkg(code)]))
  ]);
  const usable = modelSettled.map((result, index) => result.status === 'fulfilled'
    ? { model: models[index], data: result.value }
    : null).filter(Boolean);
  const bmkgByCode = new Map();
  bmkgSettled.forEach(result => { if (result.status === 'fulfilled') bmkgByCode.set(result.value[0], result.value[1]); });

  if (!usable.length && !bmkgByCode.size) {
    return json(502, {
      ok: false,
      error: 'BMKG dan seluruh model cuaca rute tidak berhasil diakses. Tidak ada cuaca yang dibuat atau ditebak.',
      details: {
        models: modelSettled.map((result, index) => ({ name: models[index].name, ok: result.status === 'fulfilled' })),
        bmkgCodes: codes.map((code, index) => ({ code, ok: bmkgSettled[index]?.status === 'fulfilled' }))
      }
    });
  }

  const output = points.map((point, pointIndex) => {
    const candidates = usable.map(item => ({
      item,
      hourly: item.data[pointIndex]?.hourly || {},
      slot: findHour(item.data[pointIndex]?.hourly, point.eta)
    })).filter(candidate => candidate.slot);
    const selected = candidates.find(candidate => candidate.item.model.id === null) || candidates[0] || null;
    const slot = selected?.slot || null;
    const chosenHourly = selected?.hourly || {};
    const idx = slot?.index ?? -1;
    const modelField = field => {
      for (const candidate of candidates) {
        const value = fieldValue(candidate.hourly, field, candidate.slot.index);
        if (value !== null) return { value, source: candidate.item.model.name };
      }
      return { value: null, source: null };
    };
    const probabilities = [];
    for (const result of usable) {
      const hourly = result.data[pointIndex]?.hourly || {};
      const matched = findHour(hourly, point.eta);
      if (!matched) continue;
      const probability = fieldValue(hourly, 'precipitation_probability', matched.index);
      if (probability !== null && probability >= 0 && probability <= 100) probabilities.push({ name: result.model.name, value: Math.round(probability) });
    }
    const probabilityValues = probabilities.map(item => item.value);
    const probability = probabilityValues.length
      ? Math.round(probabilityValues.reduce((sum, value) => sum + value, 0) / probabilityValues.length)
      : null;

    const bmkgRows = point.adm4 ? bmkgByCode.get(point.adm4) : null;
    const bmkg = nearestBmkg(bmkgRows, point.eta);
    const temperatureModel = modelField('temperature_2m');
    const humidityModel = modelField('relative_humidity_2m');
    const apparentModel = modelField('apparent_temperature');
    const precipitationModel = modelField('precipitation');
    const weatherCodeModel = modelField('weather_code');
    const windModel = modelField('wind_speed_10m');
    const windDirectionModel = modelField('wind_direction_10m');
    const windGustModel = modelField('wind_gusts_10m');
    const visibilityModel = modelField('visibility');
    const cloudModel = modelField('cloud_cover');
    const pressureModel = modelField('pressure_msl');

    // Official BMKG village forecast wins for every field it actually publishes.
    // A missing BMKG field/time is completed by the available numerical weather model.
    const temperature = bmkg?.temp ?? temperatureModel.value;
    const humidity = bmkg?.humidity ?? humidityModel.value;
    const wind = bmkg?.wind ?? windModel.value;
    const cloud = bmkg?.cloud ?? cloudModel.value;
    const visibility = visibilityMeters(bmkg?.visibility) ?? visibilityModel.value;
    const condition = bmkg?.condition || weatherTextFromCode(weatherCodeModel.value);
    const apparent = apparentModel.value;
    const fieldSources = {
      condition: bmkg?.condition ? 'BMKG' : weatherCodeModel.source,
      temperature: bmkg?.temp !== null && bmkg?.temp !== undefined ? 'BMKG' : temperatureModel.source,
      humidity: bmkg?.humidity !== null && bmkg?.humidity !== undefined ? 'BMKG' : humidityModel.source,
      wind: bmkg?.wind !== null && bmkg?.wind !== undefined ? 'BMKG' : windModel.source,
      cloud: bmkg?.cloud !== null && bmkg?.cloud !== undefined ? 'BMKG' : cloudModel.source,
      visibility: visibilityMeters(bmkg?.visibility) !== null ? 'BMKG' : visibilityModel.source,
      apparent_temperature: apparentModel.source,
      probability: probabilities.length ? probabilities.map(item => item.name).join(' + ') : null,
      precipitation: precipitationModel.source,
      pressure: pressureModel.source,
      wind_direction: bmkg?.windDirection ? 'BMKG' : windDirectionModel.source,
      wind_gust: windGustModel.source
    };
    const available = [temperature, humidity, wind, cloud, visibility, probability, precipitationModel.value, weatherCodeModel.value, bmkg?.condition].some(value => value !== null && value !== undefined && value !== '');
    return {
      id: point.id,
      lat: point.lat,
      lon: point.lon,
      eta: point.eta_iso,
      available,
      forecast_time_utc: slot ? `${slot.time}:00Z` : (bmkg ? new Date(bmkg.at).toISOString() : null),
      slot_delta_minutes: slot?.delta_minutes ?? (bmkg ? Math.round(Math.abs(bmkg.at - point.eta) / 60000) : null),
      temperature_c: temperature,
      apparent_temperature_c: apparent,
      relative_humidity_pct: humidity,
      precipitation_probability_pct: probability,
      precipitation_mm: precipitationModel.value,
      weather_code: weatherCodeModel.value,
      condition,
      wind_speed_kmh: wind,
      wind_direction: bmkg?.windDirection || (windDirectionModel.value === null ? null : `${Math.round(windDirectionModel.value)}°`),
      wind_direction_deg: windDirectionModel.value,
      wind_gust_kmh: windGustModel.value,
      visibility_m: visibility,
      cloud_cover_pct: cloud,
      pressure_hpa: pressureModel.value,
      field_sources: fieldSources,
      probability_models: probabilities,
      probability_range_pct: probabilityValues.length >= 2 ? { min: Math.min(...probabilityValues), max: Math.max(...probabilityValues) } : null,
      probability_method: probabilityValues.length >= 2 ? 'mean' : probabilityValues.length === 1 ? 'single' : 'none',
      selected_model: bmkg ? 'BMKG + model pelengkap' : (selected?.item.model.name || 'BMKG'),
      bmkg_adm4: bmkg ? point.adm4 : null,
      data_note: bmkg ? 'Variabel yang diterbitkan BMKG diprioritaskan; peluang/akumulasi hujan dilengkapi model.' : 'Prakiraan model pada koordinat jalan; bukan observasi langsung.'
    };
  });

  const value = {
    ok: true,
    points: output,
    meta: {
      source: 'BMKG (bila kode ADM4 terverifikasi) + Open-Meteo multi-model',
      models_used: usable.map(item => item.model.name),
      bmkg_codes_used: [...bmkgByCode.keys()],
      fetched_at: new Date().toISOString(),
      timezone_for_lookup: 'UTC',
      note: 'Prakiraan per jam pada koordinat rute jalan. BMKG lokal dipakai untuk ADM4 yang sudah diketahui dan variabel yang diterbitkan; model mengisi slot/variabel yang tidak tersedia. Bukan observasi hujan tepat di jalan.'
    }
  };
  CACHE.set(cacheKey, { at: now, value });
  if (CACHE.size > 220) CACHE.delete(CACHE.keys().next().value);
  return json(200, value, 'public, max-age=120, stale-while-revalidate=120');
};

exports._test = { parseBmkg, weatherTextFromCode };
