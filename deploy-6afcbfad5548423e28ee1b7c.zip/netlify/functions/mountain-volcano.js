'use strict';

const magma = require('./lib/magma-volcano.cjs');

const json = (statusCode, body, cache = 'no-store') => ({
  statusCode,
  headers: {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': cache,
    'Access-Control-Allow-Origin': '*',
    'X-Content-Type-Options': 'nosniff'
  },
  body: JSON.stringify(body)
});

exports._test = {
  normalize: magma.normalize,
  htmlText: magma.htmlText,
  cleanLevel: magma.cleanLevel,
  parseNameRegion: magma.parseNameRegion,
  parseMagmaTable: magma.parseMagmaTable,
  parseMagmaAnchors: magma.parseMagmaAnchors,
  parseMagma: magma.parseMagma,
  parseRecentActivityReports: magma.parseRecentActivityReports,
  buildStatus: magma.buildStatus,
  clearCacheForTests: magma.clearCacheForTests
};

exports.handler = async event => {
  const detailName = String(event.queryStringParameters?.detail || '').trim();
  try {
    const status = await magma.getStatus({ force: String(event.queryStringParameters?.refresh || '') === '1' });
    if (detailName) {
      const report = magma.findReport(status.reports, detailName);
      if (!report) return json(404, {
        ok: false,
        error: `${detailName} tidak tercantum pada daftar tingkat aktivitas PVMBG/MAGMA yang berhasil dibaca.`,
        source: status.source,
        fetchedAt: status.fetchedAt,
        complete: !!status.complete,
        partial: !!status.partial
      }, 'no-store');
      let detail = null;
      try { detail = await magma.getReportDetail(report); }
      catch (error) { detail = { detailError: 'Rincian laporan belum berhasil dibaca; status tingkat aktivitas tetap mengikuti daftar resmi.', sourceError: String(error.message || error).slice(0, 180) }; }
      return json(200, {
        ok: true,
        source: status.source,
        sourceUrl: status.sourceUrl,
        fetchedAt: status.fetchedAt,
        stale: !!status.stale,
        report,
        detail,
        complete: !!status.complete,
        partial: !!status.partial
      }, 'public, max-age=60, stale-while-revalidate=180');
    }
    return json(200, status, 'public, max-age=60, stale-while-revalidate=180');
  } catch (error) {
    return json(502, {
      ok: false,
      complete: false,
      source: 'PVMBG/MAGMA Indonesia',
      error: 'Sambungan ke daftar tingkat aktivitas resmi PVMBG/MAGMA belum berhasil.',
      detail: String(error.message || error).slice(0, 320),
      sourceUrl: magma.STATUS_URL
    }, 'no-store');
  }
};
