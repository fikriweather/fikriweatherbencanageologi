'use strict';
const CACHE=new Map();let lastNominatimAt=0;let queue=Promise.resolve();
const json=(statusCode,body,cache='public, max-age=600')=>({statusCode,headers:{'Content-Type':'application/json; charset=utf-8','Cache-Control':cache,'Access-Control-Allow-Origin':'*','X-Content-Type-Options':'nosniff'},body:JSON.stringify(body)});
exports.handler=async event=>{
 const q=String(event.queryStringParameters?.q||'').trim().slice(0,120);
 if(q.length<2)return json(400,{error:'Masukkan minimal dua karakter.'},'no-store');
 const cacheKey=q.toLocaleLowerCase('id-ID');const cached=CACHE.get(cacheKey);if(cached&&Date.now()-cached.at<15*60*1000)return json(200,cached.data,'public, max-age=600, stale-while-revalidate=300');
 try{
  const url='https://nominatim.openstreetmap.org/search?'+new URLSearchParams({format:'jsonv2',q,countrycodes:'id',addressdetails:'1',limit:'10','accept-language':'id'}).toString();
  const request=async()=>{const wait=Math.max(0,1000-(Date.now()-lastNominatimAt));if(wait)await new Promise(resolve=>setTimeout(resolve,wait));lastNominatimAt=Date.now();return fetch(url,{headers:{'User-Agent':'FikriWeather/3.0 (Indonesian location search)','Accept-Language':'id'},signal:AbortSignal.timeout(6500)});};
  const pending=queue.then(request,request);queue=pending.then(()=>undefined,()=>undefined);const r=await pending;
  if(!r.ok)throw new Error(`HTTP ${r.status}`);
  const rows=await r.json();
  const results=(Array.isArray(rows)?rows:[]).filter(x=>Number.isFinite(Number(x.lat))&&Number.isFinite(Number(x.lon))).map(x=>{
   const a=x.address||{};const province=a.state||a.province||'';const regency=a.city||a.municipality||a.county||a.state_district||'';const district=a.city_district||a.district||a.subdistrict||'';const name=a.village||a.hamlet||a.suburb||a.neighbourhood||a.quarter||a.town||a.city_district||a.city||x.name||x.display_name?.split(',')[0]||'Lokasi';
   return {name,display_name:x.display_name||[name,district,regency,province].filter(Boolean).join(', '),latitude:Number(x.lat),longitude:Number(x.lon),district,regency,province,country:'Indonesia',country_code:'ID'};
  });
  const data={ok:true,results,source:'OpenStreetMap Nominatim'};CACHE.set(cacheKey,{at:Date.now(),data});if(CACHE.size>500)CACHE.delete(CACHE.keys().next().value);return json(200,data);
 }catch(e){return json(502,{ok:false,error:'Pencarian wilayah Indonesia sedang tidak tersedia.',results:[]},'no-store');}
};
