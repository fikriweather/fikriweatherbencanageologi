'use strict';
const {
  response, cookieHeaders, setSessionCookie, clearSessionCookie, parseBody,
  createSession, getSession, destroySession, timingSafeTextEqual,
} = require('./lib/fw-server.cjs');

exports.handler = async event => {
  const cors = cookieHeaders(event);
  try {
    if (event.httpMethod === 'OPTIONS') return { statusCode: 204, headers: { ...cors, 'Access-Control-Allow-Methods': 'GET,POST,DELETE,OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type' }, body: '' };
    if (event.httpMethod === 'GET') {
      const s = await getSession(event);
      return response(200, s?.role === 'admin' ? { ok: true, username: 'Admin Fikri Weather' } : { ok: false }, cors);
    }
    if (event.httpMethod === 'DELETE') {
      await destroySession(event);
      return response(200, { ok: true }, { ...cors, 'Set-Cookie': clearSessionCookie });
    }
    if (event.httpMethod !== 'POST') return response(405, { error: 'Metode tidak didukung.' }, cors);
    const body = parseBody(event);
    const code = String(body.code || '').trim();
    const configuredCode = process.env.ADMIN_SECRET_CODE || '';
    if (!configuredCode) return response(503, { error: 'Kode admin belum dikonfigurasi. Set ADMIN_SECRET_CODE di environment Netlify.' }, cors);
    if (!code || !timingSafeTextEqual(code, configuredCode)) {
      await new Promise(resolve => setTimeout(resolve, 550));
      return response(401, { ok: false, error: 'Kode rahasia tidak cocok.' }, cors);
    }
    const token = await createSession({ principal: 'admin-fikri-weather', role: 'admin' });
    return response(200, { ok: true, username: 'Admin Fikri Weather' }, { ...cors, 'Set-Cookie': setSessionCookie(token) });
  } catch (e) {
    return response(e.statusCode || 500, { error: e.message || 'Login admin gagal.' }, cors);
  }
};
