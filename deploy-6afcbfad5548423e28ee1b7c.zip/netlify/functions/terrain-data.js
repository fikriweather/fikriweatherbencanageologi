'use strict';
const CACHE = new Map();
const TTL_MS = 12 * 60 * 60 * 1000;
const json = (statusCode, body, cache = 'no-store') => ({
  statusCode,
  headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': cache, 'Access-Control-Allow-Origin': '*', 'X-Content-Type-Options': 'nosniff' },
  body: JSON.stringify(body)
});
const validPoint = p => Number.isFinite(p.lat) && Number.isFinite(p.lon) && p.lat >= -11.5 && p.lat <= 6.8 && p.lon >= 94 && p.lon <= 142;
async function queryTopo(dataset, points) {
  const locations = points.map(p => `${p.lat},${p.lon}`).join('|');
  const url = `https://api.opentopodata.org/v1/${dataset}?locations=${encodeURIComponent(locations)}`;
  const response = await fetch(url, { headers: { Accept: 'application/json', 'User-Agent': 'FikriWeather/4.0 terrain fallback' }, signal: AbortSignal.timeout(6500) });
  if (!response.ok) throw new Error(`${dataset} HTTP ${response.status}`);
  const payload = await response.json();
  const values = Array.isArray(payload.results) ? payload.results.map(x => x?.elevation == null ? null : Number(x.elevation)) : [];
  if (values.length !== points.length || values.some(x => !Number.isFinite(x))) throw new Error(`${dataset} tidak mengembalikan semua titik elevasi`);
  return values;
}
exports._test = { validPoint };
exports.handler = async event => {
  const raw = String(event.queryStringParameters?.points || '');
  const points = raw.split('|').map(pair => { const [lat, lon] = pair.split(',').map(Number); return { lat, lon }; });
  if (points.length < 1 || points.length > 9 || points.some(p => !validPoint(p))) return json(400, { ok: false, error: 'Koordinat topografi harus valid dan berada di Indonesia.' });
  const key = points.map(p => `${p.lat.toFixed(5)},${p.lon.toFixed(5)}`).join('|');
  const cached = CACHE.get(key);
  if (cached && Date.now() - cached.at < TTL_MS) return json(200, cached.value, 'public, max-age=43200, stale-while-revalidate=3600');
  let elevations = null, source = '';
  const errors = [];
  for (const dataset of ['aster30m', 'srtm90m']) {
    try { elevations = await queryTopo(dataset, points); source = `OpenTopoData · ${dataset.toUpperCase()}`; break; }
    catch (error) { errors.push(error.message); }
  }
  if (!elevations) return json(200, { ok: false, elevations: [], source: null, note: errors.join('; ') || 'Sumber elevasi tidak merespons.' });
  const value = { ok: true, elevations, source, resolution: source.includes('ASTER') ? '30 m' : '90 m', checkedAt: new Date().toISOString() };
  CACHE.set(key, { at: Date.now(), value });
  if (CACHE.size > 500) CACHE.delete(CACHE.keys().next().value);
  return json(200, value, 'public, max-age=43200, stale-while-revalidate=3600');
};
