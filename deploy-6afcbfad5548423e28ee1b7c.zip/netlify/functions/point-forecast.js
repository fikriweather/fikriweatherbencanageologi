'use strict';

const CACHE = new Map();
const json = (statusCode, body, cache='no-store') => ({
  statusCode,
  headers: {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': cache,
    'Access-Control-Allow-Origin': '*',
    'X-Content-Type-Options': 'nosniff'
  },
  body: JSON.stringify(body)
});
const num = v => v !== null && v !== undefined && v !== '' && Number.isFinite(Number(v)) ? Number(v) : null;
const jakartaDate = date => new Intl.DateTimeFormat('en-CA', {
  timeZone: 'Asia/Jakarta', year: 'numeric', month: '2-digit', day: '2-digit'
}).format(date);

exports.handler = async event => {
  const q = event.queryStringParameters || {};
  const lat = num(q.lat), lon = num(q.lon);
  const date = String(q.date || ''), time = String(q.time || '');
  if (lat === null || lon === null || Math.abs(lat) > 90 || Math.abs(lon) > 180) {
    return json(400, { ok: false, error: 'Koordinat tujuan tidak valid.' });
  }
  if (lat < -11.5 || lat > 6.8 || lon < 94 || lon > 142) {
    return json(400, { ok: false, error: 'Pencarian prakiraan ini hanya mendukung destinasi di Indonesia.' });
  }
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || !/^(?:[01]\d|2[0-3]):00$/.test(time)) {
    return json(400, { ok: false, error: 'Tanggal harus YYYY-MM-DD dan jam harus tepat pada awal jam WIB.' });
  }
  const today = jakartaDate(new Date());
  const target = new Date(`${date}T${time}:00+07:00`);
  const start = new Date(`${today}T00:00:00+07:00`);
  const max = new Date(start.getTime() + 10 * 86400000);
  if (!Number.isFinite(target.getTime()) || target.getTime() < start.getTime() || target.getTime() >= max.getTime()) {
    return json(400, { ok: false, error: 'Tanggal kunjungan harus berada dalam rentang prakiraan 10 hari ke depan.' });
  }

  const key = `${lat.toFixed(3)},${lon.toFixed(3)},${date},${time}`;
  const cached = CACHE.get(key);
  if (cached && Date.now() - cached.at < 10 * 60 * 1000) {
    return json(200, cached.value, 'public, max-age=600, stale-while-revalidate=300');
  }

  try {
    const params = new URLSearchParams({
      latitude: String(lat), longitude: String(lon),
      hourly: 'temperature_2m,relative_humidity_2m,apparent_temperature,precipitation_probability,precipitation,weather_code,wind_speed_10m,wind_direction_10m,wind_gusts_10m,visibility,uv_index',
      forecast_days: '10', timezone: 'auto'
    });
    const response = await fetch(`https://api.open-meteo.com/v1/forecast?${params}`, {
      headers: { 'Accept': 'application/json', 'User-Agent': 'FikriWeather/3.1 destination-forecast' },
      signal: AbortSignal.timeout(12000)
    });
    if (!response.ok) throw new Error(`Layanan prakiraan mengembalikan HTTP ${response.status}`);
    const raw = await response.json();
    const hourly = raw.hourly || {};
    const times = Array.isArray(hourly.time) ? hourly.time : [];
    const index = times.findIndex(value => value === `${date}T${time}`);
    if (index < 0) throw new Error('Jam yang dipilih berada di luar rentang prakiraan yang dikirim model.');
    const fields = [
      'temperature_2m', 'relative_humidity_2m', 'apparent_temperature',
      'precipitation_probability', 'precipitation', 'weather_code',
      'wind_speed_10m', 'wind_direction_10m', 'wind_gusts_10m', 'visibility', 'uv_index'
    ];
    const hour = { time: times[index] };
    for (const field of fields) hour[field] = num(hourly[field]?.[index]);
    if (!fields.some(field => hour[field] !== null)) throw new Error('Data untuk jam yang dipilih belum tersedia.');

    const value = {
      ok: true,
      hour,
      timezone: raw.timezone || 'Asia/Jakarta',
      utc_offset_seconds: raw.utc_offset_seconds ?? null,
      meta: {
        source: 'Open-Meteo weather forecast',
        timezone: raw.timezone || 'Asia/Jakarta',
        utc_offset_seconds: raw.utc_offset_seconds ?? null,
        forecast_date: date,
        forecast_days: 10,
        fetched_at: new Date().toISOString(),
        note: 'Prakiraan model untuk koordinat destinasi; bukan observasi langsung.'
      }
    };
    CACHE.set(key, { at: Date.now(), value });
    if (CACHE.size > 800) CACHE.delete(CACHE.keys().next().value);
    return json(200, value, 'public, max-age=600, stale-while-revalidate=300');
  } catch (error) {
    return json(502, { ok: false, error: 'Prakiraan cuaca tujuan tidak berhasil diperoleh. Tidak ada data buatan yang ditampilkan.' });
  }
};
