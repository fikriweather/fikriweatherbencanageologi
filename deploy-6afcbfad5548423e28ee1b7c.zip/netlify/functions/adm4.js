'use strict';
const CACHE = new Map();
const norm = s => String(s||'').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9]+/g,' ').trim();
const clean = s => norm(s).replace(/^(kabupaten administrasi|kabupaten|kab|kota administrasi|kota|kecamatan|kec|kelurahan|kel|desa|gampong|kampung|district)\s+/,'').trim();
const json = (statusCode, body, cache='no-store') => ({statusCode,headers:{'Content-Type':'application/json; charset=utf-8','Cache-Control':cache,'Access-Control-Allow-Origin':'*','X-Content-Type-Options':'nosniff'},body:JSON.stringify(body)});
async function timedFetch(url, ms=4500, headers={}, signal=null) { const ac=new AbortController(); const t=setTimeout(()=>ac.abort(),ms); const abort=()=>ac.abort(); if(signal?.aborted)ac.abort();else signal?.addEventListener('abort',abort,{once:true}); try { const r=await fetch(url,{signal:ac.signal,headers}); if(!r.ok) throw new Error(`HTTP ${r.status}`); return r; } finally { clearTimeout(t); signal?.removeEventListener('abort',abort); } }
async function getJson(url, ms=4500, signal=null) { const r=await timedFetch(url,ms,{'User-Agent':'FikriWeather/3.0 location resolver','Accept-Language':'id'},signal); return r.json(); }
function arrOf(x){ if(Array.isArray(x)) return x; if(Array.isArray(x?.data)) return x.data; if(Array.isArray(x?.result)) return x.result; if(Array.isArray(x?.results)) return x.results; return []; }

async function listFor(base,search,limit,signal){
 const params=new URLSearchParams({search:String(search||''),page:'1',limit:String(limit)});
 let rows=arrOf(await getJson(`${base}?${params}`,2200,signal));
 if(!rows.length){const fallback=new URLSearchParams({page:'1',limit:String(limit)});rows=arrOf(await getJson(`${base}?${fallback}`,2200,signal));}
 return rows;
}
function aliases(value){const n=clean(value);const map={
  'di yogyakarta':['daerah istimewa yogyakarta','diy','yogyakarta'],'daerah istimewa yogyakarta':['di yogyakarta','diy','yogyakarta'],'diy':['daerah istimewa yogyakarta','di yogyakarta','yogyakarta'],
  'nanggroe aceh darussalam':['aceh'],'nad':['aceh'],'aceh':['nanggroe aceh darussalam','nad'],'daerah khusus ibukota jakarta':['dki jakarta','jakarta'],'dki jakarta':['daerah khusus ibukota jakarta','jakarta'],
  'kepulauan bangka belitung':['bangka belitung'],'bangka belitung':['kepulauan bangka belitung'],
  'dki jakarta':['jakarta'],'papua barat daya':['papua barat daya']
 };return [n,...(map[n]||[])];}
function choose(list, wanted, type='name') {const variants=aliases(wanted).filter(Boolean);if(!variants.length)return null;const names=x=>clean(x?.name||x?.[type]||x?.village_name||x?.district_name||x?.regency_name||x?.province_name||'');for(const w of variants){const exact=list.filter(x=>names(x)===w);if(exact.length===1)return exact[0];}for(const w of variants){const close=list.filter(x=>names(x)&&(names(x).includes(w)||w.includes(names(x))));if(close.length===1)return close[0];}return null;}
function codeOf(x){const digits=String(x?.code||x?.id||x?.village_id||x?.village_code||'').replace(/\D/g,'');return digits.length===10?`${digits.slice(0,2)}.${digits.slice(2,4)}.${digits.slice(4,6)}.${digits.slice(6)}`:String(x?.code||x?.id||'').match(/^\d{2}\.\d{2}\.\d{2}\.\d{4}$/)?.[0]||null;}
function sameArea(actual,expected){if(!actual||!expected)return true;const a=clean(actual),e=clean(expected);return a===e||a.endsWith(' '+e)||e.endsWith(' '+a);}
async function validateBMKG(adm4,expected,signal){
 const d=await getJson('https://api.bmkg.go.id/publik/prakiraan-cuaca?adm4='+encodeURIComponent(adm4),3500,signal);
 if(!d?.lokasi||!Array.isArray(d?.data)||!d.data.some(x=>Array.isArray(x?.cuaca)&&x.cuaca.length))return false;
 const l=d.lokasi,actualVillage=l.desa||l.village||l.kelurahan||l.name||'';
 // A response is accepted only when BMKG identifies the same village and, when
 // supplied, the same district/regency. Merely receiving any forecast is not enough.
 if(!actualVillage||!sameArea(actualVillage,expected.village))return false;
 const actualDistrict=l.kecamatan||l.district||'';
 const actualRegency=l.kotkab||l.kabupaten||l.kota||l.regency||'';
 if(actualDistrict&&!sameArea(actualDistrict,expected.district))return false;
 if(actualRegency&&!sameArea(actualRegency,expected.regency))return false;
 return true;
}
async function findWilayah2025(a,signal){
 // Wilayah.web.id's current hierarchy is a candidate source only. Every village code
 // is tested against BMKG's 2022 ADM4 endpoint before the app may label it BMKG.
 const provinces=await listFor('https://wilayah.web.id/api/provinces',a.state||a.province||'',50,signal);
 const province=choose(provinces,a.state||a.province||''); if(!province) return null;
 const provId=province.code||province.id; if(!provId)return null;
 const regencyWanted=a.city||a.municipality||a.county||a.state_district||'';
 const regencies=await listFor(`https://wilayah.web.id/api/regencies/${encodeURIComponent(provId)}`,regencyWanted,100,signal);
 const regency=choose(regencies,regencyWanted); if(!regency)return null;
 const regId=regency.code||regency.id; if(!regId)return null;
 const districtWanted=a.city_district||a.district||a.subdistrict||a.municipality_district||'';
 const districts=await listFor(`https://wilayah.web.id/api/districts/${encodeURIComponent(regId)}`,districtWanted,150,signal);
 const district=choose(districts,districtWanted); if(!district)return null;
 const distId=district.code||district.id; if(!distId)return null;
 const villageWanted=a.village||a.hamlet||a.suburb||a.neighbourhood||a.quarter||a.town||'';
 const villages=await listFor(`https://wilayah.web.id/api/villages/${encodeURIComponent(distId)}`,villageWanted,200,signal);
 const village=choose(villages,villageWanted); if(!village)return null;
 const code=codeOf(village); if(!code)return null;
 const expected={village:village.name||village.village_name||villageWanted,district:district.name||district.district_name||districtWanted,regency:regency.name||regencyWanted};
 if(await validateBMKG(code,expected,signal)) return {adm4:code,...expected,province:province.name||a.state||'',mappingSource:'Nama desa/kecamatan dicocokkan dengan respons API BMKG'};
 return null;
}
exports.handler=async event=>{
 const lat=Number(event.queryStringParameters?.lat),lon=Number(event.queryStringParameters?.lon);
 if(!Number.isFinite(lat)||!Number.isFinite(lon)||Math.abs(lat)>90||Math.abs(lon)>180) return json(400,{error:'Koordinat tidak valid.'});
 if(lat < -11.5 || lat > 6.8 || lon < 94 || lon > 142) return json(200,{adm4:null,country:'outside_indonesia',detail:'Lokasi berada di luar Indonesia; gunakan sumber cuaca global.'},'public, max-age=3600');
 const key=`${lat.toFixed(3)},${lon.toFixed(3)}`;const cached=CACHE.get(key);if(cached&&Date.now()-cached.at<cached.ttl)return json(200,cached.value,'public, max-age=600');
 try{
  const ac=new AbortController(),deadline=setTimeout(()=>ac.abort(),14200);
  try{
  const u=`https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${lat}&lon=${lon}&zoom=18&addressdetails=1`;
  const data=await getJson(u,2800,ac.signal),a=data.address||{};
  if(String(a.country_code||'').toLowerCase()!=='id') return json(200,{adm4:null,detail:'Koordinat tidak dikenali sebagai wilayah Indonesia.'});
  const village=a.village||a.hamlet||a.suburb||a.neighbourhood||a.quarter||a.town||a.borough||data.name||'';
  const district=a.city_district||a.district||a.subdistrict||a.municipality_district||'';
  const regency=a.city||a.municipality||a.county||a.state_district||'';
  const province=a.state||a.province||'';
  const place={village,district,regency,province};
  const result=await findWilayah2025({...a,state:province,city:regency,city_district:district,village},ac.signal);
  const value=result?{...place,...result,detail:'Kode ADM4 berhasil divalidasi oleh API prakiraan BMKG.'}:{adm4:null,...place,detail:'Kode wilayah belum berhasil dipetakan atau tidak diterima API BMKG. Fikri Weather akan memakai sumber pelengkap dan menandainya secara terpisah.'};
  CACHE.set(key,{at:Date.now(),ttl:result?6*3600*1000:5*60*1000,value});if(CACHE.size>2000)CACHE.delete(CACHE.keys().next().value);return json(200,value,result?'public, max-age=3600':'public, max-age=120');
  } finally { clearTimeout(deadline); }
 }catch(e){return json(502,{adm4:null,error:'Pemetaan wilayah BMKG belum berhasil.',detail:'Sumber pencarian wilayah sementara tidak tersedia. Tidak ada kode ADM4 yang ditebak.'});}
};
