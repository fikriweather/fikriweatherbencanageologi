'use strict';

const CACHE = new Map();
const json = (statusCode, body, cache = 'no-store') => ({
  statusCode,
  headers: {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': cache,
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
    'X-Content-Type-Options': 'nosniff'
  },
  body: JSON.stringify(body)
});
const finite = value => value !== null && value !== undefined && value !== '' && Number.isFinite(Number(value));
const number = value => finite(value) ? Number(value) : null;
const isoHour = ms => new Date(ms).toISOString().slice(0, 13) + ':00';

function validatePoint(point, index, now) {
  if (!point || typeof point !== 'object') throw new Error(`Titik ${index + 1} tidak valid.`);
  const lat = number(point.lat), lon = number(point.lon), eta = Date.parse(point.eta);
  if (lat === null || lon === null || Math.abs(lat) > 90 || Math.abs(lon) > 180) {
    throw new Error(`Koordinat titik ${index + 1} tidak valid.`);
  }
  // Route samples are expected to remain in the Indonesian FIR/archipelago region.
  if (lat < -12.5 || lat > 7.5 || lon < 93 || lon > 143) {
    throw new Error(`Titik ${index + 1} berada di luar cakupan wilayah rute Indonesia.`);
  }
  if (!Number.isFinite(eta) || eta < now - 15 * 60 * 1000 || eta > now + 10 * 86400000) {
    throw new Error(`Waktu titik ${index + 1} harus berada dari 15 menit lalu hingga 10 hari ke depan.`);
  }
  return {
    id: String(point.id || `P${index + 1}`).slice(0, 24),
    lat,
    lon,
    eta,
    eta_iso: new Date(eta).toISOString()
  };
}

async function fetchModel(points, model) {
  const params = new URLSearchParams({
    latitude: points.map(point => point.lat.toFixed(4)).join(','),
    longitude: points.map(point => point.lon.toFixed(4)).join(','),
    hourly: 'temperature_2m,relative_humidity_2m,precipitation_probability,precipitation,weather_code,wind_speed_10m,wind_direction_10m,wind_gusts_10m,visibility,cloud_cover,pressure_msl,cape',
    forecast_days: '10',
    timezone: 'UTC',
    wind_speed_unit: 'kn'
  });
  if (model?.id) params.set('models', model.id);
  const response = await fetch(`https://api.open-meteo.com/v1/forecast?${params}`, {
    headers: { Accept: 'application/json', 'User-Agent': 'FikriWeather/2.4.4 flight-route-weather' },
    signal: AbortSignal.timeout(18000)
  });
  if (!response.ok) throw new Error(`${model?.name || 'Best Match'} HTTP ${response.status}`);
  const raw = await response.json();
  const list = Array.isArray(raw) ? raw : [raw];
  if (list.length !== points.length) throw new Error('Jumlah titik respons prakiraan tidak cocok dengan rute.');
  return list;
}

function findHour(hourly, targetMs) {
  const times = Array.isArray(hourly?.time) ? hourly.time : [];
  let bestIndex = -1, bestDelta = Infinity;
  for (let i = 0; i < times.length; i++) {
    const parsed = Date.parse(`${times[i]}Z`);
    if (!Number.isFinite(parsed)) continue;
    const delta = Math.abs(parsed - targetMs);
    if (delta < bestDelta) { bestDelta = delta; bestIndex = i; }
  }
  if (bestIndex < 0 || bestDelta > 90 * 60 * 1000) return null;
  return { index: bestIndex, time: times[bestIndex], delta_minutes: Math.round(bestDelta / 60000) };
}

function fieldValue(hourly, field, index) {
  return number(hourly?.[field]?.[index]);
}

exports.handler = async event => {
  if (event.httpMethod === 'OPTIONS') return json(204, {});
  if (event.httpMethod && event.httpMethod !== 'POST') return json(405, { ok: false, error: 'Gunakan metode POST untuk analisis rute penerbangan.' });

  let body;
  try { body = JSON.parse(event.body || '{}'); }
  catch { return json(400, { ok: false, error: 'Isi permintaan bukan JSON yang valid.' }); }

  const incoming = body?.points;
  if (!Array.isArray(incoming) || incoming.length < 2 || incoming.length > 17) {
    return json(400, { ok: false, error: 'Rute memerlukan 2 sampai 17 titik cuaca.' });
  }

  const now = Date.now();
  let points;
  try { points = incoming.map((point, index) => validatePoint(point, index, now)); }
  catch (error) { return json(400, { ok: false, error: error.message }); }

  const cacheKey = points.map(point => `${point.lat.toFixed(3)},${point.lon.toFixed(3)},${isoHour(point.eta)}`).join('|');
  const cached = CACHE.get(cacheKey);
  if (cached && now - cached.at < 5 * 60 * 1000) {
    return json(200, { ...cached.value, meta: { ...cached.value.meta, cache: 'hit' } }, 'public, max-age=120, stale-while-revalidate=120');
  }

  const models = [
    { id: null, name: 'Best Match' },
    { id: 'ecmwf_ifs025', name: 'ECMWF IFS' },
    { id: 'gfs_seamless', name: 'NCEP GFS' }
  ];
  const results = await Promise.allSettled(models.map(model => fetchModel(points, model)));
  const usable = results.map((result, index) => result.status === 'fulfilled'
    ? { model: models[index], data: result.value }
    : null).filter(Boolean);

  if (!usable.length) {
    return json(502, {
      ok: false,
      error: 'Seluruh sumber prakiraan rute tidak berhasil diakses. Tidak ada cuaca yang dibuat atau ditebak.',
      details: results.map((result, index) => ({ model: models[index].name, ok: result.status === 'fulfilled' }))
    });
  }

  const output = points.map((point, pointIndex) => {
    // Prefer Best Match for each point, but allow another provider to supply a valid slot
    // when the primary feed has a gap at the requested ETA.
    const candidates = usable.map(item => ({ item, hourly: item.data[pointIndex]?.hourly || {}, slot: findHour(item.data[pointIndex]?.hourly, point.eta) }))
      .filter(candidate => candidate.slot);
    const selected = candidates.find(candidate => candidate.item.model.id === null) || candidates[0];
    if (!selected) {
      return {
        id: point.id, lat: point.lat, lon: point.lon, eta: point.eta_iso,
        available: false,
        note: 'Tidak ada slot prakiraan yang cukup dekat dengan estimasi waktu melintas.'
      };
    }

    const chosen = selected.item;
    const chosenHourly = selected.hourly;
    const slot = selected.slot;
    const idx = slot.index;
    const valueFromAvailableModel = field => {
      // Field-level priority: Best Match, then ECMWF, then GFS. A null in one
      // model must not erase a valid value supplied by another model.
      for (const candidate of candidates) {
        const value = fieldValue(candidate.hourly, field, candidate.slot.index);
        if (value !== null) return { value, model: candidate.item.model.name };
      }
      return { value: null, model: null };
    };
    const probabilities = [];
    for (const result of usable) {
      const matched = findHour(result.data[pointIndex]?.hourly, point.eta);
      if (!matched) continue;
      const probability = fieldValue(result.data[pointIndex]?.hourly, 'precipitation_probability', matched.index);
      if (probability !== null && probability >= 0 && probability <= 100) {
        probabilities.push({ model: result.model.name, value: Math.round(probability) });
      }
    }
    const probabilityValues = probabilities.map(item => item.value);
    const probability = probabilityValues.length
      ? Math.round(probabilityValues.reduce((sum, item) => sum + item, 0) / probabilityValues.length)
      : null;

    const temperature = valueFromAvailableModel('temperature_2m');
    const humidity = valueFromAvailableModel('relative_humidity_2m');
    const precipitation = valueFromAvailableModel('precipitation');
    const weatherCode = valueFromAvailableModel('weather_code');
    const windSpeed = valueFromAvailableModel('wind_speed_10m');
    const windDirection = valueFromAvailableModel('wind_direction_10m');
    const windGust = valueFromAvailableModel('wind_gusts_10m');
    const visibility = valueFromAvailableModel('visibility');
    const cloudCover = valueFromAvailableModel('cloud_cover');
    const pressure = valueFromAvailableModel('pressure_msl');
    const cape = valueFromAvailableModel('cape');
    return {
      id: point.id,
      lat: point.lat,
      lon: point.lon,
      eta: point.eta_iso,
      available: true,
      forecast_time_utc: `${slot.time}:00Z`,
      slot_delta_minutes: slot.delta_minutes,
      temperature_c: temperature.value,
      relative_humidity_pct: humidity.value,
      precipitation_probability_pct: probability,
      precipitation_mm: precipitation.value,
      weather_code: weatherCode.value,
      wind_speed_kt: windSpeed.value,
      wind_direction_deg: windDirection.value,
      wind_gust_kt: windGust.value,
      visibility_m: visibility.value,
      cloud_cover_pct: cloudCover.value,
      pressure_hpa: pressure.value,
      cape_jkg: cape.value,
      field_sources: { temperature: temperature.model, humidity: humidity.model, precipitation: precipitation.model, weather: weatherCode.model, wind: windSpeed.model, visibility: visibility.model, cloud: cloudCover.model, pressure: pressure.model, cape: cape.model },
      probability_models: probabilities,
      probability_range_pct: probabilityValues.length >= 2
        ? { min: Math.min(...probabilityValues), max: Math.max(...probabilityValues) }
        : null,
      probability_method: probabilityValues.length >= 2 ? 'mean' : probabilityValues.length === 1 ? 'single' : 'none',
      selected_model: chosen.model.name
    };
  });

  const value = {
    ok: true,
    points: output,
    meta: {
      source: 'Open-Meteo Forecast API',
      models_used: usable.map(item => item.model.name),
      fetched_at: new Date().toISOString(),
      timezone_for_lookup: 'UTC',
      note: 'Prakiraan model per jam pada koordinat permukaan sepanjang lintasan ilustratif; bukan observasi langsung dan bukan prakiraan cuaca pada ketinggian jelajah.'
    }
  };
  CACHE.set(cacheKey, { at: now, value });
  if (CACHE.size > 180) CACHE.delete(CACHE.keys().next().value);
  return json(200, value, 'public, max-age=120, stale-while-revalidate=120');
};
