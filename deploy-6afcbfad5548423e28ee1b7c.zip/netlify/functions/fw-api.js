'use strict';
const {
  response, cookieHeaders, setSessionCookie, clearSessionCookie, parseBody,
  db, createSession, getSession, destroySession, scryptHash, verifyScrypt,
  uploadDataUrl, addNotification, addAdminNotification, notifyUsers,
} = require('./lib/fw-server.cjs');

const defaults = {
  notification_settings: { rain: false, quake: false, forecast5h: false, today: false, tomorrow: false, announcement: true, admin_reply: true },
  sound_settings: { enabled: true, volume: 0.65, style: 'default', customDataUrl: '' },
  location: null,
};
const pick = (obj, keys) => Object.fromEntries(keys.filter(k => obj && Object.prototype.hasOwnProperty.call(obj, k)).map(k => [k, obj[k]]));
const cleanUsername = value => String(value || '').trim().toLowerCase();
const usernameOk = value => /^[a-z0-9._-]{3,32}$/.test(value);
const text = (v, max) => String(v ?? '').trim().slice(0, max);
async function requireSession(event) {
  const s = await getSession(event);
  if (!s) { const e = new Error('Silakan login terlebih dahulu.'); e.statusCode = 401; throw e; }
  return s;
}
async function requireAdmin(event) {
  const s = await requireSession(event);
  if (s.role !== 'admin') { const e = new Error('Akses khusus admin.'); e.statusCode = 403; throw e; }
  return s;
}
async function prefsFor(userId) {
  const rows = await db('user_preferences', { query: `select=user_id,notification_settings,sound_settings,location,updated_at&user_id=eq.${encodeURIComponent(userId)}&limit=1` });
  return { ...defaults, ...(rows?.[0] || {}) };
}
async function getSuggestionMessages(id) {
  return await db('suggestion_messages', { query: `select=id,suggestion_id,sender_role,message,created_at&suggestion_id=eq.${encodeURIComponent(id)}&order=created_at.asc` }) || [];
}
async function publicAnnouncements() {
  return await db('announcements', { query: 'select=id,title,body,pinned,media,created_at&order=created_at.desc&limit=50' }) || [];
}
exports.handler = async event => {
  const cors = cookieHeaders(event);
  try {
    if (event.httpMethod === 'OPTIONS') return { statusCode: 204, headers: { ...cors, 'Access-Control-Allow-Methods': 'GET,POST,DELETE,OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type' }, body: '' };
    const action = String(event.queryStringParameters?.action || '');
    const method = event.httpMethod;
    if (!action) return response(400, { error: 'Parameter action wajib diisi.' }, cors);

    if (action === 'register' && method === 'POST') {
      const b = parseBody(event), username = cleanUsername(b.username), password = String(b.password || '');
      if (!usernameOk(username)) return response(400, { error: 'Username harus 3–32 karakter: huruf, angka, titik, garis bawah, atau tanda hubung.' }, cors);
      if (password.length < 8 || password.length > 128) return response(400, { error: 'Password harus terdiri dari 8–128 karakter.' }, cors);
      const old = await db('users', { query: `select=id&username=eq.${encodeURIComponent(username)}&limit=1` });
      if (old?.length) return response(409, { error: 'Username sudah digunakan.' }, cors);
      let created;
      try {
        created = await db('users', { method: 'POST', body: { username, password_hash: scryptHash(password) }, prefer: 'return=representation' });
      } catch (e) {
        if (e.statusCode === 409 || /duplicate|unique/i.test(e.message)) return response(409, { error: 'Username sudah digunakan.' }, cors);
        throw e;
      }
      const user = created?.[0];
      if (!user?.id) throw new Error('Akun gagal dibuat.');
      await db('user_preferences', { method: 'POST', body: { user_id: user.id, ...pick(defaults, ['notification_settings', 'sound_settings', 'location']) }, prefer: 'return=minimal' });
      try { await addAdminNotification('registration', 'Pengguna baru terdaftar', `${user.username} membuat akun Fikri Weather.`, '/#developer'); } catch (e) { console.warn('Admin notification skipped:', e.message); }
      const token = await createSession({ principal: user.username, role: 'user', userId: user.id });
      return response(201, { ok: true, user: { id: user.id, username: user.username, created_at: user.created_at } }, { ...cors, 'Set-Cookie': setSessionCookie(token) });
    }

    if (action === 'login' && method === 'POST') {
      const b = parseBody(event), username = cleanUsername(b.username), password = String(b.password || '');
      const rows = await db('users', { query: `select=id,username,password_hash,created_at&username=eq.${encodeURIComponent(username)}&disabled=eq.false&limit=1` });
      const user = rows?.[0];
      if (!user || !verifyScrypt(password, user.password_hash)) {
        await new Promise(resolve => setTimeout(resolve, 350));
        return response(401, { error: 'Username atau password tidak cocok.' }, cors);
      }
      const token = await createSession({ principal: user.username, role: 'user', userId: user.id });
      return response(200, { ok: true, user: { id: user.id, username: user.username, created_at: user.created_at } }, { ...cors, 'Set-Cookie': setSessionCookie(token) });
    }

    if (action === 'logout' && method === 'POST') {
      await destroySession(event);
      return response(200, { ok: true }, { ...cors, 'Set-Cookie': clearSessionCookie });
    }

    if (action === 'me' && method === 'GET') {
      const s = await getSession(event);
      if (!s || s.role !== 'user') return response(200, { ok: false }, cors);
      const rows = await db('users', { query: `select=id,username,created_at&id=eq.${encodeURIComponent(s.user_id)}&limit=1` });
      if (!rows?.[0]) return response(200, { ok: false }, cors);
      return response(200, { ok: true, user: rows[0], preferences: await prefsFor(s.user_id) }, cors);
    }

    if (action === 'announcements' && method === 'GET') return response(200, { items: await publicAnnouncements() }, cors);

    if (action === 'app-settings' && method === 'GET') {
      const rows = await db('app_settings', { query: 'select=setting_key,value&setting_key=eq.sound_defaults&limit=1' });
      return response(200, { sound_defaults: rows?.[0]?.value || {} }, cors);
    }
    if (action === 'app-settings' && method === 'POST') {
      await requireAdmin(event);
      const b = parseBody(event);
      const value = b.sound_defaults && typeof b.sound_defaults === 'object' ? b.sound_defaults : {};
      await db('app_settings', { method: 'POST', query: 'on_conflict=setting_key', body: { setting_key: 'sound_defaults', value }, prefer: 'resolution=merge-duplicates,return=minimal' });
      return response(200, { ok: true }, cors);
    }

    if (action === 'preferences' && method === 'GET') {
      const s = await requireSession(event);
      if (s.role !== 'user') return response(403, { error: 'Fitur ini untuk akun pengguna.' }, cors);
      return response(200, { preferences: await prefsFor(s.user_id) }, cors);
    }
    if (action === 'preferences' && method === 'POST') {
      const s = await requireSession(event);
      if (s.role !== 'user') return response(403, { error: 'Fitur ini untuk akun pengguna.' }, cors);
      const b = parseBody(event);
      const n = b.notification_settings && typeof b.notification_settings === 'object' ? b.notification_settings : defaults.notification_settings;
      const allowed = ['rain', 'quake', 'forecast5h', 'today', 'tomorrow', 'announcement', 'admin_reply'];
      const notif = Object.fromEntries(allowed.map(k => [k, n[k] === true]));
      const sound = b.sound_settings && typeof b.sound_settings === 'object' ? {
        enabled: b.sound_settings.enabled !== false,
        volume: Math.max(0, Math.min(1, Number(b.sound_settings.volume ?? .65))),
        style: ['default', 'soft', 'chime', 'alert'].includes(b.sound_settings.style) ? b.sound_settings.style : 'default',
        customDataUrl: /^data:audio\//i.test(String(b.sound_settings.customDataUrl || '')) ? String(b.sound_settings.customDataUrl).slice(0, 420000) : '',
      } : defaults.sound_settings;
      let location = null;
      if (b.location && Number.isFinite(+b.location.lat) && Number.isFinite(+b.location.lon) && Math.abs(+b.location.lat) <= 90 && Math.abs(+b.location.lon) <= 180) {
        location = { lat: +b.location.lat, lon: +b.location.lon, place: text(b.location.place, 160), adm4: /^\d{2}\.\d{2}\.\d{2}\.\d{4}$/.test(String(b.location.adm4 || '')) ? String(b.location.adm4) : null };
      }
      await db('user_preferences', { method: 'POST', query: 'on_conflict=user_id', body: { user_id: s.user_id, notification_settings: notif, sound_settings: sound, location, updated_at: new Date().toISOString() }, prefer: 'resolution=merge-duplicates,return=minimal' });
      return response(200, { ok: true, preferences: { notification_settings: notif, sound_settings: sound, location } }, cors);
    }

    if (action === 'assistant-chat' && method === 'GET') {
      const s = await requireSession(event);
      if (s.role !== 'user') return response(403, { ok: false, error: 'Penyimpanan percakapan hanya tersedia untuk akun pengguna.' }, cors);
      const items = await db('assistant_conversations', {
        query: `select=id,title,messages,created_at,updated_at&user_id=eq.${encodeURIComponent(s.user_id)}&order=updated_at.desc&limit=20`,
      }) || [];
      return response(200, { ok: true, items }, cors);
    }
    if (action === 'assistant-chat' && method === 'POST') {
      const s = await requireSession(event);
      if (s.role !== 'user') return response(403, { ok: false, error: 'Penyimpanan percakapan hanya tersedia untuk akun pengguna.' }, cors);
      const b = parseBody(event);
      const title = text(b.title || 'Percakapan cuaca', 120) || 'Percakapan cuaca';
      if (!Array.isArray(b.messages)) return response(400, { ok: false, error: 'Format riwayat percakapan tidak valid.' }, cors);
      const messages = b.messages.slice(-20).map(m => ({
        role: m?.role === 'user' ? 'user' : m?.role === 'assistant' ? 'assistant' : '',
        content: text(m?.content, 1200),
      })).filter(m => m.role && m.content);
      const totalChars = messages.reduce((sum, m) => sum + m.content.length, 0);
      if (!messages.length || totalChars > 12000) return response(400, { ok: false, error: 'Isi percakapan kosong atau terlalu panjang.' }, cors);
      const id = text(b.id, 64);
      if (id) {
        if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(id)) {
          return response(400, { ok: false, error: 'ID percakapan tidak valid.' }, cors);
        }
        const owned = await db('assistant_conversations', {
          query: `select=id&id=eq.${encodeURIComponent(id)}&user_id=eq.${encodeURIComponent(s.user_id)}&limit=1`,
        });
        if (!owned?.length) return response(404, { ok: false, error: 'Percakapan tidak ditemukan pada akun ini.' }, cors);
        await db('assistant_conversations', {
          method: 'PATCH',
          query: `id=eq.${encodeURIComponent(id)}&user_id=eq.${encodeURIComponent(s.user_id)}`,
          body: { title, messages, updated_at: new Date().toISOString() },
          prefer: 'return=minimal',
        });
        return response(200, { ok: true, id }, cors);
      }
      const created = await db('assistant_conversations', {
        method: 'POST',
        body: { user_id: s.user_id, title, messages },
        prefer: 'return=representation',
      });
      const createdId = created?.[0]?.id;
      if (!createdId) throw new Error('Percakapan belum berhasil disimpan.');
      return response(201, { ok: true, id: createdId }, cors);
    }
    if (action === 'assistant-chat' && method === 'DELETE') {
      const s = await requireSession(event);
      if (s.role !== 'user') return response(403, { ok: false, error: 'Akses pengguna diperlukan.' }, cors);
      const id = text(event.queryStringParameters?.id, 64);
      if (id && !/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(id)) {
        return response(400, { ok: false, error: 'ID percakapan tidak valid.' }, cors);
      }
      const ownerFilter = `user_id=eq.${encodeURIComponent(s.user_id)}`;
      await db('assistant_conversations', {
        method: 'DELETE',
        query: id ? `id=eq.${encodeURIComponent(id)}&${ownerFilter}` : ownerFilter,
      });
      return response(200, { ok: true }, cors);
    }

    if (action === 'suggestions' && method === 'GET') {
      const s = await requireSession(event);
      const query = s.role === 'admin'
        ? 'select=id,user_id,category,status,created_at&order=created_at.desc&limit=100'
        : `select=id,user_id,category,status,created_at&user_id=eq.${encodeURIComponent(s.user_id)}&order=created_at.desc&limit=50`;
      const items = await db('suggestions', { query }) || [];
      const enriched = await Promise.all(items.map(async item => {
        const [messages, owner] = await Promise.all([
          getSuggestionMessages(item.id),
          s.role === 'admin' ? db('users', { query: `select=username&id=eq.${encodeURIComponent(item.user_id)}&limit=1` }) : Promise.resolve([]),
        ]);
        return { ...item, username: owner?.[0]?.username || (s.role === 'user' ? s.principal : 'Pengguna'), messages };
      }));
      return response(200, { items: enriched }, cors);
    }

    if (action === 'suggestion' && method === 'POST') {
      const s = await requireSession(event);
      if (s.role !== 'user') return response(403, { error: 'Gunakan akun pengguna untuk mengirim saran.' }, cors);
      const b = parseBody(event), category = text(b.category, 80), message = text(b.message, 4000);
      if (!category || !message) return response(400, { error: 'Kategori dan isi saran wajib diisi.' }, cors);
      const created = await db('suggestions', { method: 'POST', body: { user_id: s.user_id, category, status: 'new' }, prefer: 'return=representation' });
      const row = created?.[0];
      if (!row?.id) throw new Error('Saran gagal disimpan.');
      await db('suggestion_messages', { method: 'POST', body: { suggestion_id: row.id, sender_role: 'user', sender_user_id: s.user_id, message }, prefer: 'return=minimal' });
      try { await addAdminNotification('suggestion', 'Saran baru masuk', `${s.principal} mengirim saran kategori ${category}.`, '/#developer'); } catch (e) { console.warn('Admin notification skipped:', e.message); }
      return response(201, { ok: true, id: row.id }, cors);
    }

    if (action === 'message' && method === 'POST') {
      const s = await requireSession(event), b = parseBody(event);
      const suggestionId = text(b.suggestion_id, 64), message = text(b.message, 3000);
      if (!suggestionId || !message) return response(400, { error: 'Pesan tidak boleh kosong.' }, cors);
      const rows = await db('suggestions', { query: `select=id,user_id,status&id=eq.${encodeURIComponent(suggestionId)}&limit=1` });
      const item = rows?.[0];
      if (!item) return response(404, { error: 'Percakapan tidak ditemukan.' }, cors);
      if (s.role !== 'admin' && item.user_id !== s.user_id) return response(403, { error: 'Percakapan ini bukan milik akunmu.' }, cors);
      await db('suggestion_messages', { method: 'POST', body: { suggestion_id: item.id, sender_role: s.role, sender_user_id: s.role === 'user' ? s.user_id : null, message }, prefer: 'return=minimal' });
      if (s.role === 'admin') {
        await db('suggestions', { method: 'PATCH', query: `id=eq.${encodeURIComponent(item.id)}`, body: { status: 'replied' }, prefer: 'return=minimal' });
        await notifyUsers('admin_reply', 'Balasan admin Fikri Weather', 'Admin membalas saran yang kamu kirim.', '/#suggestions', item.user_id);
      } else {
        await db('suggestions', { method: 'PATCH', query: `id=eq.${encodeURIComponent(item.id)}`, body: { status: 'waiting_admin' }, prefer: 'return=minimal' });
        try { await addAdminNotification('suggestion_message', 'Pesan baru dalam saran', `${s.principal} mengirim pesan lanjutan.`, '/#developer'); } catch (e) { console.warn('Admin notification skipped:', e.message); }
      }
      return response(201, { ok: true }, cors);
    }

    if (action === 'announcement' && method === 'POST') {
      await requireAdmin(event);
      const b = parseBody(event), title = text(b.title, 140), body = text(b.body, 6000);
      if (!title) return response(400, { error: 'Judul pengumuman wajib diisi.' }, cors);
      let media = {};
      if (b.imageDataUrl) media.image = await uploadDataUrl(b.imageDataUrl, 'announcements');
      if (b.audioDataUrl) media.audio = await uploadDataUrl(b.audioDataUrl, 'announcements');
      if (b.pinned === true) await db('announcements', { method: 'PATCH', query: 'pinned=eq.true', body: { pinned: false }, prefer: 'return=minimal' });
      const result = await db('announcements', { method: 'POST', body: { title, body, pinned: b.pinned === true, media }, prefer: 'return=representation' });
      const targetCategory = ['rain','quake','forecast5h','today','tomorrow','admin_reply','announcement'].includes(b.targetCategory) ? b.targetCategory : 'announcement';
      await notifyUsers(targetCategory, `Pengumuman: ${title}`, body || 'Ada pengumuman baru dari admin.', '/#announcements');
      return response(201, { ok: true, item: result?.[0] || null }, cors);
    }

    if (action === 'announcement' && method === 'DELETE') {
      await requireAdmin(event);
      const id = text(event.queryStringParameters?.id, 64);
      if (!id) return response(400, { error: 'ID pengumuman wajib diisi.' }, cors);
      await db('announcements', { method: 'DELETE', query: `id=eq.${encodeURIComponent(id)}` });
      return response(200, { ok: true }, cors);
    }

    if (action === 'admin-dashboard' && method === 'GET') {
      await requireAdmin(event);
      const users = await db('users', { query: 'select=id,username,created_at&order=created_at.desc&limit=500' }) || [];
      const suggestions = await db('suggestions', { query: 'select=id,status&limit=500' }) || [];
      return response(200, { users, user_count: users.length, suggestion_count: suggestions.length }, cors);
    }

    if (action === 'notifications' && method === 'GET') {
      const s = await requireSession(event);
      if (s.role !== 'user') return response(403, { error: 'Akses pengguna diperlukan.' }, cors);
      const items = await db('user_notifications', { query: `select=id,category,title,body,url,created_at,read_at&user_id=eq.${encodeURIComponent(s.user_id)}&order=created_at.desc&limit=80` }) || [];
      return response(200, { items }, cors);
    }
    if (action === 'notification-read' && method === 'POST') {
      const s = await requireSession(event), b = parseBody(event);
      if (s.role !== 'user') return response(403, { error: 'Akses pengguna diperlukan.' }, cors);
      const id = text(b.id, 64);
      await db('user_notifications', { method: 'PATCH', query: `id=eq.${encodeURIComponent(id)}&user_id=eq.${encodeURIComponent(s.user_id)}`, body: { read_at: new Date().toISOString() }, prefer: 'return=minimal' });
      return response(200, { ok: true }, cors);
    }

    if (action === 'push-key' && method === 'GET') return response(200, { publicKey: process.env.VAPID_PUBLIC_KEY || '' }, cors);
    if (action === 'push-subscription' && method === 'POST') {
      const s = await requireSession(event), b = parseBody(event);
      if (s.role !== 'user' || !b.subscription?.endpoint) return response(400, { error: 'Langganan push tidak valid.' }, cors);
      await db('push_subscriptions', { method: 'POST', query: 'on_conflict=endpoint', body: { user_id: s.user_id, endpoint: b.subscription.endpoint, subscription: b.subscription }, prefer: 'resolution=merge-duplicates,return=minimal' });
      return response(200, { ok: true }, cors);
    }

    return response(404, { error: 'Aksi tidak dikenal.' }, cors);
  } catch (e) {
    const code = Number(e.statusCode) || 500;
    return response(code, { error: code >= 500 ? (e.message || 'Layanan sementara tidak tersedia.') : e.message }, cors);
  }
};
