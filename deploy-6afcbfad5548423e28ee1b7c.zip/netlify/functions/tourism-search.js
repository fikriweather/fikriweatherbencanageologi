'use strict';

const CACHE = new Map();
let lastRequestAt = 0;
let requestQueue = Promise.resolve();
const json = (statusCode, body, cache='no-store') => ({
  statusCode,
  headers: {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': cache,
    'Access-Control-Allow-Origin': '*',
    'X-Content-Type-Options': 'nosniff'
  },
  body: JSON.stringify(body)
});
const clean = value => String(value || '').replace(/[<>\u0000-\u001f]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 180);

exports.handler = async event => {
  const q = clean(event.queryStringParameters?.q);
  if (q.length < 2) return json(400, { ok: false, error: 'Masukkan nama tempat atau area pencarian minimal dua karakter.', results: [] });
  const category = clean(event.queryStringParameters?.category || 'all').slice(0, 24);
  const key = `${category}:${q.toLocaleLowerCase('id-ID')}`;
  const cached = CACHE.get(key);
  if (cached && Date.now() - cached.at < 30 * 60 * 1000) return json(200, cached.value, 'public, max-age=900, stale-while-revalidate=600');

  try {
    const params = new URLSearchParams({
      format: 'jsonv2', q, countrycodes: 'id', addressdetails: '1', extratags: '1',
      namedetails: '1', limit: '16', 'accept-language': 'id'
    });
    const url = `https://nominatim.openstreetmap.org/search?${params}`;
    const request = async () => {
      const wait = Math.max(0, 1100 - (Date.now() - lastRequestAt));
      if (wait) await new Promise(resolve => setTimeout(resolve, wait));
      lastRequestAt = Date.now();
      return fetch(url, {
        headers: { 'User-Agent': 'FikriWeather/3.1 tourism-search', 'Accept-Language': 'id' },
        signal: AbortSignal.timeout(11000)
      });
    };
    const pending = requestQueue.then(request, request);
    requestQueue = pending.then(() => undefined, () => undefined);
    const response = await pending;
    if (!response.ok) throw new Error(`Pencarian peta mengembalikan HTTP ${response.status}`);
    const raw = await response.json();
    const excluded = new Set(['boundary', 'highway', 'railway', 'place']);
    const rows = (Array.isArray(raw) ? raw : []).filter(item => {
      if (!Number.isFinite(Number(item.lat)) || !Number.isFinite(Number(item.lon))) return false;
      const klass = String(item.class || '').toLowerCase();
      const type = String(item.type || '').toLowerCase();
      if (excluded.has(klass) && !['national_park', 'nature_reserve', 'park'].includes(type)) return false;
      return true;
    }).map(item => {
      const tags = item.extratags || {};
      const address = item.address || {};
      const name = item.name || item.namedetails?.name || item.display_name?.split(',')[0] || 'Destinasi wisata';
      const area = [address.suburb, address.city_district, address.city, address.town, address.county, address.state].filter(Boolean).join(', ');
      return {
        place_id: String(item.place_id || `${item.osm_type || 'osm'}-${item.osm_id || name}`),
        name,
        display_name: item.display_name || area || 'Indonesia',
        latitude: Number(item.lat), longitude: Number(item.lon),
        category: [item.class, item.type].filter(Boolean).join(' · ') || 'Tempat menarik',
        opening_hours: tags.opening_hours || null,
        website: tags.website || tags['contact:website'] || null,
        phone: tags.phone || tags['contact:phone'] || null,
        area
      };
    });
    const value = { ok: true, results: rows, count: rows.length };
    CACHE.set(key, { at: Date.now(), value });
    if (CACHE.size > 350) CACHE.delete(CACHE.keys().next().value);
    return json(200, value, 'public, max-age=900, stale-while-revalidate=600');
  } catch (error) {
    return json(502, { ok: false, error: 'Pencarian destinasi belum berhasil diakses. Coba kata pencarian atau area lain.', results: [] });
  }
};
