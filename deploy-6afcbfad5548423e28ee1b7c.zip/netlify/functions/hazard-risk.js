'use strict';

// Location-specific national hazard index lookup. InaRISK raster values are
// treated as baseline susceptibility, never as proof of an active disaster. Each
// selected location uses one exact rendered pixel per hazard layer.
const CACHE = new Map();
const TTL_MS = 10 * 60 * 1000;
const ROOT = 'https://gis.bnpb.go.id/server/rest/services/inarisk/';
const PIXEL_SIZE_M = 100;
const LAYERS = {
  flood: { name: 'INDEKS_BAHAYA_BANJIR', label: 'Indeks bahaya banjir InaRISK BNPB' },
  landslide: { name: 'INDEKS_BAHAYA_TANAHLONGSOR', label: 'Indeks bahaya tanah longsor InaRISK BNPB' }
};
const json = (statusCode, body, cache = 'no-store') => ({
  statusCode,
  headers: {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': cache,
    'Access-Control-Allow-Origin': '*',
    'X-Content-Type-Options': 'nosniff'
  },
  body: JSON.stringify(body)
});
const num = value => value !== null && value !== undefined && value !== '' && Number.isFinite(Number(value)) ? Number(value) : null;

function level(value) {
  const n = num(value);
  if (n === null || n < 0 || n > 1) return { status: 'DATA BELUM TERSEDIA', category: null };
  if (n <= 0.333) return { status: 'NORMAL', category: 'rendah', classRange: '0–0,333' };
  if (n <= 0.666) return { status: 'BERPOTENSI', category: 'sedang', classRange: '0,334–0,666' };
  return { status: 'SIAGA', category: 'tinggi', classRange: '0,667–1' };
}

// Parse only fields that ArcGIS ImageServer documents as pixel-value fields.
// Avoid walking arbitrary metadata, where an unrelated zero could be mistaken for a raster value.
function parsePixelScalar(value) {
  if (typeof value === 'number') return Number.isFinite(value) ? value : null;
  if (typeof value !== 'string') return null;
  const text = value.trim();
  if (!text || /^(?:nodata|null|nan|n\/a|no data)$/i.test(text)) return null;
  const match = text.match(/^[+-]?(?:\d+\.?\d*|\.\d+)(?:e[+-]?\d+)?/i);
  if (!match) return null;
  const parsed = Number(match[0]);
  return Number.isFinite(parsed) ? parsed : null;
}

function extractIndex(payload) {
  if (!payload || payload.error) return null;

  // ArcGIS ImageServer Identify returns `value` as the processed mosaic pixel
  // from the ImageServer default mosaic renderer. `properties.Values` describes individual
  // catalog rasters and must never override the mosaic value shown on the map.
  // `processedValues` is accepted only for older/nonstandard responses where
  // the documented mosaic `value` field is entirely absent.
  if (Object.prototype.hasOwnProperty.call(payload, 'value')) {
    const value = parsePixelScalar(payload.value);
    return value !== null && value >= 0 && value <= 1 ? value : null;
  }

  if (Object.prototype.hasOwnProperty.call(payload, 'processedValues')) {
    const processed = payload.processedValues;
    const candidates = Array.isArray(processed) ? processed : [processed];
    for (const item of candidates) {
      const value = parsePixelScalar(item);
      if (value !== null && value >= 0 && value <= 1) return value;
    }
  }
  return null;
}

// InaRISK ImageServer metadata declares native spatial reference EPSG:3395 and 100 m pixels.
// Convert WGS84 GPS coordinates to World Mercator (ellipsoidal), not Web Mercator EPSG:3857.
function toWorldMercator3395(lat, lon) {
  const a = 6378137, e = 0.08181919084262149;
  const phi = Math.max(-85, Math.min(85, Number(lat))) * Math.PI / 180;
  const lambda = Number(lon) * Math.PI / 180;
  const sinPhi = Math.sin(phi);
  const x = a * lambda;
  const y = a * Math.log(Math.tan(Math.PI / 4 + phi / 2) * Math.pow((1 - e * sinPhi) / (1 + e * sinPhi), e / 2));
  return { x, y };
}

async function identifyProjected(layer, point) {
  const params = new URLSearchParams({
    f: 'json',
    geometry: JSON.stringify({ x: point.x, y: point.y, spatialReference: { wkid: 3395 } }),
    geometryType: 'esriGeometryPoint',
    sr: '3395',
    returnGeometry: 'false',
    // ArcGIS returns `value` as the processed mosaic pixel. Catalog pixel lists are not used.
    returnPixelValues: 'false',
    returnCatalogItems: 'false',
    pixelSize: JSON.stringify({ x: PIXEL_SIZE_M, y: PIXEL_SIZE_M })
  });
  const response = await fetch(`${ROOT}${layer.name}/ImageServer/identify?${params}`, {
    headers: { Accept: 'application/json', 'User-Agent': 'FikriWeather/4.0 InaRISK index lookup' },
    signal: AbortSignal.timeout(7000)
  });
  if (!response.ok) throw new Error(`InaRISK ${layer.name} HTTP ${response.status}`);
  const payload = await response.json();
  if (payload?.error) throw new Error(`InaRISK ${layer.name}: ${payload.error.message || 'identify gagal'}`);
  const value = extractIndex(payload);
  if (value === null || value < 0 || value > 1) throw new Error('Nilai mosaic raster untuk renderer peta tidak tersedia atau di luar rentang indeks 0–1.');
  return value;
}

async function identify(layer, lat, lon) {
  return identifyProjected(layer, toWorldMercator3395(lat, lon));
}

function summarizeNeighborhood(values) {
  const samples = Array.isArray(values) ? values.map(num) : [];
  const valid = samples.filter(value => value !== null && value >= 0 && value <= 1);
  if (!valid.length) return { value: null, centerValue: null, minNearbyValue: null, maxNearbyValue: null, sampleCount: 0, sampleValues: samples };
  const sorted = [...valid].sort((a, b) => a - b);
  const middle = Math.floor(sorted.length / 2);
  const medianValue = sorted.length % 2 ? sorted[middle] : (sorted[middle - 1] + sorted[middle]) / 2;
  // A single sample is the exact selected pixel. Nine-value inputs remain
  // supported only for the legacy neighborhood-summary diagnostic helper.
  const centerValue = samples.length === 1 ? samples[0] : (samples.length >= 5 && samples[4] !== null && samples[4] >= 0 && samples[4] <= 1 ? samples[4] : null);
  return {
    value: centerValue,
    centerValue,
    medianValue,
    minNearbyValue: samples.length === 1 ? null : sorted[0],
    maxNearbyValue: samples.length === 1 ? null : sorted[sorted.length - 1],
    sampleCount: valid.length,
    sampleValues: samples
  };
}

async function identifyNeighborhood(layer, lat, lon) {
  // The selected point is the authoritative location. One Identify request per
  // layer uses the same ImageServer data source as the map overlay, using the service default renderer.
  // Sampling eight neighbouring cells added sixteen more network calls and could
  // make the analysis stall; nearby pixels are not substituted for the clicked pixel.
  const value = await identify(layer, lat, lon);
  const summary = summarizeNeighborhood([value]);
  if (summary.value === null) throw new Error('Piksel raster tepat pada koordinat terpilih tidak berhasil dibaca.');
  return {
    ...summary,
    sampleRadiusM: 0,
    sampleMethod: 'Satu piksel raster tepat pada koordinat terpilih; layer InaRISK sama dengan peta',
    pointOnlyAvailable: true
  };
}

exports._test = { level, extractIndex, parsePixelScalar, summarizeNeighborhood, toWorldMercator3395, identify, identifyNeighborhood, identifyProjected, LAYERS, ROOT };
exports.handler = async event => {
  const lat = num(event.queryStringParameters?.lat);
  const lon = num(event.queryStringParameters?.lon);
  if (lat === null || lon === null || lat < -11.5 || lat > 6.8 || lon < 94 || lon > 142) {
    return json(400, { ok: false, error: 'Koordinat harus valid dan berada di wilayah Indonesia.' });
  }

  // Keep cache keys at sub-meter scale so nearby pins on opposite sides of a raster-cell boundary never share a pixel result.
  const key = `${lat.toFixed(6)},${lon.toFixed(6)}`;
  const cached = CACHE.get(key);
  if (cached && Date.now() - cached.at < TTL_MS) {
    return json(200, cached.value, 'public, max-age=600, stale-while-revalidate=300');
  }

  const entries = await Promise.all(Object.entries(LAYERS).map(async ([kind, layer]) => {
    try {
      const sampled = await identifyNeighborhood(layer, lat, lon);
      const graded = level(sampled.value);
      return [kind, { ...sampled, status: graded.status, category: graded.category, classRange: graded.classRange, source: layer.label, dataType: 'indeks kerawanan dasar raster', available: graded.category !== null, note: graded.category === null ? 'Piksel tepat di koordinat terpilih tidak terbaca; sampel sekitar hanya ditampilkan sebagai konteks dan tidak menggantikan nilai titik.' : null }];
    } catch (error) {
      return [kind, { value: null, status: 'DATA BELUM TERSEDIA', category: null, source: layer.label, dataType: 'indeks kerawanan dasar raster', available: false, note: 'Piksel titik pada raster tidak berhasil dibaca; sistem lokasi akan mencoba estimasi mandiri dari indikator yang tersedia.' }];
    }
  }));
  const hazards = Object.fromEntries(entries);
  const availableCount = Object.values(hazards).filter(item => item.available).length;
  const value = {
    ok: true,
    hazards,
    source: 'InaRISK BNPB ImageServer nasional',
    location: { latitude: lat, longitude: lon },
    checkedAt: new Date().toISOString(),
    note: 'Nilai utama adalah satu piksel tepat di koordinat yang dipilih dari layer InaRISK yang sama dengan peta (renderer bawaan layanan). InaRISK adalah kerawanan dasar, bukan prakiraan kejadian atau peringatan aktif.',
    availableCount
  };
  if (availableCount) {
    CACHE.set(key, { at: Date.now(), value });
    if (CACHE.size > 500) CACHE.delete(CACHE.keys().next().value);
  }
  return json(200, value, availableCount ? 'public, max-age=600, stale-while-revalidate=300' : 'no-store');
};
