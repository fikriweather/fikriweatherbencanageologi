'use strict';

// Open-Meteo Air Quality API (CAMS global) is used as a regional model estimate,
// not as a substitute for a local monitoring-station measurement.
const CACHE = new Map();
const json = (statusCode, body, cache='no-store') => ({
  statusCode,
  headers: {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': cache,
    'Access-Control-Allow-Origin': '*',
    'X-Content-Type-Options': 'nosniff'
  },
  body: JSON.stringify(body)
});
const num = v => v !== null && v !== undefined && v !== '' && Number.isFinite(Number(v)) ? Number(v) : null;

exports.handler = async event => {
  const lat = num(event.queryStringParameters?.lat);
  const lon = num(event.queryStringParameters?.lon);
  if (lat === null || lon === null || Math.abs(lat) > 90 || Math.abs(lon) > 180) {
    return json(400, { ok: false, error: 'Koordinat kualitas udara tidak valid.' });
  }
  if (lat < -11.5 || lat > 6.8 || lon < 94 || lon > 142) {
    return json(400, { ok: false, error: 'Koordinat berada di luar cakupan Indonesia.' });
  }

  const requestedTimezone = String(event.queryStringParameters?.timezone || 'auto') === 'auto' ? 'auto' : 'Asia/Jakarta';
  const key = `${lat.toFixed(2)},${lon.toFixed(2)},${requestedTimezone}`;
  const cached = CACHE.get(key);
  if (cached && Date.now() - cached.at < 15 * 60 * 1000) {
    return json(200, cached.value, 'public, max-age=600, stale-while-revalidate=300');
  }

  try {
    const params = new URLSearchParams({
      latitude: String(lat),
      longitude: String(lon),
      current: 'us_aqi,european_aqi,pm2_5,pm10,ozone',
      hourly: 'us_aqi,pm2_5,pm10,ozone',
      forecast_days: '5',
      timezone: requestedTimezone,
      domains: 'cams_global'
    });
    const response = await fetch(`https://air-quality-api.open-meteo.com/v1/air-quality?${params}`, {
      headers: { 'Accept': 'application/json', 'User-Agent': 'FikriWeather/3.1 air-quality' },
      signal: AbortSignal.timeout(11000)
    });
    if (!response.ok) throw new Error(`Layanan kualitas udara mengembalikan HTTP ${response.status}`);
    const raw = await response.json();
    const hourly = raw.hourly || {};
    const times = Array.isArray(hourly.time) ? hourly.time : [];
    const hourlyRows = times.map((time, i) => ({
      time,
      us_aqi: num(hourly.us_aqi?.[i]),
      european_aqi: num(hourly.european_aqi?.[i]),
      pm2_5: num(hourly.pm2_5?.[i]),
      pm10: num(hourly.pm10?.[i]),
      ozone: num(hourly.ozone?.[i])
    }));
    let current = raw.current ? {
      time: raw.current.time || null,
      us_aqi: num(raw.current.us_aqi),
      european_aqi: num(raw.current.european_aqi),
      pm2_5: num(raw.current.pm2_5),
      pm10: num(raw.current.pm10),
      ozone: num(raw.current.ozone)
    } : null;

    // If current values are absent, use only a nearby published model time.
    // This is still clearly timestamped as a model estimate, not an observation.
    if (!current || Object.values(current).filter(v => typeof v === 'number').every(v => v === null)) {
      const now = Date.now();
      const nearby = hourlyRows
        .filter(x => x.time && (x.us_aqi !== null || x.pm2_5 !== null || x.pm10 !== null))
        .map(x => ({ ...x, delta: Math.abs((new Date(`${x.time}:00Z`).getTime() - Number(raw.utc_offset_seconds || 0) * 1000) - now) }))
        .filter(x => Number.isFinite(x.delta) && x.delta <= 3 * 60 * 60 * 1000)
        .sort((a, b) => a.delta - b.delta)[0];
      if (nearby) {
        const { delta, ...rest } = nearby;
        current = rest;
      }
    }

    if (!current || (current.us_aqi === null && current.pm2_5 === null && current.pm10 === null)) {
      throw new Error('Model kualitas udara belum memberikan AQI maupun data partikulat untuk koordinat ini.');
    }

    const value = {
      ok: true,
      current,
      hourly: hourlyRows,
      meta: {
        source: 'Open-Meteo Air Quality API / CAMS global',
        timezone: raw.timezone || requestedTimezone,
        utc_offset_seconds: raw.utc_offset_seconds ?? null,
        resolution_km: 45,
        temporal_resolution: '3-hourly',
        fetched_at: new Date().toISOString(),
        note: 'Estimasi model grid regional, bukan pembacaan sensor lokal.'
      }
    };
    CACHE.set(key, { at: Date.now(), value });
    if (CACHE.size > 400) CACHE.delete(CACHE.keys().next().value);
    return json(200, value, 'public, max-age=600, stale-while-revalidate=300');
  } catch (error) {
    return json(502, {
      ok: false,
      error: 'Data kualitas udara tidak berhasil diperoleh. Tidak ada angka pengganti yang dibuat.'
    });
  }
};
