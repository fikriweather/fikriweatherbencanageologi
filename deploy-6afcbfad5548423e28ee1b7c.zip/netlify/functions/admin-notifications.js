'use strict';
const { response, cookieHeaders, getSession, parseBody, db } = require('./lib/fw-server.cjs');
exports.handler = async event => {
  const cors = cookieHeaders(event);
  try {
    if (event.httpMethod === 'OPTIONS') return { statusCode: 204, headers: { ...cors, 'Access-Control-Allow-Methods': 'GET,POST,DELETE,OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type' }, body: '' };
    const session = await getSession(event);
    if (!session) return response(401, { ok: false, error: 'Silakan login sebagai admin.' }, cors);
    if (session.role !== 'admin') return response(403, { ok: false, error: 'Akses khusus admin.' }, cors);

    if (event.httpMethod === 'GET') {
      const items = await db('admin_notifications', { query: 'select=id,category,title,body,url,created_at,read_at&order=created_at.desc&limit=50' }) || [];
      return response(200, { ok: true, items, vapidPublicKey: process.env.VAPID_PUBLIC_KEY || '' }, cors);
    }
    if (event.httpMethod === 'POST') {
      const body = parseBody(event);
      if (body.action === 'read') {
        const id = String(body.id || '').trim();
        if (!id || id.length > 64) return response(400, { ok: false, error: 'ID notifikasi tidak valid.' }, cors);
        await db('admin_notifications', { method: 'PATCH', query: `id=eq.${encodeURIComponent(id)}`, body: { read_at: new Date().toISOString() }, prefer: 'return=minimal' });
        return response(200, { ok: true }, cors);
      }
      const subscription = body.subscription;
      const endpoint = String(subscription?.endpoint || '').trim();
      let parsed;
      try { parsed = new URL(endpoint); } catch { parsed = null; }
      if (!parsed || parsed.protocol !== 'https:' || !subscription?.keys?.p256dh || !subscription?.keys?.auth) {
        return response(400, { ok: false, error: 'Data langganan push tidak valid.' }, cors);
      }
      if (endpoint.length > 2048) return response(400, { ok: false, error: 'Endpoint push terlalu panjang.' }, cors);
      await db('admin_push_subscriptions', {
        method: 'POST', query: 'on_conflict=endpoint',
        body: { endpoint, subscription }, prefer: 'resolution=merge-duplicates,return=minimal',
      });
      return response(200, { ok: true }, cors);
    }
    if (event.httpMethod === 'DELETE') {
      const endpoint = String(event.queryStringParameters?.endpoint || '').trim();
      if (!endpoint.startsWith('https://') || endpoint.length > 2048) return response(400, { ok: false, error: 'Endpoint tidak valid.' }, cors);
      await db('admin_push_subscriptions', { method: 'DELETE', query: `endpoint=eq.${encodeURIComponent(endpoint)}` });
      return response(200, { ok: true }, cors);
    }
    return response(405, { ok: false, error: 'Metode tidak didukung.' }, { ...cors, Allow: 'GET, POST, DELETE, OPTIONS' });
  } catch (e) {
    return response(e.statusCode || 500, { ok: false, error: e.message || 'Layanan notifikasi admin gagal.' }, cors);
  }
};
