'use strict';

const CACHE = new Map();
const SEARCH_TTL = 12 * 60 * 60 * 1000;
const ROUTE_TTL = 30 * 60 * 1000;
const WEATHER_TTL = 5 * 60 * 1000;
const WATER_TTL = 3 * 60 * 60 * 1000;
const HAZARD_TTL = 30 * 60 * 1000;
const TERRAIN_TTL = 12 * 60 * 60 * 1000;
const INDONESIA = { minLat: -11.5, maxLat: 6.8, minLon: 94, maxLon: 142 };
let nominatimLastAt = 0;
let nominatimQueue = Promise.resolve();
let footRouterLastAt = 0;

const json = (statusCode, body, cache = 'no-store') => ({
  statusCode,
  headers: {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': cache,
    'Access-Control-Allow-Origin': '*',
    'X-Content-Type-Options': 'nosniff'
  },
  body: JSON.stringify(body)
});
const clean = value => String(value || '').replace(/[<>\u0000-\u001f]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 100);
const norm = value => String(value || '').toLocaleLowerCase('id-ID').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]+/g, ' ').trim();
const number = value => value !== null && value !== undefined && value !== '' && Number.isFinite(Number(value)) ? Number(value) : null;
const insideIndonesia = (lat, lon) => Number.isFinite(lat) && Number.isFinite(lon) && lat >= INDONESIA.minLat && lat <= INDONESIA.maxLat && lon >= INDONESIA.minLon && lon <= INDONESIA.maxLon;
const timezoneForLongitude = lon => lon >= 127.5 ? 'Asia/Jayapura' : lon >= 115 ? 'Asia/Makassar' : 'Asia/Jakarta';
const timezoneForRegion = region => { const r = norm(region); if (/\b(maluku|papua)\b/.test(r)) return 'Asia/Jayapura'; if (/\b(bali|nusa tenggara|sulawesi)\b|kalimantan (selatan|timur|utara)/.test(r)) return 'Asia/Makassar'; if (/\b(sumatera|sumatra|jawa)\b|kalimantan (barat|tengah)/.test(r)) return 'Asia/Jakarta'; return null; };
const offsetForTimezone = zone => zone === 'Asia/Jayapura' ? '+09:00' : zone === 'Asia/Makassar' ? '+08:00' : '+07:00';
const cacheGet = (key, ttl) => { const row = CACHE.get(key); return row && Date.now() - row.at < ttl ? row.value : null; };
const cacheSet = (key, value) => { CACHE.set(key, { at: Date.now(), value }); if (CACHE.size > 500) CACHE.delete(CACHE.keys().next().value); };

async function fetchJson(url, timeoutMs = 10000, headers = {}) {
  const response = await fetch(url, { headers: { Accept: 'application/json', 'User-Agent': 'FikriWeather/4.0 mountain-weather' , ...headers }, signal: AbortSignal.timeout(timeoutMs) });
  if (!response.ok) throw new Error(`HTTP ${response.status}`);
  return response.json();
}
async function fetchText(url, body, timeoutMs = 18000) {
  const response = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8', Accept: 'application/json', 'User-Agent': 'FikriWeather/4.0 mountain-weather' },
    body: `data=${encodeURIComponent(body)}`,
    signal: AbortSignal.timeout(timeoutMs)
  });
  if (!response.ok) throw new Error(`Overpass HTTP ${response.status}`);
  return response.json();
}

const OVERPASS_ENDPOINTS = [
  'https://overpass-api.de/api/interpreter',
  'https://overpass.kumi.systems/api/interpreter',
  'https://overpass.nchc.org.tw/api/interpreter'
];
async function fetchOverpass(query, timeoutMs = 10000) {
  const errors = [];
  const budget = Math.max(3000, Math.min(12500, Number(timeoutMs) || 10000));
  const deadline = Date.now() + budget;
  for (let index = 0; index < OVERPASS_ENDPOINTS.length; index++) {
    const endpoint = OVERPASS_ENDPOINTS[index];
    const remaining = deadline - Date.now();
    if (remaining < 1200) break;
    const attemptTimeout = Math.min(remaining, index === 0 ? 6000 : 3500);
    try { return await fetchText(endpoint, query, attemptTimeout); }
    catch (error) { errors.push(`${new URL(endpoint).hostname}: ${error.message || 'gagal'}`); }
  }
  throw new Error(errors.join(' · ') || 'Server Overpass belum merespons dalam batas waktu.');
}
async function nominatim(query) {
  const run = async () => {
    const wait = Math.max(0, 1100 - (Date.now() - nominatimLastAt));
    if (wait) await new Promise(resolve => setTimeout(resolve, wait));
    nominatimLastAt = Date.now();
    const params = new URLSearchParams({ q: query, format: 'jsonv2', countrycodes: 'id', addressdetails: '1', extratags: '1', namedetails: '1', limit: '30', 'accept-language': 'id' });
    return fetchJson(`https://nominatim.openstreetmap.org/search?${params}`, 9000, { 'Accept-Language': 'id' });
  };
  const pending = nominatimQueue.then(run, run);
  nominatimQueue = pending.then(() => undefined, () => undefined);
  return pending;
}
function elevationValue(value) { const raw = String(value ?? '').trim().replace(',', '.'); const match = raw.match(/-?\d+(?:\.\d+)?/); return match ? number(match[0]) : null; }
function mountainFromNominatim(item) {
  const lat = number(item?.lat), lon = number(item?.lon);
  if (!insideIndonesia(lat, lon)) return null;
  const tags = item.extratags || {};
  const type = String(item.type || '').toLowerCase();
  const natural = String(tags.natural || '').toLowerCase();
  const isPeak = ['peak', 'volcano', 'mountain_range', 'hill', 'ridge'].includes(type) || ['peak', 'volcano', 'mountain_range'].includes(natural) || String(tags.mountain || '').toLowerCase() === 'yes';
  if (!isPeak) return null;
  const name = clean(item.name || item.namedetails?.name || item.display_name?.split(',')[0]);
  if (!name) return null;
  const address = item.address || {};
  const area = [address.village, address.town, address.city, address.county, address.state].filter(Boolean).join(', ');
  return {
    id: `osm-${item.osm_type || 'node'}-${item.osm_id || item.place_id}`,
    name,
    aliases: [item.namedetails?.['name:id'], item.namedetails?.alt_name, tags.alt_name, tags.official_name].filter(Boolean),
    lat, lon,
    elevation: elevationValue(tags.ele),
    kind: type === 'volcano' || natural === 'volcano' || tags.volcano ? 'Gunung api' : type === 'mountain_range' ? 'Pegunungan' : 'Puncak/gunung',
    isVolcano: type === 'volcano' || natural === 'volcano' || !!tags.volcano,
    region: area || item.display_name || 'Indonesia',
    osmType: item.osm_type || null,
    osmId: item.osm_id || null,
    mapUrl: item.osm_type && item.osm_id ? `https://www.openstreetmap.org/${item.osm_type}/${item.osm_id}` : null,
    nameSource: 'OpenStreetMap · Nominatim'
  };
}
function mountainFromOverpass(item) {
  const tags = item.tags || {};
  const lat = number(item.lat ?? item.center?.lat), lon = number(item.lon ?? item.center?.lon);
  if (!insideIndonesia(lat, lon)) return null;
  const natural = String(tags.natural || '').toLowerCase();
  const mountain = String(tags.mountain || '').toLowerCase();
  if (!['peak', 'volcano', 'mountain_range'].includes(natural) && mountain !== 'yes') return null;
  const name = clean(tags.name || tags['name:id'] || tags.official_name || tags.alt_name);
  if (!name) return null;
  const type = item.type || 'node';
  return {
    id: `osm-${type}-${item.id}`, name,
    aliases: [tags['name:id'], tags.alt_name, tags.official_name].filter(Boolean),
    lat, lon, elevation: elevationValue(tags.ele),
    kind: natural === 'volcano' || tags.volcano ? 'Gunung api' : natural === 'mountain_range' ? 'Pegunungan' : 'Puncak/gunung',
    isVolcano: natural === 'volcano' || !!tags.volcano,
    region: [tags['addr:subdistrict'], tags['addr:city'], tags['addr:state']].filter(Boolean).join(', ') || 'Indonesia',
    osmType: type, osmId: item.id,
    mapUrl: `https://www.openstreetmap.org/${type}/${item.id}`,
    nameSource: 'OpenStreetMap · Overpass'
  };
}
async function searchMountains(q) {
  const queryName = String(q || '').replace(/^(gunung api|gunung|g)\s+/i, '').trim();
  const key = `search:${norm(queryName)}`;
  const cached = cacheGet(key, SEARCH_TTL);
  if (cached) return cached;
  let nominatimRows = [], overpassRows = [], errors = [];
  const escaped = queryName.replace(/[.*+?^${}()|[\]\\"]/g, '\\$&').slice(0, 70);
  const bbox = `${INDONESIA.minLat},${INDONESIA.minLon},${INDONESIA.maxLat},${INDONESIA.maxLon}`;
  const query = `[out:json][timeout:10];(
    nwr[~"^(name|alt_name|official_name|name:id)$"~"${escaped}",i]["natural"~"^(peak|volcano|mountain_range)$"](${bbox});
    nwr[~"^(name|alt_name|official_name|name:id)$"~"${escaped}",i]["mountain"="yes"](${bbox});
    nwr[~"^(name|alt_name|official_name|name:id)$"~"${escaped}",i]["volcano"](${bbox});
  );out center tags;`;
  const [nomResult, overResult] = await Promise.allSettled([
    nominatim(`${queryName}, Indonesia`),
    fetchOverpass(query, 11000)
  ]);
  if (nomResult.status === 'fulfilled') nominatimRows = nomResult.value;
  else errors.push(`Nominatim: ${nomResult.reason?.message || 'tidak merespons'}`);
  if (overResult.status === 'fulfilled') overpassRows = Array.isArray(overResult.value.elements) ? overResult.value.elements : [];
  else errors.push(`Overpass: ${overResult.reason?.message || 'tidak merespons'}`);

  const merged = new Map();
  for (const item of (Array.isArray(nominatimRows) ? nominatimRows : [])) {
    const value = mountainFromNominatim(item);
    if (value) merged.set(`${norm(value.name)}:${value.lat.toFixed(4)},${value.lon.toFixed(4)}`, value);
  }
  for (const item of overpassRows) {
    const value = mountainFromOverpass(item);
    if (value) merged.set(`${norm(value.name)}:${value.lat.toFixed(4)},${value.lon.toFixed(4)}`, value);
  }
  const rows = [...merged.values()].sort((a, b) => {
    const qa = norm(queryName), an = norm(a.name), bn = norm(b.name);
    const scoreA = an === qa ? -3 : an.startsWith(qa) ? -2 : (a.aliases || []).some(x => norm(x) === qa) ? -1 : 0;
    const scoreB = bn === qa ? -3 : bn.startsWith(qa) ? -2 : (b.aliases || []).some(x => norm(x) === qa) ? -1 : 0;
    return scoreA - scoreB || a.name.localeCompare(b.name, 'id');
  }).slice(0, 30);
  const value = {
    ok: true, query: q, normalizedQuery: queryName, results: rows, count: rows.length,
    sources: ['OpenStreetMap Nominatim', 'OpenStreetMap Overpass'], fetchedAt: new Date().toISOString(),
    note: rows.length
      ? 'Katalog menggabungkan unsur puncak, gunung api, gunung bernama, dan pegunungan yang terpetakan. Cakupan mengikuti data geografis yang tersedia, bukan jaminan daftar legal lengkap BIG.'
      : 'Nama belum ditemukan pada sumber geografis yang berhasil diakses. Coba nama lokal, nama resmi, atau ejaan alternatif.',
    warnings: errors
  };
  cacheSet(key, value);
  return value;
}

function pointSegmentDistanceMeters(point, start, end) {
  const meanLat = ((point.lat + start.lat + end.lat) / 3) * Math.PI / 180;
  const project = p => ({ x: p.lon * 111320 * Math.cos(meanLat), y: p.lat * 110540 });
  const p = project(point), a = project(start), b = project(end);
  const dx = b.x - a.x, dy = b.y - a.y, length2 = dx * dx + dy * dy;
  if (!length2) return Math.hypot(p.x - a.x, p.y - a.y);
  const t = Math.max(0, Math.min(1, ((p.x - a.x) * dx + (p.y - a.y) * dy) / length2));
  return Math.hypot(p.x - (a.x + t * dx), p.y - (a.y + t * dy));
}
function simplifyGeometry(points, toleranceMeters = 12) {
  if (points.length <= 2) return points;
  const keep = new Uint8Array(points.length); keep[0] = 1; keep[points.length - 1] = 1;
  const stack = [[0, points.length - 1]];
  while (stack.length) {
    const [first, last] = stack.pop(); let maxDistance = toleranceMeters, maxIndex = -1;
    for (let i = first + 1; i < last; i++) {
      const distance = pointSegmentDistanceMeters(points[i], points[first], points[last]);
      if (distance > maxDistance) { maxDistance = distance; maxIndex = i; }
    }
    if (maxIndex >= 0) { keep[maxIndex] = 1; stack.push([first, maxIndex], [maxIndex, last]); }
  }
  return points.filter((_, i) => keep[i]);
}
function normalizeGeometry(coords) {
  if (!Array.isArray(coords)) return [];
  const points = coords.map(p => ({ lat: number(p.lat), lon: number(p.lon) })).filter(p => insideIndonesia(p.lat, p.lon));
  if (points.length <= 240) return points;
  let simplified = points;
  for (const tolerance of [12, 24, 48, 96, 192, 384]) {
    simplified = simplifyGeometry(points, tolerance);
    if (simplified.length <= 240) return simplified;
  }
  const sampled = [];
  for (let i = 0; i < 240; i++) sampled.push(simplified[Math.round(i * (simplified.length - 1) / 239)]);
  return sampled;
}
function routeFromRelation(item) {
  const tags = item.tags || {};
  const members = Array.isArray(item.members) ? item.members : [];
  const segments = members.filter(m => m.type === 'way' && Array.isArray(m.geometry)).map(m => normalizeGeometry(m.geometry)).filter(g => g.length >= 2).slice(0, 24);
  const waypoints = members.filter(m => m.type === 'node' && m.tags?.name && insideIndonesia(number(m.lat), number(m.lon))).map(m => ({ name: clean(m.tags.name), lat: Number(m.lat), lon: Number(m.lon), kind: clean(m.tags.amenity || m.tags.tourism || m.role || 'titik rute') })).slice(0, 50);
  if (!segments.length) return null;
  return { id: `relation-${item.id}`, name: clean(tags.name || tags.ref || 'Jalur pendakian terpetakan'), kind: 'Rute hiking OSM', network: tags.network || null, difficulty: tags.sac_scale || null, distance: tags.distance || null, duration: tags.duration || null, segments, waypoints, source: 'OpenStreetMap · relasi route=hiking/foot' };
}
function routeFromWay(item) {
  const tags = item.tags || {};
  const highway = String(tags.highway || '').toLowerCase();
  if (!['path', 'footway', 'track', 'steps'].includes(highway)) return null;
  if (highway === 'track' && !/^(yes|designated|permissive)$/i.test(String(tags.foot || '')) && !tags.sac_scale && !tags.trail_visibility) return null;
  const geometry = normalizeGeometry(item.geometry);
  if (geometry.length < 2) return null;
  const lengthKm = geometry.slice(1).reduce((sum, point, index) => sum + haversineMeters(geometry[index], point), 0) / 1000;
  if (lengthKm < 0.08) return null;
  return {
    id: `way-${item.id}`,
    name: clean(tags.name || tags.ref || (highway === 'path' ? 'Jejak pendakian terpetakan' : 'Jejak akses pejalan kaki')),
    kind: 'Jejak jalur OSM (bukan relasi rute resmi)',
    network: null,
    difficulty: tags.sac_scale || null,
    distance: tags.distance || null,
    segments: [geometry],
    waypoints: [],
    tags: {
      highway, surface: tags.surface || null, trailVisibility: tags.trail_visibility || null,
      foot: tags.foot || null, sacScale: tags.sac_scale || null, name: tags.name || null
    },
    source: 'OpenStreetMap · geometri jalur terpetakan'
  };
}
function routeDistanceKm(route) {
  return (route.segments || []).reduce((sum, line) => sum + line.slice(1).reduce((part, point, index) =>
    part + haversineMeters(line[index], point), 0), 0) / 1000;
}
function routeProximityMeters(route, point) {
  let best = Infinity;
  for (const line of route.segments || []) for (const coord of line) best = Math.min(best, haversineMeters(point, coord));
  return best;
}
async function findRoutes(lat, lon, radius, mountainName = '') {
  const key = `routes:${lat.toFixed(4)}:${lon.toFixed(4)}:${radius}`;
  const cached = cacheGet(key, ROUTE_TTL);
  if (cached) return cached;
  const pathRadius = Math.min(radius, 15000);
  const query = `[out:json][timeout:14];(
    relation(around:${radius},${lat},${lon})["type"="route"]["route"~"^(hiking|foot)$"];
    way(around:${pathRadius},${lat},${lon})["highway"~"^(path|footway|steps)$"];
    way(around:${Math.min(pathRadius, 12000)},${lat},${lon})["highway"="track"]["foot"~"^(yes|designated|permissive)$"];
    way(around:${Math.min(pathRadius, 12000)},${lat},${lon})["highway"="track"]["sac_scale"];
    node(around:${radius},${lat},${lon})["tourism"="alpine_hut"];
    node(around:${radius},${lat},${lon})["name"~"base ?camp|pos pendakian|pos registrasi|gerbang pendakian",i];
    way(around:${radius},${lat},${lon})["name"~"base ?camp|pos pendakian|pos registrasi|gerbang pendakian",i];
  );out body geom;`;
  const errors = [];
  let data = null;
  try { data = await fetchOverpass(query, 13500); }
  catch (error) { errors.push(error.message); }

  const relationRoutes = [];
  const mappedWays = [];
  let routeQueryAvailable = !!data;
  for (const item of (data?.elements || [])) {
    if (item.type === 'relation') {
      const route = routeFromRelation(item);
      if (route) relationRoutes.push(route);
    } else if (item.type === 'way') {
      const route = routeFromWay(item);
      if (route) mappedWays.push(route);
    }
  }
  // The three named Merapi hiking relations are verified OpenStreetMap route
  // objects. Query them directly as a second chance when a spatial Overpass
  // search misses the relation geometry; never fabricate route coordinates.
  if (!relationRoutes.length && /merapi/i.test(mountainName)) {
    try {
      const explicit = await fetchOverpass('[out:json][timeout:8];(relation(17254520);relation(17254538);relation(17254521););out body geom;', 5500);
      routeQueryAvailable = true;
      for (const item of (explicit?.elements || [])) {
        if (item.type !== 'relation') continue;
        const route = routeFromRelation(item);
        if (route) relationRoutes.push(route);
      }
    } catch (error) { errors.push(`Relasi jalur Merapi OSM: ${error.message || 'belum tersedia'}`); }
  }
  const summit = { lat, lon };
  relationRoutes.sort((a, b) =>
    routeProximityMeters(a, summit) - routeProximityMeters(b, summit) ||
    routeDistanceKm(b) - routeDistanceKm(a)
  );
  const routes = relationRoutes.slice(0, 8);
  if (!routes.length && mappedWays.length) {
    mappedWays.sort((a, b) => {
      const score = route => (route.tags?.sacScale ? 4 : 0) + (route.tags?.name ? 2 : 0) +
        (route.tags?.trailVisibility ? 1 : 0) + (/^(yes|designated|permissive)$/.test(route.tags?.foot || '') ? 1 : 0);
      return score(b) - score(a) ||
        routeProximityMeters(a, summit) - routeProximityMeters(b, summit);
    });
    // Bundle connected/mapped path segments into one visible trail network. The UI
    // only joins endpoints that are genuinely close; it never draws a summit shortcut.
    const chosen = mappedWays.slice(0, 45);
    routes.push({
      id: `mapped-network-${lat.toFixed(3)}-${lon.toFixed(3)}`,
      name: 'Jejak jalur pendakian terpetakan di sekitar gunung',
      kind: 'Jaringan jalur OSM (bukan relasi rute resmi)',
      network: null,
      difficulty: chosen.find(route => route.difficulty)?.difficulty || null,
      distance: null,
      duration: null,
      segments: chosen.flatMap(route => route.segments),
      waypoints: [],
      source: 'OpenStreetMap · gabungan geometri highway=path/footway/steps serta track bertag akses pejalan kaki'
    });
  }
  // Optional walking-network fallback. It only draws a route if a named access/basecamp
  // object is actually present in OSM and the public foot router returns a valid GeoJSON
  // path. It never connects the summit with a straight, invented line.
  if (!routes.length && data?.elements?.length) {
    const accessCandidates = data.elements.map(item => {
      const tags = item.tags || {};
      const name = clean(tags.name || tags['name:id'] || '');
      const isAccess = tags.tourism === 'alpine_hut' || /base\s?camp|pos pendakian|pos registrasi|gerbang pendakian/i.test(name);
      const geometry = item.type === 'node' ? [item] : (Array.isArray(item.geometry) ? item.geometry : []);
      const candidateLat = geometry.length ? geometry.reduce((sum, point) => sum + number(point.lat), 0) / geometry.length : null;
      const candidateLon = geometry.length ? geometry.reduce((sum, point) => sum + number(point.lon), 0) / geometry.length : null;
      if (!isAccess || !name || !insideIndonesia(candidateLat, candidateLon)) return null;
      const point = { lat: candidateLat, lon: candidateLon };
      return { name, point, distance: haversineMeters(summit, point), osmType: item.type, osmId: item.id };
    }).filter(Boolean).filter(row => row.distance >= 250 && row.distance <= radius).sort((a, b) => a.distance - b.distance);
    const access = accessCandidates[0];
    if (access) {
      try {
        // Public FOSSGIS foot-routing service asks clients to keep requests at
        // or below one request per second. Route requests are also cached above.
        const wait = Math.max(0, 1100 - (Date.now() - footRouterLastAt));
        if (wait) await new Promise(resolve => setTimeout(resolve, wait));
        footRouterLastAt = Date.now();
        const routerUrl = `https://routing.openstreetmap.de/routed-foot/route/v1/driving/${access.point.lon},${access.point.lat};${lon},${lat}?overview=full&geometries=geojson&steps=false`;
        const routed = await fetchJson(routerUrl, 7500);
        const raw = routed?.routes?.[0]?.geometry?.coordinates;
        const geometry = Array.isArray(raw) ? normalizeGeometry(raw.map(pair => ({ lon: pair?.[0], lat: pair?.[1] }))) : [];
        const distanceM = number(routed?.routes?.[0]?.distance);
        if (routed?.code === 'Ok' && geometry.length >= 3 && distanceM !== null && distanceM >= access.distance * 0.85 && distanceM <= 50000) {
          routes.push({
            id: `foot-network-${access.osmType}-${access.osmId}`,
            name: `${access.name} → ${clean(mountainName || 'koordinat puncak')}`,
            kind: 'Rute berjalan kaki berbasis jaringan OSM · bukan jalur resmi',
            network: null, difficulty: null, distance: `${(distanceM / 1000).toFixed(2)} km · routing jalan kaki OSM`, duration: null,
            segments: [geometry],
            waypoints: [{ name: access.name, lat: access.point.lat, lon: access.point.lon, kind: 'Akses/basecamp terpetakan OSM' }],
            source: 'OpenStreetMap · Overpass + routing.openstreetmap.de/routed-foot'
          });
        }
      } catch (error) { errors.push(`Routing kaki OSM: ${error.message || 'tidak tersedia'}`); }
    }
  }
  const value = {
    ok: true, queryAvailable: routeQueryAvailable, routes: routes.slice(0, 8), count: routes.length,
    mappedWayCount: mappedWays.length, radiusMeters: radius,
    source: 'OpenStreetMap · Overpass', fetchedAt: new Date().toISOString(),
    note: !routeQueryAvailable
      ? 'Layanan pencarian jalur OSM sedang tidak merespons. Geometri rute belum dapat diverifikasi; analisis risiko tetap berjalan pada 7 titik area sekitar gunung.'
      : routes.length
      ? (routes[0].kind.includes('Jaringan') ?
        'Jalur ditampilkan dari jejak hiking/pejalan kaki yang dipetakan dan ditag pada OSM. Segmen tidak dihubungkan jika berjauhan; kesulitan dapat belum terklasifikasi. Jalur bukan verifikasi resmi atau kondisi lapangan.' :
        'Relasi hiking/foot yang terpetakan ditemukan. Awal rute bukan otomatis basecamp resmi; verifikasi akses, pembukaan, dan kondisi dengan pengelola.')
      : 'Belum ditemukan geometri hiking/pejalan kaki atau rute jaringan kaki yang terhubung ke objek akses OSM pada radius pencarian. Peta tetap menampilkan titik skrining area; sistem tidak menggambar garis buatan menuju puncak.',
    warnings: errors
  };
  if (data) cacheSet(key, value); // Cache genuine empty-map results, never a transient Overpass outage.
  return value;
}

async function getElevations(points) {
  const locations = points.map(p => `${p.lat},${p.lon}`).join('|');
  const datasets = ['aster30m', 'srtm90m'];
  const attempts = datasets.map(dataset => fetchJson(`https://api.opentopodata.org/v1/${dataset}?locations=${encodeURIComponent(locations)}`, 4500).then(d => {
    const values = Array.isArray(d.results) ? d.results.map(x => number(x?.elevation)) : [];
    if (values.length !== points.length || values.some(v => v === null)) throw new Error('DEM tidak lengkap');
    return { values, source: `OpenTopoData ${dataset.toUpperCase()}` };
  }));
  try { return await Promise.any(attempts); }
  catch { return { values: points.map(() => null), source: 'DEM khusus tidak tersedia; memakai elevasi DEM bawaan Open-Meteo bila dikembalikan.' }; }
}

function hourlyAt(data, date, time) {
  const hourly = data?.hourly || {}, times = Array.isArray(hourly.time) ? hourly.time : [];
  const target = `${date}T${time}`;
  const offset = offsetForTimezone(data?.timezone || 'Asia/Jakarta');
  let index = times.indexOf(target);
  if (index < 0) {
    let best = -1, delta = Infinity;
    for (let i = 0; i < times.length; i++) {
      const d = Math.abs(new Date(`${times[i]}:00${offset}`).getTime() - new Date(`${target}:00${offset}`).getTime());
      if (d < delta) { delta = d; best = i; }
    }
    if (delta <= 30 * 60000) index = best;
  }
  if (index < 0) return null;
  const fields = ['temperature_2m','relative_humidity_2m','apparent_temperature','precipitation_probability','precipitation','rain','showers','weather_code','cloud_cover','wind_speed_10m','wind_gusts_10m','wind_direction_10m','visibility','uv_index','cape','freezing_level_height','soil_moisture_0_to_7cm','soil_moisture_7_to_28cm','soil_moisture_28_to_100cm'];
  const hour = { time: times[index] };
  for (const field of fields) hour[field] = number(hourly[field]?.[index]);
  const precipitationSeries = Array.isArray(hourly.precipitation) ? hourly.precipitation : [];
  const next24 = precipitationSeries.slice(index, index + 24).map(number);
  const next6 = precipitationSeries.slice(index, index + 6).map(number);
  const next72 = precipitationSeries.slice(index, index + 72).map(number);
  hour.precipitation_24h = next24.length === 24 && next24.every(value => value !== null) ? next24.reduce((sum, value) => sum + value, 0) : null;
  hour.precipitation_6h = next6.length === 6 && next6.every(value => value !== null) ? next6.reduce((sum, value) => sum + value, 0) : null;
  hour.precipitation_72h = next72.length === 72 && next72.every(value => value !== null) ? next72.reduce((sum, value) => sum + value, 0) : null;
  return { hour, timezone: data.timezone || 'Asia/Jakarta', modelElevation: number(data.elevation), source: 'Open-Meteo · prakiraan model per jam' };
}
async function mountainWeather(points, date, time, paceKmh = 2) {
  const key = `weather:${date}:${time}:${paceKmh}:${points.map(p => `${p.lat.toFixed(4)},${p.lon.toFixed(4)},${p.elevation ?? ''},${p.distanceAlongRouteKm ?? ''}`).join('|')}`;
  const cached = cacheGet(key, WEATHER_TTL); if (cached) return cached;
  const demPromise = getElevations(points);
  const elevation = points.map(p => number(p.elevation));
  const timezone = ['Asia/Jakarta','Asia/Makassar','Asia/Jayapura'].includes(points[0].timezone) ? points[0].timezone : timezoneForLongitude(points[0].lon);
  const params = new URLSearchParams({
    latitude: points.map(p => p.lat).join(','), longitude: points.map(p => p.lon).join(','),
    hourly: 'temperature_2m,relative_humidity_2m,apparent_temperature,precipitation_probability,precipitation,rain,showers,weather_code,cloud_cover,wind_speed_10m,wind_gusts_10m,wind_direction_10m,visibility,uv_index,cape,freezing_level_height,soil_moisture_0_to_7cm,soil_moisture_7_to_28cm,soil_moisture_28_to_100cm',
    forecast_days: '10', timezone, wind_speed_unit: 'kmh', precipitation_unit: 'mm'
  });
  if (elevation.length && elevation.every(v => v !== null)) params.set('elevation', elevation.map(String).join(','));
  const elevationProvided = elevation.length > 0 && elevation.every(v => v !== null);
  const [raw, dem] = await Promise.all([fetchJson(`https://api.open-meteo.com/v1/forecast?${params}`, 8500), demPromise]);
  const datasets = Array.isArray(raw) ? raw : points.length === 1 ? [raw] : (Array.isArray(raw?.data) ? raw.data : [raw]);
  const elevations = points.map((point, index) => elevationProvided ? elevation[index] : number(datasets[index]?.elevation) ?? dem.values[index] ?? number(point.elevation) ?? null);
  const routeMode = points.length > 1;
  const itinerary = computeItinerary(points, elevations, date, time, timezone, paceKmh);
  const results = points.map((point, index) => {
    const arrival = itinerary.points[index];
    const selected = hourlyAt(datasets[index], arrival.arrivalDate, arrival.arrivalTime);
    const elev = elevations[index];
    return {
      ...arrival,
      elevation: elev,
      elevationSource: elevationProvided ? 'Elevasi titik diterapkan pada query model' : number(datasets[index]?.elevation) !== null ? 'DEM bawaan Open-Meteo (elevasi model)' : dem.values[index] !== null ? dem.source + ' (rujukan elevasi; model memakai DEM bawaannya)' : 'Elevasi tidak tersedia',
      ...(selected || { available: false, error: 'Slot prakiraan untuk waktu kedatangan titik tidak tersedia.' }),
      available: !!selected,
      slopeDegrees: index > 0 && elevations[index - 1] !== null && elev !== null && arrival.segmentDistanceKm > 0 ? Math.atan(Math.abs(elev - elevations[index - 1]) / (arrival.segmentDistanceKm * 1000)) * 180 / Math.PI : null
    };
  });
  const value = {
    ok: true, date, time, timezone, points: results,
    itinerary: { ...itinerary.summary, routeMode, note: routeMode ? itinerary.summary.routeNote : 'Tidak ada geometri jalur terpilih; prakiraan berlaku pada koordinat gunung dan jam yang dipilih.' },
    source: 'Open-Meteo', elevationSource: dem.source, fetchedAt: new Date().toISOString(),
    note: 'Prakiraan model pada koordinat dan elevasi tiap titik. ETA adalah estimasi berdasarkan panjang geometri jalur, tempo pendakian perencanaan internal, dan elevasi DEM jika tersedia; bukan waktu resmi pengelola.'
  };
  cacheSet(key, value); return value;
}


function haversineMeters(a, b) {
  const rad = value => value * Math.PI / 180;
  const dLat = rad(b.lat - a.lat), dLon = rad(b.lon - a.lon);
  const x = Math.sin(dLat / 2) ** 2 + Math.cos(rad(a.lat)) * Math.cos(rad(b.lat)) * Math.sin(dLon / 2) ** 2;
  return 6371000 * 2 * Math.asin(Math.sqrt(x));
}
function addLocalMinutes(date, time, minutes) {
  const [year, month, day] = date.split('-').map(Number);
  const [hour, minute] = time.split(':').map(Number);
  const stamp = new Date(Date.UTC(year, month - 1, day, hour, minute + minutes));
  return { date: `${stamp.getUTCFullYear()}-${String(stamp.getUTCMonth() + 1).padStart(2, '0')}-${String(stamp.getUTCDate()).padStart(2, '0')}`, time: `${String(stamp.getUTCHours()).padStart(2, '0')}:${String(stamp.getUTCMinutes()).padStart(2, '0')}` };
}
function computeItinerary(points, elevations, date, startTime, timezone, paceKmh = 2) {
  let elapsedMinutes = 0, distanceKm = 0, ascentM = 0;
  const output = points.map((point, index) => {
    let segmentDistanceKm = 0, segmentAscentM = 0;
    if (index > 0) {
      const previousPathDistance = number(points[index - 1].distanceAlongRouteKm), currentPathDistance = number(point.distanceAlongRouteKm);
      segmentDistanceKm = previousPathDistance !== null && currentPathDistance !== null && currentPathDistance >= previousPathDistance
        ? currentPathDistance - previousPathDistance
        : haversineMeters(points[index - 1], point) / 1000;
      const previousElevation = number(elevations[index - 1]), currentElevation = number(elevations[index]);
      if (previousElevation !== null && currentElevation !== null) segmentAscentM = Math.max(0, currentElevation - previousElevation);
      // Conservative planning estimate from mapped distance and ascent; not an official duration.
      elapsedMinutes += Math.max(12, segmentDistanceKm / paceKmh * 60 + segmentAscentM / 600 * 60);
      distanceKm += segmentDistanceKm;
      ascentM += segmentAscentM;
    }
    const arrival = addLocalMinutes(date, startTime, elapsedMinutes);
    return {
      ...point,
      arrivalDate: arrival.date,
      arrivalTime: arrival.time,
      arrivalMinutes: Math.round(elapsedMinutes),
      cumulativeHours: elapsedMinutes / 60,
      segmentDistanceKm,
      cumulativeDistanceKm: distanceKm,
      segmentAscentM,
      cumulativeAscentM: ascentM,
      arrivalTimezone: timezone,
      itineraryEstimated: points.length > 1
    };
  });
  return {
    points: output,
    summary: {
      totalDistanceKm: distanceKm,
      positiveAscentM: ascentM,
      estimatedDurationHours: elapsedMinutes / 60,
      method: 'Estimasi waktu menggunakan panjang jalur terpetakan dan perubahan elevasi yang tersedia; bukan durasi resmi pengelola.',
      elevationComplete: elevations.length === points.length && elevations.every(value => number(value) !== null),
      routeNote: points.length > 1 ? 'Titik mengikuti geometri jalur terpetakan; titik awal bukan otomatis basecamp resmi.' : 'Belum ada jalur terpetakan; waktu hanya menunjukkan waktu yang dipilih, bukan estimasi durasi pendakian.'
    }
  };
}
function classifyBaseline(value) {
  const n = number(value);
  if (n === null || n < 0 || n > 1) return { status: 'DATA TIDAK TERSEDIA', category: null };
  if (n <= 0.333) return { status: 'RENDAH', category: 'rendah' };
  if (n <= 0.666) return { status: 'SEDANG', category: 'sedang' };
  return { status: 'TINGGI', category: 'tinggi' };
}
function combineMountainRisk(indexValue, rain24h) {
  const base = classifyBaseline(indexValue), rain = number(rain24h);
  const rainClass = rain === null ? 'DATA TIDAK TERSEDIA' : rain > 150 ? 'EKSTREM' : rain >= 100 ? 'SANGAT LEBAT' : rain >= 50 ? 'LEBAT' : rain >= 20 ? 'SEDANG' : rain >= 0.5 ? 'RINGAN' : 'RENDAH';
  let status = 'DATA TIDAK TERSEDIA';
  if (base.category === 'tinggi') status = rain !== null && rain >= 50 ? 'SIAGA' : rain !== null && rain >= 20 ? 'BERPOTENSI' : 'KERAWANAN DASAR TINGGI';
  else if (base.category === 'sedang') status = rain !== null && rain >= 100 ? 'SIAGA' : rain !== null && rain >= 20 ? 'BERPOTENSI' : 'KERAWANAN DASAR SEDANG';
  else if (base.category === 'rendah') status = rain !== null && rain >= 100 ? 'WASPADA HUJAN SANGAT LEBAT' : rain !== null && rain >= 50 ? 'WASPADA HUJAN LEBAT' : rain === null ? 'NORMAL · HUJAN TIDAK TERSEDIA' : 'NORMAL';
  else if (rain !== null && rain >= 100) status = 'WASPADA HUJAN SANGAT LEBAT · DATA INARISK TIDAK TERSEDIA';
  else if (rain !== null && rain >= 50) status = 'WASPADA HUJAN LEBAT · DATA INARISK TIDAK TERSEDIA';
  return {
    status,
    baseline: base.status,
    baselineIndex: number(indexValue),
    rainfall24hMm: rain,
    rainfallClass: rainClass,
    sourceNote: 'Indeks InaRISK adalah kerawanan dasar. Curah hujan 24 jam adalah prakiraan model. Status gabungan adalah skrining kewaspadaan, bukan probabilitas kejadian atau peringatan resmi. Kelas kerawanan tinggi tanpa hujan pemicu ditampilkan sebagai kerawanan dasar, bukan SIAGA kejadian.'
  };
}
const MOUNTAIN_HAZARD_LAYERS = {
  flood: { name: 'INDEKS_BAHAYA_BANJIR', label: 'InaRISK · bahaya banjir' },
  landslide: { name: 'INDEKS_BAHAYA_TANAHLONGSOR', label: 'InaRISK · bahaya tanah longsor' }
};
function parseHazardPixel(payload) {
  if (!payload || payload.error) return null;
  const raw = Object.prototype.hasOwnProperty.call(payload, 'value') ? payload.value : payload.processedValues;
  const values = Array.isArray(raw) ? raw : [raw];
  for (const item of values) {
    const value = number(typeof item === 'string' ? item.trim().split(/[;,\s]/)[0] : item);
    if (value !== null && value >= 0 && value <= 1) return value;
  }
  return null;
}
async function identifyMountainHazard(layer, lat, lon) {
  const a = 6378137, e = 0.08181919084262149;
  const phi = Math.max(-85, Math.min(85, lat)) * Math.PI / 180, lambda = lon * Math.PI / 180, sinPhi = Math.sin(phi);
  const x = a * lambda, y = a * Math.log(Math.tan(Math.PI / 4 + phi / 2) * Math.pow((1 - e * sinPhi) / (1 + e * sinPhi), e / 2));
  const params = new URLSearchParams({
    f: 'json', geometry: JSON.stringify({ x, y, spatialReference: { wkid: 3395 } }), geometryType: 'esriGeometryPoint', sr: '3395',
    returnGeometry: 'false', returnPixelValues: 'false', returnCatalogItems: 'false', pixelSize: JSON.stringify({ x: 100, y: 100 })
  });
  const payload = await fetchJson(`https://gis.bnpb.go.id/server/rest/services/inarisk/${layer.name}/ImageServer/identify?${params}`, 7000);
  const value = parseHazardPixel(payload);
  if (value === null) throw new Error('Piksel raster tepat pada koordinat titik tidak tersedia.');
  return value;
}
async function getLocalTerrainMetrics(points) {
  const key = `local-terrain:${points.map(p => `${p.lat.toFixed(5)},${p.lon.toFixed(5)}`).join('|')}`;
  const cached = cacheGet(key, TERRAIN_TTL);
  if (cached) return cached;
  const grids = points.map(point => {
    const dLat = 120 / 110540;
    const dLon = 120 / Math.max(20000, 111320 * Math.cos(point.lat * Math.PI / 180));
    return [
      { lat: point.lat - dLat, lon: point.lon - dLon },
      { lat: point.lat - dLat, lon: point.lon },
      { lat: point.lat - dLat, lon: point.lon + dLon },
      { lat: point.lat, lon: point.lon - dLon },
      { lat: point.lat, lon: point.lon },
      { lat: point.lat, lon: point.lon + dLon },
      { lat: point.lat + dLat, lon: point.lon - dLon },
      { lat: point.lat + dLat, lon: point.lon },
      { lat: point.lat + dLat, lon: point.lon + dLon }
    ];
  });
  const all = grids.flat();
  let elevations = null, source = null, errors = [];
  for (const dataset of ['aster30m', 'srtm90m']) {
    try {
      const locations = all.map(p => `${p.lat},${p.lon}`).join('|');
      const payload = await fetchJson(`https://api.opentopodata.org/v1/${dataset}?locations=${encodeURIComponent(locations)}`, 8000);
      const values = Array.isArray(payload.results) ? payload.results.map(row => number(row?.elevation)) : [];
      if (values.length !== all.length || values.some(value => value === null)) throw new Error('Grid DEM tidak lengkap');
      elevations = values;
      source = `OpenTopoData ${dataset.toUpperCase()} · grid lokal 3×3`;
      break;
    } catch (error) { errors.push(error.message || 'DEM tidak merespons'); }
  }
  const result = grids.map((grid, i) => {
    if (!elevations) return { available: false, slopeDegrees: number(points[i].slopeDegrees), topographicPositionM: null, localReliefM: null, source: 'DEM lokal tidak tersedia' };
    const z = elevations.slice(i * 9, i * 9 + 9);
    const dzEast = (z[5] - z[3]) / 240;
    const dzNorth = (z[1] - z[7]) / 240;
    const slopeDegrees = Math.atan(Math.hypot(dzEast, dzNorth)) * 180 / Math.PI;
    const neighborMean = z.reduce((sum, value, index) => index === 4 ? sum : sum + value, 0) / 8;
    return {
      available: true,
      elevationM: z[4],
      slopeDegrees: Number.isFinite(slopeDegrees) ? slopeDegrees : null,
      topographicPositionM: z[4] - neighborMean,
      localReliefM: Math.max(...z) - Math.min(...z),
      source
    };
  });
  const value = { points: result, source: source || errors.join('; ') || 'DEM tidak tersedia' };
  cacheSet(key, value);
  return value;
}

function estimateMountainRisk(kind, baselineIndex, metrics) {
  const baseline = classifyBaseline(baselineIndex);
  const rain24 = number(metrics.rain24hMm);
  const rain6 = number(metrics.rain6hMm);
  const rain72 = number(metrics.rain72hMm);
  const slope = number(metrics.slopeDegrees);
  const tpi = number(metrics.topographicPositionM);
  const relief = number(metrics.localReliefM);
  const nearWater = number(metrics.nearestWaterMeters);
  const soil = number(metrics.soilMoisture);
  const rainClass = rain24 === null ? 'BELUM ADA AKUMULASI 24 JAM'
    : rain24 >= 150 ? 'EKSTREM'
    : rain24 >= 100 ? 'SANGAT LEBAT'
    : rain24 >= 50 ? 'LEBAT'
    : rain24 >= 20 ? 'SEDANG'
    : rain24 >= 0.5 ? 'RINGAN' : 'RENDAH';

  const terrainFactors = [];
  const triggerFactors = [];
  const add = (list, label, value, weight) => {
    if (value !== null && Number.isFinite(value)) list.push({ label, value: Math.max(0, Math.min(100, value)), weight });
  };
  const weighted = list => {
    const totalWeight = list.reduce((sum, item) => sum + item.weight, 0);
    return totalWeight ? list.reduce((sum, item) => sum + item.value * item.weight, 0) / totalWeight : null;
  };
  const rainfallScore = (value, thresholds) => value === null ? null
    : value >= thresholds[3] ? 100
    : value >= thresholds[2] ? 82
    : value >= thresholds[1] ? 58
    : value >= thresholds[0] ? 30 : 5;
  const soilScore = value => value === null ? null : value >= 0.5 ? 100 : value >= 0.45 ? 85 : value >= 0.4 ? 68 : value >= 0.35 ? 45 : value >= 0.28 ? 22 : 5;

  if (kind === 'flood') {
    add(terrainFactors, 'InaRISK', number(baselineIndex) === null ? null : number(baselineIndex) * 100, 0.30);
    add(terrainFactors, 'Posisi lembah/topografi', tpi === null ? null : tpi <= -15 ? 100 : tpi <= -8 ? 86 : tpi <= -3 ? 68 : tpi <= 3 ? 42 : 10, 0.29);
    add(terrainFactors, 'Kedekatan alur air', nearWater === null ? null : nearWater <= 100 ? 100 : nearWater <= 250 ? 86 : nearWater <= 500 ? 68 : nearWater <= 1000 ? 40 : nearWater <= 2000 ? 18 : 0, 0.27);
    add(terrainFactors, 'Kemiringan medan datar', slope === null ? null : slope <= 2 ? 100 : slope <= 5 ? 82 : slope <= 10 ? 54 : slope <= 15 ? 25 : 5, 0.14);
    add(triggerFactors, 'Hujan 24 jam', rainfallScore(rain24, [20, 50, 100, 150]), 0.45);
    add(triggerFactors, 'Hujan 6 jam', rainfallScore(rain6, [10, 20, 35, 50]), 0.20);
    add(triggerFactors, 'Hujan 72 jam', rainfallScore(rain72, [50, 100, 150, 180]), 0.25);
    add(triggerFactors, 'Kelembapan tanah', soilScore(soil), 0.10);
  } else {
    add(terrainFactors, 'InaRISK', number(baselineIndex) === null ? null : number(baselineIndex) * 100, 0.30);
    add(terrainFactors, 'Kemiringan lereng', slope === null ? null : slope >= 40 ? 100 : slope >= 35 ? 90 : slope >= 30 ? 82 : slope >= 25 ? 68 : slope >= 20 ? 52 : slope >= 15 ? 32 : slope >= 10 ? 16 : 5, 0.43);
    add(terrainFactors, 'Relief lokal', relief === null ? null : relief >= 120 ? 100 : relief >= 80 ? 82 : relief >= 50 ? 64 : relief >= 25 ? 40 : relief >= 10 ? 20 : 5, 0.19);
    add(terrainFactors, 'Posisi medan', tpi === null ? null : tpi <= -10 ? 65 : tpi <= -5 ? 52 : tpi >= 15 ? 28 : 35, 0.08);
    add(triggerFactors, 'Hujan 24 jam', rainfallScore(rain24, [20, 56, 100, 150]), 0.40);
    add(triggerFactors, 'Hujan 6 jam', rainfallScore(rain6, [10, 30, 50, 70]), 0.18);
    add(triggerFactors, 'Hujan 72 jam', rainfallScore(rain72, [50, 128, 180, 240]), 0.30);
    add(triggerFactors, 'Kelembapan tanah', soilScore(soil), 0.12);
  }

  const susceptibilityScore = weighted(terrainFactors);
  const triggerScore = weighted(triggerFactors);
  const score = susceptibilityScore === null ? triggerScore
    : triggerScore === null ? susceptibilityScore
    : susceptibilityScore * 0.68 + triggerScore * 0.32;
  const moderateRain = kind === 'landslide'
    ? (rain24 !== null && rain24 >= 56) || (rain72 !== null && rain72 >= 128) || (rain6 !== null && rain6 >= 30)
    : (rain24 !== null && rain24 >= 20) || (rain72 !== null && rain72 >= 50) || (rain6 !== null && rain6 >= 10);
  const severeRain = kind === 'landslide'
    ? ((rain24 !== null && rain24 >= 100) && (rain72 !== null && rain72 >= 180)) || ((rain6 !== null && rain6 >= 70) && (rain24 !== null && rain24 >= 56))
    : (rain24 !== null && rain24 >= 150) || (rain6 !== null && rain6 >= 70) || (rain72 !== null && rain72 >= 220);
  const enoughTerrain = terrainFactors.length > 0;
  const enoughInputs = terrainFactors.length + triggerFactors.length;

  let susceptibility = 'BELUM TERKELAS';
  if (susceptibilityScore !== null) susceptibility = susceptibilityScore >= 70 ? 'TINGGI' : susceptibilityScore >= 45 ? 'SEDANG' : 'RENDAH';
  let triggerStatus = triggerScore === null ? 'PEMICU CUACA BELUM TERUKUR'
    : severeRain ? 'PEMICU HUJAN SANGAT TINGGI'
    : moderateRain ? 'PEMICU HUJAN TERDETEKSI'
    : 'PEMICU HUJAN RENDAH';

  let status = 'SKRINING TERBATAS';
  if (susceptibilityScore !== null) {
    if (susceptibilityScore >= 82 && severeRain && triggerScore >= 78) status = 'BAHAYA';
    else if (susceptibilityScore >= 55 && severeRain) status = 'SIAGA';
    else if (susceptibilityScore >= 55 && moderateRain) status = 'SIAGA';
    else if (susceptibilityScore >= 42 && moderateRain) status = 'BERPOTENSI';
    else if (susceptibilityScore >= 70) status = 'KERENTANAN DASAR TINGGI';
    else if (susceptibilityScore >= 45) status = 'KERENTANAN DASAR SEDANG';
    else if (severeRain) status = 'WASPADA HUJAN SANGAT LEBAT';
    else if (moderateRain) status = 'WASPADA PEMICU HUJAN';
    else status = 'NORMAL';
  } else if (triggerScore !== null) {
    status = severeRain ? 'WASPADA HUJAN SANGAT LEBAT · MEDAN BELUM TERUKUR'
      : moderateRain ? 'WASPADA PEMICU HUJAN · MEDAN BELUM TERUKUR'
      : 'SKRINING TERBATAS · TOPOGRAFI BELUM TERUKUR';
  }

  const reasons = [];
  if (baseline.category) reasons.push(`Indeks dasar InaRISK ${baseline.status.toLowerCase()}`);
  if (kind === 'landslide' && slope !== null) reasons.push(`Kemiringan lokal ${slope.toFixed(1)}°`);
  if (kind === 'landslide' && relief !== null) reasons.push(`Relief medan sekitar ${Math.round(relief)} m`);
  if (kind === 'flood' && tpi !== null && tpi <= -5) reasons.push('Titik berada pada posisi topografi relatif rendah/lembah');
  if (kind === 'flood' && nearWater !== null && nearWater <= 500) reasons.push(`Dekat alur air terpetakan (±${Math.round(nearWater)} m)`);
  if (moderateRain) reasons.push(kind === 'landslide' ? 'Ambang hujan pemicu longsor terlampaui (56 mm/24 jam, 128 mm/72 jam, atau 30 mm/6 jam)' : 'Akumulasi hujan meningkatkan potensi limpasan dan genangan');
  if (soil !== null && soil >= 0.35) reasons.push(`Kelembapan tanah permukaan relatif tinggi (${soil.toFixed(2)})`);
  if (!reasons.length) reasons.push('Indikator topografi dan pemicu cuaca yang tersedia berada pada kelas rendah');

  return {
    status, susceptibility, susceptibilityScore: susceptibilityScore === null ? null : Math.round(susceptibilityScore),
    triggerStatus, triggerScore: triggerScore === null ? null : Math.round(triggerScore),
    riskScore: score === null ? null : Math.round(score),
    baseline: baseline.status, baselineIndex: number(baselineIndex),
    rainfall24hMm: rain24, rainfall6hMm: rain6, rainfall72hMm: rain72,
    rainfallClass: rainClass, slopeDegrees: slope, topographicPositionM: tpi,
    localReliefM: relief, nearestWaterMeters: nearWater, soilMoisture: soil,
    reasons, confidence: enoughInputs >= 6 ? 'baik · beberapa indikator terukur' : enoughInputs >= 3 ? 'sedang · data parsial' : 'terbatas · perlu verifikasi',
    sourceNote: 'Skor adalah skrining relatif berbasis raster InaRISK, DEM, hidrologi terpetakan, dan prakiraan hujan. Kelas kerentanan medan dipisahkan dari pemicu cuaca; bukan probabilitas kejadian atau peringatan resmi.'
  };
}

async function mountainHazards(points) {
  const cacheKey = `mh:${points.map(p => `${p.lat.toFixed(5)},${p.lon.toFixed(5)}:${p.rain24hMm ?? ''}:${p.rain6hMm ?? ''}:${p.rain72hMm ?? ''}:${p.slopeDegrees ?? ''}:${p.nearestWaterMeters ?? ''}:${p.soilMoisture ?? ''}`).join('|')}`;
  const cached = cacheGet(cacheKey, HAZARD_TTL);
  if (cached) return cached;
  const [terrain, rasterResults, hydroResults] = await Promise.all([
    getLocalTerrainMetrics(points),
    (async () => {
      const results = new Array(points.length);
      let next = 0;
      await Promise.all(Array.from({ length: Math.min(2, points.length) }, async () => {
        while (next < points.length) {
          const index = next++, point = points[index];
          const pair = await Promise.all(Object.entries(MOUNTAIN_HAZARD_LAYERS).map(async ([key, layer]) => {
            try { return [key, { value: await identifyMountainHazard(layer, point.lat, point.lon), available: true, source: layer.label }]; }
            catch (error) { return [key, { value: null, available: false, source: layer.label, note: String(error.message || error) }]; }
          }));
          results[index] = Object.fromEntries(pair);
        }
      }));
      return results;
    })(),
    nearbyWaterSources(points).catch(() => ({ points: points.map(point => ({ id: point.id, nearestHydroMeters: null, available: false })) }))
  ]);
  const results = points.map((point, index) => {
    const terrainPoint = terrain.points[index] || {};
    const slope = number(terrainPoint.slopeDegrees) ?? number(point.slopeDegrees);
    const metrics = {
      rain24hMm: point.rain24hMm,
      rain6hMm: point.rain6hMm,
      rain72hMm: point.rain72hMm,
      slopeDegrees: slope,
      topographicPositionM: terrainPoint.topographicPositionM,
      localReliefM: terrainPoint.localReliefM,
      nearestWaterMeters: number(point.nearestWaterMeters) ?? number(hydroResults.points?.[index]?.nearestHydroMeters),
      soilMoisture: point.soilMoisture
    };
    const raster = rasterResults[index] || {};
    const floodValue = raster.flood?.value ?? null;
    const landslideValue = raster.landslide?.value ?? null;
    const floodScreening = estimateMountainRisk('flood', floodValue, metrics);
    const landslideScreening = estimateMountainRisk('landslide', landslideValue, metrics);
    return {
      id: point.id, label: point.label, lat: point.lat, lon: point.lon,
      terrain: { ...terrainPoint, slopeDegrees: slope },
      rain24hMm: number(point.rain24hMm),
      flood: { ...raster.flood, ...floodScreening, rasterAvailable: !!raster.flood?.available },
      landslide: { ...raster.landslide, ...landslideScreening, rasterAvailable: !!raster.landslide?.available }
    };
  });
  const value = {
    ok: true,
    points: results,
    source: 'InaRISK BNPB + Open-Meteo + OpenTopoData DEM + OpenStreetMap hydrography',
    checkedAt: new Date().toISOString(),
    note: 'Setiap waypoint dianalisis pada koordinatnya sendiri. Skor kerentanan medan dipisahkan dari pemicu hujan; alur air OSM dipakai sebagai indikator pendukung dan bukan inventaris hidrologi lengkap. Hasil adalah skrining relatif, bukan probabilitas kejadian atau peringatan resmi.'
  };
  cacheSet(cacheKey, value);
  return value;
}

async function nearbyWaterSources(points) {
  const key = `water:${points.map(p => `${p.lat.toFixed(4)},${p.lon.toFixed(4)}`).join('|')}`;
  const cached = cacheGet(key, WATER_TTL);
  if (cached) return cached;

  // One Overpass request for the whole itinerary; broaden tags/radius without per-point fan-out.
  const unique = [...new Map(points.map(p => [`${p.lat.toFixed(4)},${p.lon.toFixed(4)}`, p])).values()];
  const selectors = [];
  for (const point of unique) {
    const lat = point.lat.toFixed(5), lon = point.lon.toFixed(5);
    selectors.push(`nwr(around:1800,${lat},${lon})["amenity"="drinking_water"];`);
    selectors.push(`nwr(around:1800,${lat},${lon})["man_made"~"^(water_well|water_tap)$"];`);
    selectors.push(`nwr(around:1800,${lat},${lon})["natural"~"^(spring|water)$"];`);
    selectors.push(`nwr(around:1800,${lat},${lon})["waterway"~"^(stream|river)$"];`);
    selectors.push(`nwr(around:1800,${lat},${lon})["landuse"="reservoir"];`);
    selectors.push(`nwr(around:1800,${lat},${lon})["water"~"^(pond|lake|reservoir)$"];`);
  }
  const query = `[out:json][timeout:14];(${selectors.join('')});out center tags;`;
  let data = null, queryError = null;
  try { data = await fetchOverpass(query, 18000); }
  catch (error) { queryError = String(error.message || error); }

  const sources = new Map();
  for (const item of (data?.elements || [])) {
    const tags = item.tags || {};
    const lat = number(item.lat ?? item.center?.lat), lon = number(item.lon ?? item.center?.lon);
    if (!insideIndonesia(lat, lon)) continue;
    const amenity = String(tags.amenity || '').toLowerCase();
    const natural = String(tags.natural || '').toLowerCase();
    const manMade = String(tags.man_made || '').toLowerCase();
    const waterway = String(tags.waterway || '').toLowerCase();
    const landuse = String(tags.landuse || '').toLowerCase();
    const water = String(tags.water || '').toLowerCase();
    let kind = '', hydroFeature = false, drinkingFacility = false;
    if (amenity === 'drinking_water') { kind = 'Fasilitas air minum bertanda OSM'; drinkingFacility = true; }
    else if (manMade === 'water_tap') { kind = 'Keran air terpetakan'; drinkingFacility = true; }
    else if (manMade === 'water_well') { kind = 'Sumur terpetakan'; hydroFeature = true; }
    else if (natural === 'spring') { kind = 'Mata air terpetakan'; hydroFeature = true; }
    else if (waterway === 'river' || waterway === 'stream') { kind = waterway === 'river' ? 'Sungai terpetakan' : 'Aliran air terpetakan'; hydroFeature = true; }
    else if (natural === 'water' || landuse === 'reservoir' || ['pond','lake','reservoir'].includes(water)) {
      kind = 'Badan air terpetakan'; hydroFeature = true;
    }
    if (!kind) continue;
    const id = `${item.type || 'node'}-${item.id}`;
    sources.set(id, {
      id, name: clean(tags.name || tags['name:id'] || kind), kind, lat, lon,
      hydroFeature, drinkingFacility,
      drinkingWaterTag: String(tags.drinking_water || '').toLowerCase(),
      access: tags.access || null, intermittent: tags.intermittent || null,
      source: 'OpenStreetMap · Overpass',
      osmUrl: item.type && item.id ? `https://www.openstreetmap.org/${item.type}/${item.id}` : null
    });
  }

  const all = [...sources.values()];
  const results = points.map(point => {
    const nearby = all
      .map(source => ({ ...source, distanceMeters: haversineMeters(point, source) }))
      .filter(source => source.distanceMeters <= 2000)
      .sort((a, b) => a.distanceMeters - b.distanceMeters)
      .slice(0, 6);
    const nearestHydro = nearby.find(source => source.hydroFeature);
    return {
      id: point.id, label: point.label, nearby, source: 'OpenStreetMap · Overpass',
      nearestHydroMeters: nearestHydro ? Math.round(nearestHydro.distanceMeters) : null,
      mappedSourceCount: nearby.length,
      available: !queryError,
      note: queryError ? 'Server data peta tidak merespons; sumber air tidak dapat dipastikan.' : nearby.length
        ? 'Objek air ditemukan pada peta. Keberadaan, aliran, akses, dan kualitas air harus diperiksa di lapangan.'
        : 'Tidak ditemukan objek air bertag dalam radius 2 km. Ini berarti peta belum mencatat sumber air, bukan bukti bahwa sumber air tidak ada.'
    };
  });
  const value = {
    ok: true, points: results, queryAvailable: !queryError,
    source: 'OpenStreetMap · Overpass',
    fetchedAt: new Date().toISOString(),
    warning: queryError,
    note: 'Pencarian dilakukan serentak untuk semua waypoint dalam radius 1,8 km dan hasil dihitung sampai 2 km. Fasilitas bertag drinking_water tetap perlu verifikasi kondisi lapangan; sungai, danau, dan mata air bukan otomatis air layak minum.'
  };
  if (!queryError) cacheSet(key, value); // Only cache completed Overpass responses.
  return value;
}

exports._test = { insideIndonesia, timezoneForLongitude, timezoneForRegion, offsetForTimezone, elevationValue, mountainFromNominatim, mountainFromOverpass, routeFromRelation, routeFromWay, normalizeGeometry, simplifyGeometry, hourlyAt, norm, addLocalMinutes, computeItinerary, classifyBaseline, combineMountainRisk, estimateMountainRisk, parseHazardPixel, haversineMeters };
exports.handler = async event => {
  const q = event.queryStringParameters || {};
  const action = String(q.action || '').toLowerCase();
  try {
    if (action === 'search') {
      const query = clean(q.q);
      if (query.length < 2) return json(400, { ok: false, error: 'Masukkan minimal dua karakter nama gunung.', results: [] });
      return json(200, await searchMountains(query), 'public, max-age=900, stale-while-revalidate=1800');
    }
    if (action === 'routes') {
      const lat = number(q.lat), lon = number(q.lon), radius = Math.max(2000, Math.min(15000, Math.round(number(q.radius) || 12000))), mountainName = clean(q.name || '');
      if (!insideIndonesia(lat, lon)) return json(400, { ok: false, error: 'Koordinat gunung tidak valid untuk wilayah Indonesia.', routes: [] });
      return json(200, await findRoutes(lat, lon, radius, mountainName), 'public, max-age=900, stale-while-revalidate=1800');
    }
    if (action === 'water') {
      const points = JSON.parse(String(q.points || '[]'));
      if (!Array.isArray(points) || points.length < 1 || points.length > 8 || points.some(p => !insideIndonesia(number(p.lat), number(p.lon)))) return json(400, { ok: false, error: 'Pilih 1–8 titik rute yang valid di Indonesia.' });
      const normalized = points.map((p, i) => ({ id: String(p.id || `point-${i + 1}`).slice(0, 30), label: clean(p.label || `Titik ${i + 1}`), lat: Number(p.lat), lon: Number(p.lon) }));
      return json(200, await nearbyWaterSources(normalized), 'public, max-age=1800, stale-while-revalidate=3600');
    }
    if (action === 'hazards') {
      const points = JSON.parse(String(q.points || '[]'));
      if (!Array.isArray(points) || points.length < 1 || points.length > 8 || points.some(p => !insideIndonesia(number(p.lat), number(p.lon)))) return json(400, { ok: false, error: 'Pilih 1–8 titik rute yang valid di Indonesia.' });
      const normalized = points.map((p, i) => ({
        id: String(p.id || `point-${i + 1}`).slice(0, 30),
        label: clean(p.label || `Titik ${i + 1}`),
        lat: Number(p.lat), lon: Number(p.lon),
        rain24hMm: number(p.rain24hMm), rain6hMm: number(p.rain6hMm), rain72hMm: number(p.rain72hMm),
        slopeDegrees: number(p.slopeDegrees), nearestWaterMeters: number(p.nearestWaterMeters),
        soilMoisture: number(p.soilMoisture), elevation: number(p.elevation)
      }));
      return json(200, await mountainHazards(normalized), 'public, max-age=900, stale-while-revalidate=1800');
    }
    if (action === 'weather') {
      const points = JSON.parse(String(q.points || '[]'));
      const date = String(q.date || ''), time = String(q.time || '');
      const paceKmh = 2.0; // Kecepatan rata-rata internal untuk perencanaan; tidak ditampilkan sebagai kontrol pengguna.
      if (!Array.isArray(points) || points.length < 1 || points.length > 8 || points.some(p => !insideIndonesia(number(p.lat), number(p.lon)))) return json(400, { ok: false, error: 'Pilih 1–8 titik rute yang valid di Indonesia.' });
      if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || !/^(?:[01]\d|2[0-3]):00$/.test(time)) return json(400, { ok: false, error: 'Tanggal atau jam prakiraan tidak valid.' });
      const timezone = ['Asia/Jakarta','Asia/Makassar','Asia/Jayapura'].includes(points[0]?.timezone) ? points[0].timezone : (timezoneForRegion(points[0]?.region) || timezoneForLongitude(number(points[0]?.lon)));
      const offset = offsetForTimezone(timezone);
      const today = new Intl.DateTimeFormat('en-CA', { timeZone: timezone, year: 'numeric', month: '2-digit', day: '2-digit' }).format(new Date());
      const target = new Date(`${date}T${time}:00${offset}`).getTime(), start = new Date(`${today}T00:00:00${offset}`).getTime();
      if (!Number.isFinite(target) || target < start || target >= start + 10 * 86400000) return json(400, { ok: false, error: 'Tanggal prakiraan harus berada dalam 10 hari ke depan.' });
      const normalized = points.map((p, i) => ({ id: String(p.id || `point-${i + 1}`).slice(0, 30), label: clean(p.label || `Titik ${i + 1}`), lat: Number(p.lat), lon: Number(p.lon), elevation: number(p.elevation), distanceAlongRouteKm: number(p.distanceAlongRouteKm), timezone }));
      return json(200, await mountainWeather(normalized, date, time, paceKmh), 'public, max-age=180, stale-while-revalidate=300');
    }
    return json(400, { ok: false, error: 'Aksi tidak dikenal.' }, 'no-store');
  } catch (error) {
    return json(502, { ok: false, error: 'Data gunung belum berhasil diakses.', detail: String(error.message || error).slice(0, 240) }, 'no-store');
  }
};
