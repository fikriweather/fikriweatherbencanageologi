'use strict';
const decode=s=>String(s||'').replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g,'$1').replace(/&amp;/g,'&').replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&quot;/g,'"').replace(/&#39;|&apos;/g,"'").replace(/&#(\d+);/g,(_,n)=>String.fromCharCode(Number(n)));
const tag=(xml,name)=>{const m=String(xml||'').match(new RegExp(`<${name}(?:\\s+[^>]*)?>([\\s\\S]*?)<\\/${name}>`,'i'));return m?decode(m[1]).trim():'';};
const norm=s=>String(s||'').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9]+/g,' ').trim();
async function fetchText(url,ms=6500){const r=await fetch(url,{headers:{'User-Agent':'FikriWeather/4.0 (BMKG CAP reader)','Accept':'application/xml,text/xml,application/rss+xml,*/*'},signal:AbortSignal.timeout(ms)});if(!r.ok)throw new Error(`HTTP ${r.status}`);return r.text();}
async function fetchJson(url,ms=4000){const r=await fetch(url,{headers:{'User-Agent':'FikriWeather/4.0 (location reverse geocoder)','Accept':'application/json'},signal:AbortSignal.timeout(ms)});if(!r.ok)throw new Error(`HTTP ${r.status}`);return r.json();}
function inside(lat,lon,poly){let c=false;for(let i=0,j=poly.length-1;i<poly.length;j=i++){const [yi,xi]=poly[i],[yj,xj]=poly[j];if(((yi>lat)!==(yj>lat))&&(lon<(xj-xi)*(lat-yi)/(yj-yi+1e-12)+xi))c=!c;}return c;}
function polygons(xml){const out=[];for(const m of String(xml||'').matchAll(/<polygon(?:\s+[^>]*)?>([\s\S]*?)<\/polygon>/gi)){const pts=decode(m[1]).trim().split(/[\s;]+/).map(p=>p.split(',').map(Number)).filter(p=>p.length===2&&p.every(Number.isFinite));if(pts.length>=3)out.push(pts);}return out;}
function active(effective,expires,sent){const now=Date.now(),a=Date.parse(effective||sent||'')||0,b=Date.parse(expires||'')||0;return (!a||a<=now+5*60000)&&(!b||b>=now);}
function rssItems(xml){return [...String(xml||'').matchAll(/<item\b[\s\S]*?<\/item>/gi)].map(m=>m[0]);}
function validRss(xml){return /<(?:rss|rdf:RDF|feed)\b/i.test(String(xml||''))&&/<(?:channel|item|entry)\b/i.test(String(xml||''));}
function emptyFeedResult(place,lat,lon){return {ok:true,warnings:[],feedItems:0,source:'BMKG CAP Nowcast',checkedAt:new Date().toISOString(),matchStatus:'no_active_warnings',location:{place,latitude:lat,longitude:lon},message:'Feed BMKG berhasil diperiksa; tidak ada peringatan aktif yang tercantum saat pemeriksaan.'};}
const PROVINCES=['Aceh','Sumatera Utara','Sumatera Barat','Riau','Kepulauan Riau','Jambi','Sumatera Selatan','Kepulauan Bangka Belitung','Bengkulu','Lampung','Banten','DKI Jakarta','Daerah Khusus Jakarta','Jawa Barat','Jawa Tengah','DI Yogyakarta','Daerah Istimewa Yogyakarta','Jawa Timur','Bali','Nusa Tenggara Barat','Nusa Tenggara Timur','Kalimantan Barat','Kalimantan Tengah','Kalimantan Selatan','Kalimantan Timur','Kalimantan Utara','Sulawesi Utara','Gorontalo','Sulawesi Tengah','Sulawesi Barat','Sulawesi Selatan','Sulawesi Tenggara','Maluku','Maluku Utara','Papua','Papua Barat','Papua Selatan','Papua Tengah','Papua Pegunungan','Papua Barat Daya'];
function provinceFromPlace(place){const p=norm(place);return PROVINCES.find(x=>p.includes(norm(x)))||'';}
const PROV_ALIAS={
 'daerah istimewa yogyakarta':['di yogyakarta','diy','yogyakarta'],'di yogyakarta':['daerah istimewa yogyakarta','diy','yogyakarta','special region of yogyakarta'],'yogyakarta':['di yogyakarta','daerah istimewa yogyakarta','diy','special region of yogyakarta'],'special region of yogyakarta':['di yogyakarta','daerah istimewa yogyakarta','diy','yogyakarta'],
 'dki jakarta':['daerah khusus jakarta','jakarta'],'daerah khusus jakarta':['dki jakarta','jakarta'],'daerah khusus ibukota jakarta':['dki jakarta','jakarta'],
 'nanggroe aceh darussalam':['aceh'],'aceh':['nanggroe aceh darussalam'],
 'kepulauan bangka belitung':['bangka belitung'],'bangka belitung':['kepulauan bangka belitung']
};
function sameName(areaDesc,candidates){const hay=' '+norm(areaDesc)+' ';for(const value of candidates){const n=norm(value);if(n.length>=4&&hay.includes(' '+n+' '))return value;}return '';}
exports._test={tag,norm,inside,polygons,active,rssItems,validRss,emptyFeedResult,sameName,provinceFromPlace};
exports.handler=async event=>{
 const lat=Number(event.queryStringParameters?.lat),lon=Number(event.queryStringParameters?.lon),place=String(event.queryStringParameters?.place||'').slice(0,300);
 if(!Number.isFinite(lat)||!Number.isFinite(lon)||Math.abs(lat)>90||Math.abs(lon)>180||lat < -11.5||lat > 6.8||lon < 94||lon > 142)return{statusCode:400,headers:{'Content-Type':'application/json'},body:JSON.stringify({ok:false,error:'Koordinat tidak valid atau berada di luar Indonesia.'})};
 const headers={'Content-Type':'application/json; charset=utf-8','Cache-Control':'public, max-age=120, stale-while-revalidate=60','Access-Control-Allow-Origin':'*','X-Content-Type-Options':'nosniff'};
 try{
  let rss='';try{rss=await fetchText('https://www.bmkg.go.id/alerts/nowcast/id');}catch{rss=await fetchText('https://www.bmkg.go.id/alerts/nowcast/id/rss.xml');}
  let items=rssItems(rss);
  if(!items.length){
    let alt='';try{alt=await fetchText('https://www.bmkg.go.id/alerts/nowcast/id/rss.xml');}catch{}
    if(alt){rss=alt;items=rssItems(rss);}
  }
  if(!items.length){
    if(validRss(rss)){return {statusCode:200,headers,body:JSON.stringify(emptyFeedResult(place,lat,lon))};}
    throw new Error('Feed BMKG tidak berisi daftar RSS/CAP yang valid.');
  }
  let address={};try{const a=await fetchJson(`https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${lat}&lon=${lon}&zoom=12&addressdetails=1&accept-language=id`,4500);address=a.address||{};}catch{}
  const provinceRaw=address.state||address.province||'';
  const province=norm(provinceRaw||provinceFromPlace(place));
  const aliases=PROV_ALIAS[province]||[];const provinceKeys=[province,...aliases.map(norm)].filter(Boolean);
  const localCandidates=[address.village,address.hamlet,address.suburb,address.neighbourhood,address.quarter,address.city_district,address.district,address.subdistrict,address.municipality,address.county,address.city];
  if(!localCandidates.some(x=>x&&String(x).trim())){
    const comps=place.split(',').map(x=>x.trim()).filter(Boolean);
    for(const c of comps){const cn=norm(c);if(cn.length>=4&&!provinceKeys.includes(cn)&&!['indonesia','kabupaten','kecamatan','provinsi','jawa tengah','jawa barat','jawa timur','sumatera utara','sumatera barat'].includes(cn))localCandidates.push(c);}
  }
  const locals=[...new Set(localCandidates.filter(Boolean).map(x=>String(x).trim()).filter(x=>norm(x).length>=4))];
  if(!provinceKeys.length){return{statusCode:200,headers,body:JSON.stringify({ok:true,warnings:[],source:'BMKG CAP Nowcast',checkedAt:new Date().toISOString(),location:{place,latitude:lat,longitude:lon,province:'Belum teridentifikasi',localities:locals},matchStatus:'province_unresolved',message:'Provinsi titik belum dapat diverifikasi. Peringatan tidak dicocokkan secara acak agar tidak salah lokasi.'})};}
  const provinceItems=items.filter(item=>{const text=norm(tag(item,'title')+' '+tag(item,'description'));return provinceKeys.some(k=>k.length>=4&&(' '+text+' ').includes(' '+k+' '));});
  if(!provinceItems.length){return{statusCode:200,headers,body:JSON.stringify({ok:true,warnings:[],source:'BMKG CAP Nowcast',checkedAt:new Date().toISOString(),location:{place,latitude:lat,longitude:lon,province:provinceRaw||provinceFromPlace(place),localities:locals},matchStatus:'no_province_feed',message:'Tidak ada item feed BMKG untuk provinsi titik pada saat pemeriksaan. Tidak menggunakan feed provinsi lain.'})};}
  const selected=provinceItems.slice(0,15);
  const docs=await Promise.all(selected.map(async item=>{const link=tag(item,'link');if(!/^https?:\/\//i.test(link))return{item,cap:''};try{return{item,cap:await fetchText(link,6500)};}catch{return{item,cap:''};}}));
  const warnings=[];
  for(const {item,cap} of docs){
    if(!cap)continue;
    const infos=[...cap.matchAll(/<info\b[\s\S]*?<\/info>/gi)].map(m=>m[0]);
    for(const info of infos){
      const eventName=tag(info,'event'),headline=tag(info,'headline')||tag(item,'title'),description=tag(info,'description')||tag(item,'description'),effective=tag(info,'effective'),expires=tag(info,'expires'),sent=tag(cap,'sent');
      if(!active(effective,expires,sent))continue;
      const areas=[...info.matchAll(/<area\b[\s\S]*?<\/area>/gi)].map(m=>m[0]);
      let polygonMatch=false,areaDescList=[],adminMatch='';
      for(const area of areas){const areaDesc=tag(area,'areaDesc');if(areaDesc)areaDescList.push(areaDesc);if(polygons(area).some(poly=>inside(lat,lon,poly)))polygonMatch=true;if(!adminMatch)adminMatch=sameName(areaDesc,locals);}
      // Never match a location just because its name appears in the headline or broad description.
      // Area-name fallback is restricted to exact administrative names inside CAP areaDesc.
      if(!polygonMatch&&!adminMatch)continue;
      warnings.push({event:eventName,headline,description,areaDesc:areaDescList.join(' · '),effective,expires,severity:tag(info,'severity'),urgency:tag(info,'urgency'),certainty:tag(info,'certainty'),web:tag(info,'web'),match:polygonMatch?'polygon':'area_name',matchedLocality:polygonMatch?'Koordinat berada di dalam poligon CAP BMKG':adminMatch});
    }
  }
  const uniq=[];const seen=new Set();for(const w of warnings){const k=[w.headline,w.effective,w.areaDesc].join('|');if(!seen.has(k)){seen.add(k);uniq.push(w);}}
  return{statusCode:200,headers,body:JSON.stringify({ok:true,checkedAt:new Date().toISOString(),warnings:uniq.slice(0,12),feedItems:provinceItems.length,source:'BMKG CAP Nowcast',location:{place,latitude:lat,longitude:lon,province:provinceRaw||provinceFromPlace(place),localities:locals},matchStatus:uniq.length?'matched':'no_exact_match',message:uniq.length?'Peringatan cocok melalui poligon atau nama wilayah administrasi CAP.':'Tidak ditemukan peringatan aktif yang cocok dengan poligon atau nama wilayah CAP untuk titik ini.'})};
 }catch(e){return{statusCode:502,headers,body:JSON.stringify({ok:false,error:'Feed peringatan dini BMKG belum dapat dibaca.',detail:e.message,warnings:[]})};}
};
