'use strict';

// Tanya Fikri Weather: deterministic, weather-only assistant.
// No OpenAI, hosted LLM, paid AI service, or external text-generation endpoint is used.
const WINDOW_MS = 60_000;
const MAX_PER_WINDOW = 30;
const recentRequests = new Map();
const response = (statusCode, payload) => ({
  statusCode,
  headers: {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff',
    'Referrer-Policy': 'same-origin',
  },
  body: JSON.stringify(payload),
});
function textOnly(value, max = 2000) {
  return String(value ?? '').replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '').trim().slice(0, max);
}
function normalize(value) {
  let q = textOnly(value, 2500).toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  q = q.replace(/\b(ngga|nggak|enggak|engga|gak|ga|gk|ndak)\b/g, 'tidak')
    .replace(/\b(gimana|gmn)\b/g, 'bagaimana')
    .replace(/\b(ujan|hujn|hujann)\b/g, 'hujan')
    .replace(/\b(joging|joggin)\b/g, 'jogging')
    .replace(/\b(sepedahan|gowes)\b/g, 'bersepeda')
    .replace(/\b(jemur|menjemur)\b/g, 'jemuran')
    .replace(/\b(payungin)\b/g, 'payung');
  return q.replace(/[^a-z0-9%°.,:+\-\s]/g, ' ').replace(/\s+/g, ' ').trim();
}
const finite = v => v !== null && v !== undefined && v !== '' && Number.isFinite(Number(v));
const n = (v, digits = 0) => finite(v) ? Number(v).toFixed(digits) : null;
const pct = v => finite(v) ? `${Math.round(Number(v))}%` : 'belum tersedia';
const celsius = v => finite(v) ? `${Math.round(Number(v))}°C` : 'belum tersedia';
const kmh = v => finite(v) ? `${Math.round(Number(v))} km/jam` : 'belum tersedia';
function localParts(value) {
  const date = new Date(value);
  if (!Number.isFinite(date.getTime())) return null;
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Jakarta', year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit', hourCycle: 'h23',
  }).formatToParts(date);
  const out = Object.fromEntries(parts.map(p => [p.type, p.value]));
  return { date: `${out.year}-${out.month}-${out.day}`, hour: Number(out.hour), minute: Number(out.minute), dateObj: date };
}
function todayJakarta() { return localParts(Date.now())?.date || new Date().toISOString().slice(0, 10); }
function addDays(dateKey, days) {
  const d = new Date(`${dateKey}T12:00:00+07:00`);
  d.setUTCDate(d.getUTCDate() + days);
  return new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Jakarta', year: 'numeric', month: '2-digit', day: '2-digit' }).format(d);
}
function dateLabel(key) {
  const d = new Date(`${key}T12:00:00+07:00`);
  return new Intl.DateTimeFormat('id-ID', { timeZone: 'Asia/Jakarta', weekday: 'long', day: 'numeric', month: 'long' }).format(d);
}

function weatherConditionFromCode(value) {
  if (!finite(value)) return '';
  const code = Number(value);
  if (code === 0) return 'Cerah';
  if (code === 1) return 'Cerah berawan';
  if (code === 2) return 'Cerah berawan';
  if (code === 3) return 'Berawan';
  if ([45, 48].includes(code)) return 'Berkabut';
  if ([51, 53, 55, 56, 57].includes(code)) return 'Gerimis';
  if ([61, 80].includes(code)) return 'Hujan ringan';
  if ([63, 81, 66].includes(code)) return 'Hujan sedang';
  if ([65, 82, 67].includes(code)) return 'Hujan lebat';
  if ([71, 73, 75, 77, 85, 86].includes(code)) return 'Salju';
  if ([95, 96, 99].includes(code)) return 'Badai petir';
  return '';
}

function cleanCondition(label, code) {
  const raw = textOnly(label, 100);
  if (raw && !['-', '—', 'n/a', 'na', 'unknown', 'tidak diketahui', 'belum tersedia'].includes(raw.toLowerCase())) return raw;
  return weatherConditionFromCode(code);
}

function cleanContext(input = {}) {
  const c = input && typeof input === 'object' ? input : {};
  const cleanRow = r => ({
    time: textOnly(r?.time, 40), condition: cleanCondition(r?.condition, r?.code),
    temp: finite(r?.temp) ? Number(r.temp) : null,
    feels: finite(r?.feels) ? Number(r.feels) : null,
    humidity: finite(r?.humidity) ? Number(r.humidity) : null,
    rain: finite(r?.rain) ? Number(r.rain) : null,
    precip: finite(r?.precip) ? Number(r.precip) : null,
    wind: finite(r?.wind) ? Number(r.wind) : null,
    visibility: finite(r?.visibility) ? Number(r.visibility) : null,
    uv: finite(r?.uv) ? Number(r.uv) : null,
    cloud: finite(r?.cloud) ? Number(r.cloud) : null,
    pressure: finite(r?.pressure) ? Number(r.pressure) : null,
    windDirDeg: finite(r?.windDirDeg) ? Number(r.windDirDeg) : null,
    gust: finite(r?.gust) ? Number(r.gust) : null,
    code: finite(r?.code) ? Number(r.code) : null,
  });
  const hourly = Array.isArray(c.hourly) ? c.hourly.slice(0, 96).map(cleanRow) : [];
  const daily = Array.isArray(c.daily) ? c.daily.slice(0, 16).map(d => ({
    day: textOnly(d?.day, 10), condition: textOnly(d?.condition, 100),
    lo: finite(d?.lo) ? Number(d.lo) : null, hi: finite(d?.hi) ? Number(d.hi) : null,
    p: finite(d?.p) ? Number(d.p) : null, rain: finite(d?.rain) ? Number(d.rain) : null,
    wind: finite(d?.wind) ? Number(d.wind) : null, hum: finite(d?.hum) ? Number(d.hum) : null,
    uv: finite(d?.uv) ? Number(d.uv) : null,
  })) : [];
  const current = c.current && typeof c.current === 'object' ? {
    condition: cleanCondition(c.current.condition, c.current.code),
    temp: finite(c.current.temp) ? Number(c.current.temp) : null,
    feels: finite(c.current.feels) ? Number(c.current.feels) : null,
    humidity: finite(c.current.humidity) ? Number(c.current.humidity) : null,
    rain: finite(c.current.rain) ? Number(c.current.rain) : null,
    wind: finite(c.current.wind) ? Number(c.current.wind) : null,
    windDir: textOnly(c.current.windDir, 40),
    visibility: finite(c.current.visibility) ? Number(c.current.visibility) : null,
    pressure: finite(c.current.pressure) ? Number(c.current.pressure) : null,
    uv: finite(c.current.uv) ? Number(c.current.uv) : null,
    cloud: finite(c.current.cloud) ? Number(c.current.cloud) : null,
    windDirDeg: finite(c.current.windDirDeg) ? Number(c.current.windDirDeg) : null,
    gust: finite(c.current.gust) ? Number(c.current.gust) : null,
    code: finite(c.current.code) ? Number(c.current.code) : null,
  } : {};
  const airInput = c.air && typeof c.air === 'object' ? {
    usAqi: finite(c.air.usAqi) ? Number(c.air.usAqi) : null,
    europeanAqi: finite(c.air.europeanAqi) ? Number(c.air.europeanAqi) : null,
    pm25: finite(c.air.pm25) ? Number(c.air.pm25) : null,
    pm10: finite(c.air.pm10) ? Number(c.air.pm10) : null,
    ozone: finite(c.air.ozone) ? Number(c.air.ozone) : null,
    time: textOnly(c.air.time, 40), source: textOnly(c.air.source, 120),
    resolutionKm: finite(c.air.resolutionKm) ? Number(c.air.resolutionKm) : null,
  } : null;
  return {
    location: textOnly(c.location, 180) || 'lokasi aktif',
    timezone: 'Asia/Jakarta',
    fetchedAt: textOnly(c.fetchedAt, 40),
    source: textOnly(c.source, 160),
    current, hourly, daily, air: airInput,
    alerts: Array.isArray(c.alerts) ? c.alerts.slice(0, 5).map(x => textOnly(x, 220)) : [],
  };
}
function resolveFollowUp(question, history = []) {
  const q = textOnly(question, 2500);
  const nq = normalize(q);
  const vague = /^(?:(?:kalau |kalo |terus |bagaimana |gimana )?(pagi|siang|sore|malam|subuh|besok|lusa|hari ini|nanti|sekarang|jam \d{1,2})|(?:bagaimana|gimana) (?:kalau|kalo) (pagi|siang|sore|malam|subuh))\??$/;
  if (!vague.test(nq)) return q;
  const prev = [...(Array.isArray(history) ? history : [])].reverse().find(x => x?.role === 'user' && textOnly(x.content, 1000));
  return prev ? `${textOnly(prev.content, 1000)} ${q}` : q;
}
function classify(q) {
  const rules = [
    ['menu', /\b(menu|fitur|bisa apa|apa saja|cara menggunakan|cara pakai|panduan website)\b/],
    ['mountain', /\b(gunung|pendakian|pendaki|puncak|jalur hiking|status merapi|status gunung api|aktivitas vulkanik)\b/],
    ['alerts', /\b(peringatan dini|peringatan cuaca|warning|alert bmkg|peringatan bmkg|cuaca ekstrem|cuaca ekstrim)\b/],
    ['dewpoint', /\b(titik embun|dew point|dewpoint)\b/],
    ['pressure', /\b(tekanan udara|tekanan atmosfer|tekanan barometrik|tekanan permukaan laut|barometer|hpa|milibar|mslp|slp)\b/],
    ['explain', /\b(enso|el nino|el-niño|la nina|la niña|mjo|madden julian|rossby|monsun|muson|siklon|antisiklon|konvergensi|konveksi|orografis|foehn|angin fohn|inversi suhu|lapse rate|dalr|malr|konvergensi|konveksi|hujan orografis|front atmosfer|angin geostrofik|geostrofik|jet stream|arus jet|stabilitas atmosfer|awan cumulonimbus|awan cumulus|awan stratus|awan cirrus|front atmosfer|kelembapan absolut|kelembapan relatif)\b/],
    ['visibility', /\b(jarak pandang|jarak lihat|visibilitas|visibility|kabut|berkabut)\b/],
    ['condition', /\b(cerah|cerah berawan|berawan|mendung|kondisi cuaca|cuaca sekarang|keadaan cuaca)\b/],
    ['cloud', /\b(tutupan awan|jenis awan|awan cumulonimbus|awan cumulus|awan stratus|awan cirrus|cumulonimbus|cumulus|stratus|cirrus)\b/],
    ['lightning', /\b(petir|kilat|guntur|badai petir|thunderstorm)\b/],
    ['source', /\b(sumber data|data dari mana|asal data|bmkg atau model|model cuaca|akurasi prakiraan)\b/],
    ['jogging', /\b(jogging|lari|berlari|olahraga pagi|olahraga sore)\b/],
    ['cycling', /\b(bersepeda|sepeda|gowes|naik sepeda)\b/],
    ['laundry', /\b(jemuran|menjemur|jemur pakaian|pakaian kering|baju kering|mengeringkan pakaian)\b/],
    ['travel', /\b(perjalanan|bepergian|keluar rumah|naik motor|berkendara|motoran|berangkat|pergi|mudik|jalan jauh)\b/],
    ['equipment', /\b(bawa apa|apa yang.*bawa|perlu.*bawa|harus.*bawa|payung|jas hujan|jaket|sunscreen|topi|kacamata|sepatu antiair|botol air|minum|masker|pakaian hangat)\b/],
    ['flood', /\b(banjir|genangan|hujan ekstrem|hujan ekstrim|luapan|banjir bandang)\b/],
    ['drought', /\b(kekeringan|kemarau|defisit hujan|kekurangan air|ketersediaan air)\b/],
    ['agriculture', /\b(tanaman|pertanian|irigasi|menyiram|disiram|penyiraman|kebutuhan air|sawah|kebun|tanam|pemupukan)\b/],
    ['tourism', /\b(wisata|piknik|jalan jalan|liburan|rekreasi|outdoor)\b/],
    ['uv', /\b(uv|indeks uv|sinar ultraviolet|panas matahari|paparan matahari|sunscreen)\b/],
    ['air', /\b(kualitas udara|aqi|pm2 ?5|pm10|polusi udara|udara bersih|udara sehat|udara tercemar)\b/],
    ['humidity', /\b(kelembapan relatif|kelembaban relatif|kelembapan udara|kelembaban udara|kelembapan|kelembaban|relative humidity|humidity|lembap|lembab|gerah)\b/],
    ['windDirection', /\b(arah angin|angin dari mana|dari arah mana angin|angin menuju ke mana)\b/],
    ['wind', /\b(angin|hembusan|kecepatan angin)\b/],
    ['temperature', /\b(suhu|temperatur|panas sekali|dingin sekali|sangat panas|terasa panas)\b/],
    ['forecast15', /\b(15 hari|lima belas hari|15 hari ke depan)\b/],
    ['forecast4', /\b(4 hari|empat hari|96 jam|empat hari ke depan)\b/],
    ['forecast7', /\b(7 hari|tujuh hari|seminggu)\b/],
    ['forecast10', /\b(10 hari|sepuluh hari)\b/],
    ['forecast48', /\b(48 jam|dua hari|2 hari|dua hari ke depan)\b/],
    ['rain', /\b(hujan|hujan tidak|bakal hujan|turun hujan|peluang hujan|kemungkinan hujan|cuaca|prakiraan|ramalan|besok pagi|hari ini|nanti sore|malam ini|lusa)\b/],
  ];
  for (const [intent, pattern] of rules) if (pattern.test(q)) return intent;
  return 'unknown';
}
function filterHours(q, hourly) {
  const now = Date.now(), today = todayJakarta();
  let target = null;
  if (/\blusa\b/.test(q)) target = addDays(today, 2);
  else if (/\bbesok\b/.test(q)) target = addDays(today, 1);
  else if (/\bhari ini\b|\bsekarang\b|\bnanti\b|\bmalam ini\b/.test(q)) target = today;
  const part = /\bsubuh\b/.test(q) ? 'subuh' : /\bpagi\b/.test(q) ? 'pagi' : /\bsiang\b/.test(q) ? 'siang' : /\bsore\b/.test(q) ? 'sore' : /\bmalam\b/.test(q) ? 'malam' : '';
  const specific = q.match(/\bjam\s*(\d{1,2})(?:[.:](\d{2}))?\b/);
  let rows = (hourly || []).map(r => ({ ...r, local: localParts(r.time) })).filter(r => r.local);
  if (target) rows = rows.filter(r => r.local.date === target && (target !== today || new Date(r.time).getTime() >= now - 30 * 60_000));
  else rows = rows.filter(r => new Date(r.time).getTime() >= now - 30 * 60_000);
  if (part) rows = rows.filter(r => part === 'subuh' ? r.local.hour >= 4 && r.local.hour < 7 : part === 'pagi' ? r.local.hour >= 5 && r.local.hour < 11 : part === 'siang' ? r.local.hour >= 11 && r.local.hour < 15 : part === 'sore' ? r.local.hour >= 15 && r.local.hour < 18 : r.local.hour >= 18 && r.local.hour < 24);
  if (specific) {
    const h = Number(specific[1]);
    rows.sort((a, b) => Math.abs(a.local.hour - h) - Math.abs(b.local.hour - h));
    rows = rows.slice(0, 1);
  }
  if (!target && !part && !specific && rows.length > 24) rows = rows.slice(0, 24);
  return { rows, target, part };
}
function latestAvailable(rows, key) { return rows.filter(x => finite(x[key])); }
function maxRow(rows, key) { const a = latestAvailable(rows, key); return a.length ? a.reduce((p, c) => Number(c[key]) > Number(p[key]) ? c : p) : null; }
function minRow(rows, key) { const a = latestAvailable(rows, key); return a.length ? a.reduce((p, c) => Number(c[key]) < Number(p[key]) ? c : p) : null; }
function nearestRow(rows, key) { const a = latestAvailable(rows, key); return a.length ? a.reduce((p, c) => Math.abs(new Date(c.time).getTime() - Date.now()) < Math.abs(new Date(p.time).getTime() - Date.now()) ? c : p) : null; }
function hourLabel(row) {
  const p = localParts(row.time);
  if (!p) return 'waktu tidak diketahui';
  return `${p.hour.toString().padStart(2, '0')}.${p.minute.toString().padStart(2, '0')} WIB`;
}
function dateTimeLabel(row) { const p = localParts(row.time); return p ? `${dateLabel(p.date)} pukul ${hourLabel(row)}` : 'waktu tidak diketahui'; }
function periodName(q, selection) {
  if (selection.target) return dateLabel(selection.target);
  if (selection.part) return `periode ${selection.part}`;
  if (/\b4 hari\b|\bempat hari\b|\b96 jam\b/.test(q)) return '4 hari ke depan';
  if (/\b15 hari\b|\blima belas hari\b/.test(q)) return 'hari ini + 15 hari ke depan';
  if (/\b48 jam\b|\bdua hari\b|\b2 hari\b/.test(q)) return '48 jam ke depan';
  if (/\b10 hari\b|\bseminggu\b|\b7 hari\b/.test(q)) return 'beberapa hari ke depan';
  return 'periode prakiraan terdekat';
}
function selectedRainSummary(rows) {
  const peak = maxRow(rows, 'rain'), wet = rows.filter(x => (finite(x.rain) && Number(x.rain) >= 60) || (finite(x.precip) && Number(x.precip) >= 0.3));
  if (!peak) return 'Angka peluang hujan belum tersedia pada periode yang dipilih.';
  return `Peluang hujan tertinggi ${pct(peak.rain)} sekitar ${dateTimeLabel(peak)}${wet.length ? `; ada ${wet.length} slot dengan sinyal hujan` : '; tidak terlihat sinyal hujan kuat dari slot yang tersedia'}.`;
}
function compassFromDegrees(value) {
  if (!finite(value)) return '';
  const labels = ['Utara','Timur Laut','Timur','Tenggara','Selatan','Barat Daya','Barat','Barat Laut'];
  const d = ((Number(value) % 360) + 360) % 360;
  return labels[Math.round(d / 45) % 8];
}
function dewPointC(temp, humidity) {
  if (!finite(temp) || !finite(humidity) || Number(humidity) <= 0 || Number(humidity) > 100) return null;
  const t = Number(temp), rh = Number(humidity), a = 17.625, b = 243.04;
  const gamma = Math.log(rh / 100) + (a * t) / (b + t);
  const result = (b * gamma) / (a - gamma);
  return Number.isFinite(result) ? result : null;
}
function explainWeather(q) {
  const topics = [
    [/\b(enso|el nino|la nina|el-niño|la niña)\b/, 'ENSO adalah pola interaksi laut-atmosfer di Samudra Pasifik tropis. El Niño ditandai pemanasan anomali Pasifik tengah-timur dan sering mengurangi hujan di banyak wilayah Indonesia; La Niña berupa pendinginan anomali dan sering meningkatkan peluang hujan. Dampaknya tidak sama di semua daerah atau setiap bulan, sehingga perlu dibaca bersama prediksi BMKG dan kondisi lokal.'],
    [/\b(mjo|madden julian)\b/, 'MJO (Madden–Julian Oscillation) adalah gangguan konveksi tropis yang bergerak ke arah timur di sekitar wilayah tropis, umumnya dalam skala puluhan hari. Saat fase aktif melintasi sekitar Indonesia, pembentukan awan dan hujan dapat meningkat, tetapi dampak lokal tetap bergantung pada monsun, topografi, dan kondisi atmosfer lain.'],
    [/\b(rossby)\b/, 'Gelombang Rossby adalah gelombang skala besar dalam atmosfer yang dipengaruhi rotasi Bumi dan perubahan vortisitas. Gelombang ini dapat membantu membentuk daerah konvergensi, belokan angin, atau peningkatan/pengurangan pembentukan awan dan hujan. Dampaknya harus dilihat dari analisis atmosfer aktual, bukan dari nama fenomenanya saja.'],
    [/\b(konvergensi)\b/, 'Konvergensi adalah pertemuan aliran udara dari beberapa arah sehingga massa udara berkumpul. Di dekat permukaan, konvergensi dapat mendorong udara naik; bila udaranya lembap dan atmosfer mendukung, awan konvektif dan hujan dapat berkembang. Konvergensi saja tidak otomatis menghasilkan hujan lebat.'],
    [/\b(konveksi)\b/, 'Konveksi atmosfer adalah gerak vertikal udara akibat perbedaan daya apung, sering dipicu pemanasan permukaan atau ketidakstabilan atmosfer. Udara hangat-lembap yang naik dapat mendingin dan membentuk awan; konveksi kuat dapat menghasilkan cumulonimbus, hujan lebat, dan petir.'],
    [/\b(hujan orografis|orografis)\b/, 'Hujan orografis terjadi ketika udara lembap dipaksa naik oleh pegunungan atau dataran tinggi. Udara mendingin saat naik, uap air mengembun, lalu dapat menghasilkan hujan di sisi hadap angin. Sisi bawah angin dapat lebih kering (bayangan hujan), tetapi pola aktual bergantung arah angin dan kestabilan atmosfer.'],
    [/\b(front atmosfer)\b/, 'Front atmosfer adalah zona peralihan antara dua massa udara dengan karakter suhu dan kelembapan berbeda. Pengangkatan udara di sepanjang front dapat membentuk awan dan presipitasi; jenis serta intensitas cuaca bergantung pada sifat massa udara, kecepatan gerak, dan kestabilan atmosfer.'],
    [/\b(angin geostrofik|geostrofik)\b/, 'Angin geostrofik adalah pendekatan angin di atmosfer bebas ketika gaya gradien tekanan dan gaya Coriolis hampir seimbang. Angin ini bertiup kira-kira sejajar isobar; pendekatan tersebut lebih sesuai di atas lapisan gesekan dan pada skala ruang/waktu cukup besar.'],
    [/\b(jet stream|arus jet)\b/, 'Jet stream adalah pita angin sangat kencang di lapisan atas troposfer, umumnya dekat tropopause. Jet stream dipengaruhi gradien suhu horizontal dan rotasi Bumi, serta dapat mengarahkan sistem cuaca skala besar. Posisi dan kekuatannya berubah dari waktu ke waktu.'],
    [/\b(stabilitas atmosfer)\b/, 'Stabilitas atmosfer menggambarkan kecenderungan parcel udara yang terganggu untuk kembali, tetap, atau terus menjauh dari posisi awalnya. Stabilitas dipengaruhi profil suhu vertikal dan kelembapan; atmosfer labil mendukung pertumbuhan vertikal awan, sedangkan atmosfer stabil cenderung menekan gerak vertikal.'],
    [/\b(monsun|muson)\b/, 'Monsun adalah perubahan pola angin musiman akibat perbedaan pemanasan daratan dan lautan. Di Indonesia, monsun barat umumnya membawa lebih banyak uap air ke banyak wilayah sehingga mendukung musim hujan, sedangkan monsun timur cenderung lebih kering. Waktu dan dampaknya berbeda menurut wilayah dan dapat dimodifikasi ENSO, IOD, MJO, serta topografi.'],
    [/\b(siklon|antisiklon)\b/, 'Siklon adalah sistem tekanan rendah dengan aliran angin berputar menuju pusat dan cenderung mendukung konvergensi serta gerak udara naik. Antisiklon adalah sistem tekanan tinggi dengan aliran menjauhi pusat dan umumnya berkaitan dengan subsidensi. Arah putaran berbeda antara belahan Bumi utara dan selatan karena efek Coriolis.'],
    [/\b(foehn|angin fohn)\b/, 'Angin Föhn adalah angin turun di sisi bawah angin pegunungan yang menjadi lebih hangat dan relatif kering setelah udara naik, mendingin, mengembun, lalu turun dan terkompresi. Efeknya bergantung pada arah angin, kestabilan atmosfer, dan kondisi topografi.'],
    [/\b(inversi suhu)\b/, 'Inversi suhu adalah keadaan ketika suhu udara meningkat dengan bertambahnya ketinggian pada suatu lapisan, berlawanan dengan penurunan suhu yang lazim di troposfer. Inversi dapat menahan pencampuran vertikal sehingga kabut, asap, atau polutan lebih mudah terperangkap dekat permukaan.'],
    [/\b(dalr|malr|lapse rate)\b/, 'Lapse rate adalah laju perubahan suhu terhadap ketinggian. DALR (dry adiabatic lapse rate) sekitar 9,8°C per km untuk parcel udara tak jenuh. MALR (moist adiabatic lapse rate) bervariasi, umumnya lebih kecil karena pelepasan panas laten saat kondensasi; nilainya tidak konstan 6°C/km untuk semua kondisi.'],
    [/\b(cumulonimbus|awan badai)\b/, 'Cumulonimbus (Cb) adalah awan konvektif yang tumbuh tinggi dan dapat menghasilkan hujan lebat, petir, angin kencang, hujan es, atau turbulensi. Kehadiran awan Cb pada pengamatan tidak otomatis berarti semua dampak itu terjadi di lokasi pengguna; ikuti radar dan peringatan resmi.'],
    [/\b(cumulus|stratus|cirrus|jenis awan)\b/, 'Cumulus biasanya berupa gumpalan dengan perkembangan vertikal; stratus berupa lapisan rendah yang luas dan dapat berkaitan dengan gerimis; cirrus adalah awan tinggi berserat yang tersusun dari kristal es. Jenis awan membantu memahami keadaan atmosfer, tetapi tidak cukup sendirian untuk memastikan hujan di titik tertentu.'],
    [/\b(titik embun|dew point|dewpoint)\b/, 'Titik embun adalah suhu ketika udara perlu didinginkan (pada tekanan tetap dan kandungan uap air tetap) hingga mencapai kejenuhan. Semakin dekat suhu udara dengan titik embun, semakin tinggi kelembapan relatif dan semakin mungkin terbentuk embun atau kabut jika kondisi lain mendukung.'],
    [/\b(tekanan udara|tekanan atmosfer|barometer|hpa|milibar)\b/, 'Tekanan udara adalah gaya per satuan luas akibat berat kolom udara di atas suatu tempat. Satuan yang umum dipakai adalah hPa (setara numerik dengan millibar). Tekanan berubah menurut ketinggian dan sistem cuaca; untuk membandingkan cuaca antarlokasi, perhatikan apakah nilainya tekanan stasiun atau tekanan yang direduksi ke permukaan laut.'],
    [/\b(iod|dipole mode|dipole samudra hindia)\b/, 'Indian Ocean Dipole (IOD) adalah perbedaan anomali suhu permukaan laut antara Samudra Hindia bagian barat dan timur. IOD positif sering berkaitan dengan berkurangnya pasokan uap air dan hujan di sebagian Indonesia, sedangkan IOD negatif dapat mendukung peningkatan hujan. Dampaknya bergantung musim, lokasi, ENSO, dan pola atmosfer lain.'],
    [/\b(itcz|zCIT|zona konvergensi intertropis|daerah konvergensi intertropis)\b/i, 'ITCZ atau Zona Konvergensi Intertropis adalah sabuk pertemuan angin pasat di wilayah tropis yang sering disertai gerak udara naik, awan konvektif, dan hujan. Posisi ITCZ bergeser mengikuti pemanasan musiman dan dapat memengaruhi distribusi hujan di Indonesia.'],
    [/\b(angin darat|angin laut)\b/, 'Angin laut umumnya bertiup dari laut ke darat pada siang hari karena daratan lebih cepat panas; udara di atas darat naik dan digantikan udara laut. Angin darat umumnya bertiup dari darat ke laut pada malam hari ketika daratan lebih cepat mendingin. Kekuatan sebenarnya dipengaruhi gradien tekanan sinoptik, topografi, dan kondisi lokal.'],
    [/\b(angin gunung|angin lembah)\b/, 'Angin lembah biasanya mengalir menaiki lereng pada siang hari ketika lereng dipanaskan, sedangkan angin gunung biasanya mengalir menuruni lereng pada malam hari saat udara dekat lereng mendingin dan menjadi lebih rapat. Sirkulasi lokal ini dapat berinteraksi dengan angin skala besar dan memengaruhi awan di pegunungan.'],
    [/\b(bayangan hujan|rain shadow)\b/, 'Bayangan hujan adalah wilayah di sisi bawah angin pegunungan yang cenderung lebih kering karena sebagian uap air telah turun sebagai hujan di sisi hadap angin. Efek ini tidak selalu tetap; arah angin, kestabilan atmosfer, dan jalur badai dapat mengubah pola hujan.'],
    [/\b(indeks panas|heat index|suhu terasa panas)\b/, 'Indeks panas menggabungkan suhu udara dan kelembapan untuk memperkirakan tekanan panas pada tubuh di tempat teduh. Paparan matahari langsung, angin, pakaian, aktivitas, dan kondisi individu juga memengaruhi risiko; karena itu indeks panas bukan pengukuran suhu tubuh.'],
    [/\b(wind chill|suhu terasa dingin|pendinginan angin)\b/, 'Wind chill menggambarkan laju kehilangan panas tubuh akibat gabungan suhu udara rendah dan angin pada kulit yang terbuka. Nilai ini bukan suhu udara sebenarnya. Pakaian basah, durasi paparan, dan perlindungan dari angin ikut menentukan risiko hipotermia.'],
    [/\b(embun|kabut radiasi)\b/, 'Embun terbentuk ketika permukaan mendingin hingga suhu permukaannya mencapai atau turun di bawah titik embun sehingga uap air mengembun. Kabut radiasi dapat terbentuk pada malam atau dini hari yang relatif tenang dan langit cerah ketika udara dekat permukaan mendingin; topografi dan kelembapan lokal berpengaruh.'],
    [/\b(hujan es|hail)\b/, 'Hujan es terbentuk di awan konvektif kuat ketika butiran es tumbuh dalam arus naik dan akhirnya jatuh saat terlalu berat untuk ditopang. Kejadiannya bersifat lokal dan tidak dapat dipastikan hanya dari suhu permukaan atau peluang hujan biasa; pantau radar dan peringatan resmi.'],
  ];
  for (const [pattern, answer] of topics) if (pattern.test(q)) return answer;
  return 'Saya bisa menjelaskan konsep meteorologi dan klimatologi, tetapi pertanyaan ini belum cocok dengan topik pengetahuan yang tersedia. Sebutkan istilah atau fenomenanya secara lebih spesifik agar saya tidak menebak.';
}
function answerQuestion(question, context = {}, history = []) {
  const q = normalize(resolveFollowUp(question, history));
  const ctx = cleanContext(context);
  const intent = classify(q);
  const place = ctx.location;
  const current = ctx.current || {};
  const selection = filterHours(q, ctx.hourly);
  const rows = selection.rows;
  const days = ctx.daily || [];
  const period = periodName(q, selection);
  const peakRain = maxRow(rows, 'rain');
  const peakWind = maxRow(rows, 'wind');
  const peakUv = maxRow(rows, 'uv');
  const minTemp = minRow(rows, 'temp');
  const maxTemp = maxRow(rows, 'temp');
  const rainTotal = rows.some(x => finite(x.precip)) ? rows.reduce((sum, x) => sum + (finite(x.precip) ? Math.max(0, Number(x.precip)) : 0), 0) : null;
  const condition = current.condition || weatherConditionFromCode(current.code) || 'belum tersedia';

  if (intent === 'menu') return 'Fikri Weather menyediakan Ringkasan Cuaca, prakiraan per jam dan harian, radar hujan, citra satelit, peringatan, informasi gempa dan bencana geologi, kemarau, maritim, bandara, Cuaca Gunung, serta informasi pertanian dan peternakan. Rekomendasi aktivitas dan perlengkapan juga tersedia di Dashboard. Tanya Fikri Weather berfokus pada cuaca, meteorologi, klimatologi, dan informasi cuaca dari fitur website.';
  if (intent === 'mountain') return 'Untuk status aktivitas gunung api, jalur pendakian, prakiraan per titik, dan peringatan gunung, buka menu Cuaca Gunung lalu pilih nama gunung. Status resmi harus mengikuti laporan PVMBG/MAGMA terbaru; saya tidak akan menebak status gunung dari prakiraan cuaca. Untuk kondisi jalur dan penutupan, ikuti pengumuman pengelola.';
  if (intent === 'explain') return explainWeather(q);
  if (intent === 'source') return `Fikri Weather memprioritaskan prakiraan BMKG pada wilayah dan waktu yang tersedia. Variabel atau slot yang tidak diterbitkan BMKG dapat dilengkapi model cuaca dan harus dibaca sesuai label sumbernya. Sumber model yang diteruskan ke asisten: ${ctx.source || 'label sumber rinci belum tersedia pada konteks chat'}. Prakiraan model bukan pengamatan langsung. Lokasi aktif: ${place}. Pembaruan data terakhir: ${ctx.fetchedAt || 'waktu pembaruan belum tersedia'}. Perkiraan dapat berubah dan tidak menggantikan peringatan resmi.`;
  if (intent === 'alerts') return ctx.alerts.length ? `Peringatan yang diterima untuk ${place}:\n• ${ctx.alerts.join('\n• ')}\n\nPeriksa halaman Peringatan & Sumber untuk waktu berlaku dan instruksi resmi.` : `Saya belum menerima isi peringatan aktif pada konteks cuaca untuk ${place}. Periksa menu Peringatan & Sumber dan kanal resmi BMKG/BPBD. Saya tidak akan menyimpulkan tidak ada peringatan hanya karena data peringatan tidak termuat.`;
  if (intent === 'air') {
    const air = ctx.air || {};
    const usAqi = finite(air.usAqi) ? Number(air.usAqi) : null;
    const europeanAqi = finite(air.europeanAqi) ? Number(air.europeanAqi) : null;
    const pm25 = finite(air.pm25) ? Number(air.pm25) : null, pm10 = finite(air.pm10) ? Number(air.pm10) : null;
    const ozone = finite(air.ozone) ? Number(air.ozone) : null;
    if (usAqi === null && europeanAqi === null && pm25 === null && pm10 === null) return `Keluaran model kualitas udara untuk ${place} belum memuat indeks atau konsentrasi partikel yang dapat ditafsirkan. Jangan menyamakan kondisi cerah dengan kualitas udara bersih; asap, debu, dan polutan tidak selalu terlihat. Periksa sumber pemantauan kualitas udara lokal bila tersedia.`;
    const category = usAqi === null ? '' : usAqi <= 50 ? 'Baik' : usAqi <= 100 ? 'Sedang' : usAqi <= 150 ? 'Tidak sehat bagi kelompok sensitif' : usAqi <= 200 ? 'Tidak sehat' : usAqi <= 300 ? 'Sangat tidak sehat' : 'Berbahaya';
    const vals = [usAqi !== null ? `US AQI ${Math.round(usAqi)} (${category})` : '', europeanAqi !== null ? `European AQI ${Math.round(europeanAqi)} (skala EEA; tidak disamakan dengan US AQI)` : '', pm25 !== null ? `PM2.5 ${pm25.toFixed(1)} µg/m³` : '', pm10 !== null ? `PM10 ${pm10.toFixed(1)} µg/m³` : '', ozone !== null ? `ozon ${ozone.toFixed(1)} µg/m³` : ''].filter(Boolean).join('; ');
    return `Estimasi kualitas udara untuk ${place}: ${vals}. Sumber: ${air.source || 'model kualitas udara'}${air.resolutionKm ? `, resolusi grid sekitar ${Math.round(air.resolutionKm)} km` : ''}${air.time ? `, waktu keluaran ${air.time}` : ''}. Ini estimasi model regional, bukan pembacaan sensor di tepi jalan atau rumah. ${usAqi !== null && usAqi > 100 ? 'Kurangi aktivitas berat di luar, terutama kelompok sensitif; periksa pemantauan lokal.' : 'Gunakan sebagai gambaran regional dan periksa kondisi lokal, khususnya saat ada asap atau debu.'}`;
  }
  if (intent === 'dewpoint') {
    const paired = ctx.hourly.filter(r => finite(r.temp) && finite(r.humidity)).reduce((best, row) => !best || Math.abs(new Date(row.time).getTime() - Date.now()) < Math.abs(new Date(best.time).getTime() - Date.now()) ? row : best, null);
    const hasCurrentPair = finite(current.temp) && finite(current.humidity);
    const temp = hasCurrentPair ? Number(current.temp) : paired ? Number(paired.temp) : null;
    const humidity = hasCurrentPair ? Number(current.humidity) : paired ? Number(paired.humidity) : null;
    const dew = dewPointC(temp, humidity);
    if (dew === null) return `Titik embun untuk ${place} belum dapat dihitung karena suhu dan kelembapan relatif pada waktu yang sama belum tersedia.`;
    return `Titik embun adalah suhu saat udara mencapai jenuh jika didinginkan tanpa mengubah kandungan uap airnya. Perkiraan titik embun di ${place} sekitar ${dew.toFixed(1)}°C, dihitung dari suhu ${temp.toFixed(1)}°C dan kelembapan relatif ${Math.round(humidity)}% pada data saat ini. Ini estimasi termodinamika, bukan pengukuran sensor langsung.`;
  }
  if (intent === 'pressure') {
    const p = finite(current.pressure) ? Number(current.pressure) : nearestRow(rows, 'pressure')?.pressure;
    if (!finite(p)) return `Tekanan udara untuk ${place} belum tersedia pada data yang diterima. Tekanan biasanya dinyatakan dalam hPa; jangan membandingkan tekanan stasiun di ketinggian berbeda tanpa koreksi ke permukaan laut.`;
    return `Tekanan yang tersedia untuk ${place} sekitar ${n(p, 1)} hPa. Nilai ini perlu dibaca sesuai jenis datanya (tekanan permukaan laut atau tekanan stasiun). Perubahan tekanan dapat membantu mengenali perubahan sistem cuaca, tetapi satu nilai saja tidak cukup untuk memastikan hujan atau badai.`;
  }
  if (intent === 'visibility') {
    const currentVis = finite(current.visibility) ? Number(current.visibility) : null;
    const rowVis = latestAvailable(rows, 'visibility');
    const minVis = rowVis.length ? Math.min(...rowVis.map(x => Number(x.visibility))) : null;
    const maxVis = rowVis.length ? Math.max(...rowVis.map(x => Number(x.visibility))) : null;
    if (currentVis === null && minVis === null) return `Jarak pandang untuk ${place} belum tersedia pada periode ini. Kabut atau hujan dapat mengurangi jarak pandang, tetapi saya tidak akan menebak nilainya.`;
    const asKm = v => v === null ? 'belum tersedia' : `${(v > 100 ? v / 1000 : v).toFixed(1)} km`;
    return `Jarak pandang yang tersedia di ${place}: ${currentVis !== null ? `nilai saat ini sekitar ${asKm(currentVis)}` : `saat ini belum tersedia`}${minVis !== null ? `; rentang prakiraan pada periode terpilih sekitar ${asKm(minVis)}–${asKm(maxVis)}` : ''}. Jarak pandang dapat turun karena kabut, hujan lebat, asap, atau partikel udara. Kurangi kecepatan dan hindari perjalanan bila pandangan tidak aman.`;
  }
  if (intent === 'condition') {
    if (rows.length) {
      const conditions = [...new Set(rows.map(r => r.condition || weatherConditionFromCode(r.code)).filter(Boolean))];
      const peak = maxRow(rows, 'rain');
      const total = rows.some(r => finite(r.precip)) ? rows.reduce((sum, r) => sum + (finite(r.precip) ? Math.max(0, Number(r.precip)) : 0), 0) : null;
      return `Perkiraan kondisi cuaca di ${place} pada ${period}: ${conditions.length ? conditions.join(', ') : 'label kondisi belum tersedia'} . ${peak ? `Peluang hujan tertinggi ${pct(peak.rain)}.` : 'Peluang hujan belum tersedia.'} ${total !== null ? `Akumulasi presipitasi dari slot yang termuat sekitar ${n(total, 1)} mm.` : 'Akumulasi presipitasi belum tersedia.'} Kondisi dapat berubah; cocokkan dengan radar dan peringatan BMKG.`;
    }
    const codeCondition = weatherConditionFromCode(current.code);
    return `Kondisi cuaca saat ini di ${place}: ${current.condition || codeCondition || 'belum dapat ditentukan dari variabel yang termuat'}. ${codeCondition && !current.condition ? 'Label kondisi diturunkan dari kode cuaca WMO pada data model.' : ''} Prakiraan per jam untuk periode yang diminta belum termuat.`;
  }
  if (intent === 'cloud') {
    const cloud = maxRow(rows, 'cloud');
    const currentCloud = finite(current.cloud) ? Number(current.cloud) : null;
    const value = currentCloud ?? cloud?.cloud;
    if (!finite(value)) return 'Data persentase tutupan awan belum tersedia untuk lokasi/periode ini. Secara umum, awan terbentuk saat udara lembap naik dan mendingin hingga mendekati jenuh; jenis awan saja tidak cukup untuk memastikan hujan.';
    return `Tutupan awan yang tersedia untuk ${place} sekitar ${Math.round(Number(value))}%${cloud ? ` pada ${dateTimeLabel(cloud)}` : ''}. Tutupan awan adalah persentase langit yang tertutup awan, bukan peluang hujan. Awan tebal/berkembang vertikal dapat berkaitan dengan hujan, tetapi kepastian hujan perlu dilihat dari prakiraan presipitasi dan radar.`;
  }
  if (intent === 'lightning') {
    const thunderRows = rows.filter(r => [95,96,99].includes(Number(r.code)));
    const alertText = ctx.alerts.filter(x => /petir|guntur|thunderstorm|kilat/i.test(x));
    if (thunderRows.length || alertText.length) return `Sinyal badai petir terdeteksi untuk ${place}${thunderRows.length ? ` pada ${thunderRows.slice(0,4).map(dateTimeLabel).join('; ')}` : ''}${alertText.length ? `. Peringatan: ${alertText.join('; ')}` : ''}. Kode cuaca badai petir adalah sinyal prakiraan, bukan probabilitas sambaran di titik tertentu. Segera masuk ke bangunan/kendaraan tertutup ketika terdengar guntur; jauhi lapangan terbuka, pohon tunggal, dan benda logam.`;
    return `Keluaran cuaca yang diterima untuk ${place} tidak memuat sinyal WMO badai petir pada slot yang sedang diperiksa. Ini bukan jaminan bebas petir karena badai dapat berkembang lokal dan probabilitas sambaran langsung tidak dihitung di sini. Periksa peringatan BMKG/radar; jika terdengar guntur, segera cari bangunan atau kendaraan tertutup.`;
  }
  if (intent === 'windDirection') {
    const row = rows.filter(r => finite(r.windDirDeg)).reduce((best, item) => !best || Math.abs(new Date(item.time).getTime() - Date.now()) < Math.abs(new Date(best.time).getTime() - Date.now()) ? item : best, null);
    const directionText = /\b(utara|timur|selatan|barat|laut|tenggara|barat daya|barat laut)\b/i.test(current.windDir || '') ? current.windDir : compassFromDegrees(current.windDirDeg);
    const rowDirection = row ? compassFromDegrees(row.windDirDeg) : '';
    const bestDirection = directionText || rowDirection;
    if (!bestDirection) return `Data arah angin untuk ${place} belum memiliki nilai derajat pada periode yang dipilih. Kecepatan angin tidak digunakan untuk menebak arahnya.`;
    return `Arah angin ${place}: ${directionText ? `saat ini dari ${directionText}` : `dari ${rowDirection} pada ${dateTimeLabel(row)}`}${row && finite(row.wind) ? ` dengan kecepatan ${kmh(row.wind)}` : ''}. Arah angin meteorologi menyatakan dari mana angin bertiup, bukan ke mana angin menuju.`;
  }
  if (intent === 'humidity') {
    const nearestHumidity = nearestRow(rows, 'humidity'), nearestTemp = nearestRow(rows, 'temp');
    const h = finite(current.humidity) ? Number(current.humidity) : nearestHumidity?.humidity;
    const t = finite(current.temp) ? Number(current.temp) : nearestTemp?.temp;
    if (!finite(h)) return `Nilai kelembapan untuk ${place} belum tersedia. Kelembapan relatif adalah perbandingan tekanan uap air aktual terhadap tekanan uap jenuh pada suhu yang sama. Nilai tinggi biasanya membuat keringat lebih lambat menguap sehingga tubuh terasa lebih gerah.`;
    return `Kelembapan relatif yang tersedia di ${place} sekitar ${pct(h)}${finite(t) ? ` pada suhu ${celsius(t)}` : ''}. Kelembapan tinggi berarti udara mendekati jenuh pada suhu tersebut; bukan berarti udara pasti mengandung uap air paling banyak secara absolut. Kondisi ini dapat membuat badan terasa gerah dan pakaian lebih lambat kering.`;
  }
  if (intent === 'temperature') {
    const nearestTemp = nearestRow(rows, 'temp'), nearestFeels = nearestRow(rows, 'feels'), nearestHumidity = nearestRow(rows, 'humidity');
    const t = finite(current.temp) ? Number(current.temp) : nearestTemp?.temp;
    const feels = finite(current.feels) ? Number(current.feels) : nearestFeels?.feels;
    const hum = finite(current.humidity) ? Number(current.humidity) : nearestHumidity?.humidity;
    if (!finite(t)) return `Data suhu untuk ${place} belum tersedia saat ini maupun pada slot prakiraan yang dipilih. Saya tidak akan menebak nilainya.`;
    return `Di ${place}, suhu yang tersedia ${celsius(t)}${finite(feels) ? ` dan suhu terasa ${celsius(feels)}` : ''}. ${finite(hum) ? `Kelembapan ${pct(hum)}.` : ''} Rasa panas juga dapat dipengaruhi kelembapan, paparan matahari, dan angin. ${peakUv && Number(peakUv.uv) >= 6 ? `Indeks UV pada periode terpilih dapat mencapai ${n(peakUv.uv)}; kurangi paparan langsung saat tengah hari.` : 'Cari tempat teduh dan cukup minum saat beraktivitas di luar.'}`;
  }
  if (intent === 'uv') {
    if (!rows.some(x => finite(x.uv)) && !days.some(x => finite(x.uv))) return 'Data indeks UV per jam/hari belum tersedia untuk lokasi dan periode ini. Saya tidak akan membuat angka UV. Gunakan perlindungan matahari saat indeks UV tinggi berdasarkan informasi resmi yang tersedia.';
    const u = peakUv?.uv ?? days.find(d => finite(d.uv))?.uv;
    const level = Number(u) >= 11 ? 'ekstrem' : Number(u) >= 8 ? 'sangat tinggi' : Number(u) >= 6 ? 'tinggi' : Number(u) >= 3 ? 'sedang' : 'rendah';
    return `Indeks UV tertinggi pada ${period} sekitar ${n(u)} (${level}). ${Number(u) >= 3 ? 'Gunakan sunscreen SPF 30 atau lebih, topi, dan kacamata; cari tempat teduh terutama sekitar pukul 10.00–15.00 WIB.' : 'Paparan UV diprakirakan relatif rendah, tetapi tetap sesuaikan perlindungan dengan lama aktivitas dan kondisi aktual.'}`;
  }
  if (intent === 'forecast4') {
    if (!days.length && !ctx.hourly.length) return `Prakiraan 4 hari untuk ${place} belum tersedia. Perbarui data cuaca terlebih dahulu; saya tidak akan mengisi angka yang tidak diterima.`;
    const rows4 = days.slice(0, 4);
    if (rows4.length) {
      const lines = rows4.map(d => `${dateLabel(d.day)}: ${d.condition || 'kondisi tidak tersedia'}, ${celsius(d.lo)}–${celsius(d.hi)}, peluang hujan ${pct(d.p)}, curah hujan ${finite(d.rain) ? `${n(d.rain, 1)} mm` : 'belum tersedia'}`).join('\n');
      return `Prakiraan 4 hari untuk ${place}:\n${lines}\n\nRincian per jam tersedia sampai 96 jam jika slot datanya termuat. Untuk jam yang tidak dicakup BMKG, data pelengkap harus dibaca sesuai label sumbernya. Prakiraan dapat berubah dan bukan kepastian.`;
    }
    const future = ctx.hourly.filter(r => { const t = new Date(r.time).getTime(); return Number.isFinite(t) && t >= Date.now() - 30 * 60_000; }).slice(0, 96);
    return `Data harian 4 hari belum tersedia untuk ${place}, tetapi ${future.length} slot per jam tersedia dalam rentang hingga 96 jam. ${selectedRainSummary(future)} Gunakan tabel per jam dan periksa label sumber tiap slot; prakiraan dapat berubah.`;
  }
  if (intent === 'forecast15' || intent === 'forecast7' || intent === 'forecast10') {
    const count = intent === 'forecast15' ? 15 : intent === 'forecast7' ? 7 : 10;
    if (!days.length) return `Prakiraan harian ${count} hari untuk ${place} belum tersedia. Coba perbarui data cuaca; angka yang tidak diterima tidak akan saya isi sendiri.`;
    const selectedDays = intent === 'forecast15' ? days.slice(0, 16) : days.slice(0, count);
    const lines = selectedDays.map(d => `${dateLabel(d.day)}: ${d.condition || 'kondisi tidak tersedia'}, ${celsius(d.lo)}–${celsius(d.hi)}, peluang hujan ${pct(d.p)}, akumulasi ${finite(d.rain) ? `${n(d.rain, 1)} mm` : 'belum tersedia'}`).join('\n');
    const heading = intent === 'forecast15' ? 'Prakiraan hari ini + 15 hari ke depan' : `Prakiraan ${count} hari`;
    return `${heading} untuk ${place}:\n${lines}\n\nKetidakpastian umumnya meningkat pada hari-hari yang lebih jauh. Hari setelah cakupan BMKG lokal dapat memakai model pelengkap yang harus dilabeli sebagai model, bukan prakiraan BMKG. Gunakan sebagai kecenderungan, bukan kepastian untuk keputusan penting.`;
  }
  if (intent === 'forecast48') {
    if (!ctx.hourly.length) return `Prakiraan per jam 48 jam untuk ${place} belum tersedia. Perbarui data pada Dashboard terlebih dahulu.`;
    const peak = maxRow(ctx.hourly, 'rain');
    return `Prakiraan 48 jam untuk ${place}: ${selectedRainSummary(ctx.hourly)} ${minTemp && maxTemp ? `Rentang suhu dari slot yang tersedia sekitar ${celsius(minTemp.temp)}–${celsius(maxTemp.temp)}.` : ''} ${peakWind ? `Angin maksimum ${kmh(peakWind.wind)}.` : ''} Total curah hujan terhitung ${rainTotal === null ? 'belum tersedia' : `${n(rainTotal, 1)} mm`} dari slot data yang tersedia.`;
  }
  if (intent === 'rain') {
    if (!rows.length) return `Data prakiraan untuk ${period} di ${place} belum tersedia. Pastikan lokasi sudah dipilih dan data prakiraan berhasil dimuat.`;
    const first = rows[0];
    const summary = selectedRainSummary(rows);
    const peak = maxRow(rows, 'rain');
    return `Untuk ${place} pada ${period}, ${summary} ${peak && Number(peak.rain) >= 60 ? 'Sebaiknya siapkan payung atau jas hujan.' : peak && Number(peak.rain) >= 30 ? 'Payung lipat sebaiknya disiapkan sebagai antisipasi.' : peak ? 'Risiko hujan dari prakiraan ini relatif rendah, tetapi perubahan cuaca lokal tetap mungkin terjadi.' : ''} ${first ? `Kondisi slot terdekat: ${first.condition || 'tidak tercantum'}.` : ''}`;
  }
  if (intent === 'jogging' || intent === 'cycling' || intent === 'laundry' || intent === 'tourism' || intent === 'travel') {
    if (!rows.length) return `Data per jam untuk ${period} belum tersedia di ${place}. Saya belum bisa menentukan waktu terbaik tanpa data suhu, hujan, dan angin.`;
    const allowed = rows.filter(r => {
      const p = r.local;
      if (!p) return false;
      if (intent === 'jogging') return (p.hour >= 5 && p.hour < 10) || (p.hour >= 16 && p.hour < 19);
      if (intent === 'cycling') return p.hour >= 6 && p.hour < 18;
      if (intent === 'laundry') return p.hour >= 8 && p.hour < 16;
      if (intent === 'tourism') return p.hour >= 7 && p.hour < 17;
      return true;
    });
    const score = r => {
      let s = 0;
      if (finite(r.rain)) s += Number(r.rain) <= 20 ? 3 : Number(r.rain) <= 35 ? 1 : -4;
      if (finite(r.precip)) s += Number(r.precip) < 0.2 ? 2 : -3;
      if (finite(r.temp)) s += Number(r.temp) >= 22 && Number(r.temp) <= 30 ? 2 : Number(r.temp) > 33 ? -3 : 0;
      if (finite(r.wind)) s += Number(r.wind) <= 20 ? 1 : Number(r.wind) >= 35 ? -2 : 0;
      if (finite(r.humidity)) s += Number(r.humidity) <= 80 ? 1 : Number(r.humidity) >= 92 ? -2 : 0;
      if (finite(r.visibility)) s += Number(r.visibility) >= 3000 ? 1 : Number(r.visibility) < 1000 ? -2 : 0;
      return s;
    };
    const scored = allowed.map(r => ({ ...r, score: score(r) })).sort((a, b) => b.score - a.score);
    const best = scored.filter(r => r.score >= (intent === 'laundry' ? 5 : 4)).slice(0, 5);
    const bestText = best.length ? best.map(r => `${hourLabel(r)} (${r.condition || 'kondisi tidak tercantum'}${finite(r.temp) ? `, ${celsius(r.temp)}` : ''}${finite(r.rain) ? `, hujan ${pct(r.rain)}` : ''})`).join('; ') : 'belum ditemukan slot yang memenuhi indikator kenyamanan';
    const peak = maxRow(rows, 'rain');
    const windMax = maxRow(rows, 'wind');
    const lowest = minRow(rows, 'temp'), highest = maxRow(rows, 'temp');
    if (intent === 'jogging') return `Untuk jogging di ${place} pada ${period}, waktu yang relatif paling mendukung dari data tersedia: ${bestText}. ${peak && Number(peak.rain) >= 50 ? 'Ada slot dengan peluang hujan cukup tinggi, jadi hindari waktu tersebut.' : 'Tetap cek langit sebelum berangkat.'} ${highest && Number(highest.temp) >= 32 ? 'Hindari olahraga berat saat suhu mendekati puncak siang.' : ''} Bawa air minum dan mulai dengan intensitas ringan.`;
    if (intent === 'cycling') return `Untuk bersepeda di ${place}, slot yang relatif mendukung: ${bestText}. ${windMax && Number(windMax.wind) >= 30 ? `Angin dapat mencapai ${kmh(windMax.wind)}; berhati-hati di jalan terbuka.` : ''} ${peak && Number(peak.rain) >= 40 ? 'Hindari jam dengan peluang hujan lebih tinggi dan gunakan lampu/reflector.' : 'Gunakan helm, lampu, dan tetap waspada terhadap perubahan cuaca.'}`;
    if (intent === 'laundry') return `Untuk menjemur pakaian di ${place}, perkiraan jam yang relatif mendukung: ${bestText}. ${peak && Number(peak.rain) >= 40 ? 'Jangan tinggalkan jemuran tanpa pengawasan pada jam berpeluang hujan.' : 'Pilih area yang mendapat sinar matahari dan aliran udara.'} Estimasi ini mempertimbangkan suhu, kelembapan, hujan, dan angin yang tersedia; waktu kering sebenarnya juga dipengaruhi bahan dan ketebalan pakaian.`;
    if (intent === 'tourism') return `Untuk wisata di ${place}, slot relatif mendukung: ${bestText}. Rentang suhu ${lowest && highest ? `${celsius(lowest.temp)}–${celsius(highest.temp)}` : 'belum lengkap'}. ${peak && Number(peak.rain) >= 40 ? 'Siapkan rencana cadangan di tempat tertutup.' : 'Tetap bawa air minum dan perlindungan matahari.'}`;
    return `Untuk perjalanan di ${place} pada ${period}, slot yang relatif lebih mendukung: ${bestText}. ${peak && Number(peak.rain) >= 50 ? 'Waspadai hujan dan kemungkinan jalan licin.' : 'Tetap periksa kondisi jalan dan cuaca aktual sebelum berangkat.'} ${windMax && Number(windMax.wind) >= 30 ? `Angin cukup kencang pada beberapa slot (hingga ${kmh(windMax.wind)}).` : ''} Data cuaca tidak dapat menjamin suatu perjalanan aman; utamakan kondisi lapangan dan peringatan resmi.`;
  }
  if (intent === 'equipment') {
    if (!rows.length) return `Saya belum menerima prakiraan per jam untuk ${place}, jadi belum bisa menentukan perlengkapan secara akurat. Perbarui data lokasi terlebih dahulu.`;
    const p = maxRow(rows, 'rain')?.rain, uv = maxRow(rows, 'uv')?.uv, t = maxRow(rows, 'temp')?.temp, wind = maxRow(rows, 'wind')?.wind;
    const items = [];
    items.push(finite(p) ? (p >= 50 ? 'Payung/jas hujan: perlu dibawa' : p >= 25 ? 'Payung lipat: disarankan' : 'Payung/jas hujan: tidak terlalu diperlukan menurut prakiraan') : 'Payung/jas hujan: data peluang hujan belum tersedia');
    items.push(finite(uv) ? (uv >= 6 ? 'Sunscreen, topi, dan kacamata: perlu dibawa' : uv >= 3 ? 'Sunscreen: disarankan' : 'Perlindungan UV tambahan: tidak terlalu diperlukan') : 'Perlengkapan UV: indeks UV belum tersedia');
    items.push(finite(t) ? (t >= 30 ? 'Botol air minum: disarankan' : 'Botol air minum: tetap baik dibawa') : 'Botol air minum: tetap baik dibawa');
    items.push(finite(wind) && wind >= 25 ? 'Jaket ringan: disarankan karena angin cukup kencang' : 'Jaket: sesuai kenyamanan pribadi');
    return `Untuk aktivitas pada ${period} di ${place}, perlengkapan yang disarankan:\n• ${items.join('\n• ')}\n\nSaran mengikuti rentang prakiraan yang tersedia. Jika waktu aktivitasmu berbeda, sebutkan jamnya agar rekomendasi bisa dipersempit.`;
  }
  if (intent === 'flood') {
    if (!ctx.hourly.length && !days.length) return 'Data hujan untuk lokasi ini belum tersedia. Tanpa data hujan yang valid, saya tidak dapat menilai sinyal hujan lokal.';
    const rain24Rows = ctx.hourly.filter(r => { const ms = new Date(r.time).getTime(); return Number.isFinite(ms) && ms >= Date.now() - 30 * 60000 && ms < Date.now() + 24 * 3600000; });
    const total24 = rain24Rows.some(r => finite(r.precip)) ? rain24Rows.reduce((s, r) => s + (finite(r.precip) ? Math.max(0, Number(r.precip)) : 0), 0) : null;
    const probability = maxRow(rain24Rows, 'rain')?.rain;
    return `Indikator prakiraan hujan lokal ${place}: ${finite(total24) ? `akumulasi 24 jam sekitar ${n(total24, 1)} mm` : 'akumulasi 24 jam belum tersedia'}; ${finite(probability) ? `peluang hujan maksimum ${pct(probability)}` : 'peluang hujan belum tersedia'}. Ini bukan prediksi banjir atau genangan. Risiko banjir memerlukan informasi drainase, elevasi, aliran sungai, kondisi tanah, dan riwayat genangan. Hindari menerobos genangan dan ikuti peringatan BPBD/BMKG.`;
  }
  if (intent === 'drought') {
    if (!days.length) return 'Prakiraan harian belum tersedia, sehingga kecenderungan hujan beberapa hari ke depan belum bisa diringkas.';
    const total = days.every(d => finite(d.rain)) ? days.reduce((s, d) => s + Number(d.rain), 0) : null;
    return `Untuk ${place}, akumulasi hujan prakiraan hari ini + 15 hari ${finite(total) ? `sekitar ${n(total, 1)} mm` : 'belum lengkap karena sebagian data curah hujan tidak tersedia'}. ${finite(total) && total < 10 ? 'Model menunjukkan kecenderungan hujan rendah selama periode ini.' : finite(total) && total >= 50 ? 'Ada potensi hujan cukup berarti pada periode ini.' : 'Belum cukup untuk menyimpulkan kondisi kekeringan.'} Ini bukan penetapan status kekeringan; kelembapan tanah, kebutuhan air, dan data hujan historis tetap diperlukan.`;
  }
  if (intent === 'agriculture') {
    if (!rows.length) return `Data prakiraan per jam untuk ${place} belum tersedia. Untuk menentukan waktu penyiraman dengan lebih baik, perbarui data dan periksa kelembapan tanah di lapangan.`;
    const peak = maxRow(rows, 'rain'), total = rows.some(r => finite(r.precip)) ? rows.reduce((s, r) => s + (finite(r.precip) ? Number(r.precip) : 0), 0) : null;
    const advice = finite(peak?.rain) && peak.rain >= 60 ? 'Tunda penyiraman menjelang slot dengan peluang hujan tinggi, lalu periksa kelembapan tanah setelah hujan.' : finite(total) && total >= 5 ? 'Hujan terukur dalam prakiraan berpotensi membantu kebutuhan air; cek kelembapan tanah sebelum menambah irigasi.' : 'Belum terlihat hujan yang cukup meyakinkan untuk menggantikan irigasi. Periksa kelembapan tanah dan fase tanaman sebelum menyiram.';
    return `Saran pertanian untuk ${place} pada ${period}: ${advice} ${finite(total) ? `Akumulasi hujan dari slot yang tersedia sekitar ${n(total, 1)} mm.` : 'Akumulasi hujan belum tersedia.'} Kebutuhan air sebenarnya bergantung pada jenis tanaman, fase pertumbuhan, tekstur tanah, dan efisiensi irigasi.`;
  }
  if (intent === 'wind') {
    if (!rows.length) return `Data angin untuk ${period} di ${place} belum tersedia.`;
    const hi = maxRow(rows, 'wind');
    return hi ? `Kecepatan angin maksimum pada ${period} di ${place} sekitar ${kmh(hi.wind)} pada ${dateTimeLabel(hi)}${finite(hi.gust) ? `, dengan hembusan hingga ${kmh(hi.gust)}` : ''}${current.windDir ? `. Arah angin saat ini ${/\b(utara|timur|selatan|barat)\b/i.test(current.windDir) ? current.windDir : compassFromDegrees(current.windDirDeg)}` : ''}. ${Number(hi.wind) >= 30 || (finite(hi.gust) && Number(hi.gust) >= 45) ? 'Angin dan/atau hembusan cukup kuat untuk aktivitas luar; waspadai benda ringan, berkendara, dan area terbuka.' : 'Kecepatan angin dari data ini relatif tidak terlalu tinggi.'}` : 'Slot prakiraan saat ini tidak memuat kecepatan angin yang valid.';
  }
  if (intent === 'unknown') return 'Saya adalah tanyafikricuaca, asisten cuaca Fikri Weather. Saya dapat membantu prakiraan per jam/hari, hujan, suhu, suhu terasa, kelembapan, titik embun, tekanan, angin dan arahnya, tutupan awan, jarak pandang, UV, aktivitas luar ruang, pertanian, kemarau, banjir berbasis indikator hujan, serta penjelasan meteorologi seperti ENSO, MJO, monsun, Rossby, awan, inversi, dan lapse rate. Untuk status gunung, gunakan menu Cuaca Gunung agar merujuk PVMBG. Saya tetap berfokus pada cuaca dan tidak akan mengarang data yang tidak termuat.';
  if (!rows.length) return `Data cuaca untuk ${place} belum tersedia pada pertanyaan ini. Perbarui data prakiraan terlebih dahulu; saya tidak akan menebak kondisi atau angka.`;
  return `Untuk ${place} pada ${period}: ${selectedRainSummary(rows)} ${minTemp && maxTemp ? `Suhu sekitar ${celsius(minTemp.temp)}–${celsius(maxTemp.temp)}.` : ''} ${rainTotal === null ? 'Curah hujan belum tersedia.' : `Akumulasi curah hujan sekitar ${n(rainTotal, 1)} mm.`}`;
}

exports._test = { normalize, answerQuestion, classify, filterHours, resolveFollowUp, cleanContext, weatherConditionFromCode, cleanCondition, compassFromDegrees, nearestRow };
exports.handler = async event => {
  if (event.httpMethod === 'OPTIONS') return { statusCode: 204, headers: { 'Access-Control-Allow-Methods': 'POST,OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type' }, body: '' };
  if (event.httpMethod !== 'POST') return response(405, { ok: false, error: 'Metode tidak didukung.' });
  const ip = String(event.headers?.['x-nf-client-connection-ip'] || event.headers?.['x-forwarded-for'] || 'unknown').split(',')[0].trim();
  const now = Date.now(), prior = recentRequests.get(ip) || [], active = prior.filter(t => now - t < WINDOW_MS);
  if (active.length >= MAX_PER_WINDOW) return response(429, { ok: false, error: 'Pertanyaan terlalu sering dikirim. Coba lagi sebentar.' });
  active.push(now); recentRequests.set(ip, active);
  if (recentRequests.size > 2000) for (const [key, times] of recentRequests) if (!times.some(t => now - t < WINDOW_MS)) recentRequests.delete(key);
  let body;
  try { body = event.body ? JSON.parse(event.body) : {}; } catch { return response(400, { ok: false, error: 'Format pertanyaan tidak valid.' }); }
  const question = textOnly(body.question, 2500);
  if (!question) return response(400, { ok: false, error: 'Tuliskan pertanyaan terlebih dahulu.' });
  const context = cleanContext(body.context);
  const history = Array.isArray(body.history) ? body.history.slice(-10).map(x => ({ role: x?.role === 'user' ? 'user' : 'assistant', content: textOnly(x?.content, 1000) })) : [];
  const answer = answerQuestion(question, context, history);
  return response(200, { ok: true, answer, mode: 'deterministic-nlp-rule-engine', provider: 'local-weather-knowledge-base', dataAvailable: context.hourly.length > 0 || context.daily.length > 0 });
};
