'use strict';

const CACHE = new Map();
const CACHE_TTL = 10 * 60 * 1000;
const clean = value => String(value || '').replace(/[<>\u0000-\u001f]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 140);
const norm = value => String(value || '').toLocaleLowerCase('id-ID').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]+/g, ' ').trim();
const json = (statusCode, body, cache = 'public, max-age=300, stale-while-revalidate=600') => ({
  statusCode,
  headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': cache, 'Access-Control-Allow-Origin': '*', 'X-Content-Type-Options': 'nosniff' },
  body: JSON.stringify(body)
});
function decodeXml(value) {
  return String(value || '').replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;|&apos;/g, "'").replace(/&#(\d+);/g, (_, n) => String.fromCodePoint(Number(n))).replace(/&#x([0-9a-f]+);/gi, (_, n) => String.fromCodePoint(parseInt(n, 16)));
}
function tag(item, name) {
  const match = item.match(new RegExp(`<${name}(?:\\s[^>]*)?>([\\s\\S]*?)<\\/${name}>`, 'i'));
  return match ? decodeXml(match[1]).replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim() : '';
}
function sourceInfo(item) {
  const match = item.match(/<source\b([^>]*)>([\s\S]*?)<\/source>/i);
  if (!match) return { name: 'Sumber berita tidak tercantum', url: null };
  const url = (match[1].match(/\burl=["']([^"']+)["']/i) || [])[1] || null;
  return { name: clean(decodeXml(match[2]).replace(/<[^>]*>/g, ' ')) || 'Sumber tidak tercantum', url: url && /^https?:\/\//i.test(url) ? url : null };
}
function parseFeed(xml, category) {
  const rows = [];
  for (const item of String(xml || '').match(/<item\b[\s\S]*?<\/item>/gi) || []) {
    const title = clean(tag(item, 'title'));
    const link = tag(item, 'link') || ((item.match(/<link\b[^>]*href=["']([^"']+)["']/i) || [])[1] || '');
    const description = clean(tag(item, 'description').replace(/https?:\/\/\S+/g, '').slice(0, 260));
    const pubDate = tag(item, 'pubDate');
    const publishedAt = pubDate && Number.isFinite(Date.parse(pubDate)) ? new Date(pubDate).toISOString() : null;
    const source = sourceInfo(item);
    const mediaTag = item.match(/<(?:media:content|media:thumbnail|enclosure)\b([^>]*)>/i);
    const imageRaw = mediaTag ? ((mediaTag[1].match(/\burl=["']([^"']+)["']/i) || [])[1] || '') : '';
    const image = /^https:\/\//i.test(imageRaw) ? imageRaw : null;
    if (!title || !/^https?:\/\//i.test(link)) continue;
    let domain = null;
    try { domain = new URL(source.url || link).hostname.replace(/^www\./, ''); } catch {}
    const official = !!domain && /(^|\.)(bmkg\.go\.id|bnpb\.go\.id|bpbd\.[a-z0-9.-]+|esdm\.go\.id|magma\.esdm\.go\.id|pvmbg\.esdm\.go\.id|ksdae\.menlhk\.go\.id)$/i.test(domain);
    rows.push({ id: `${category}-${Buffer.from(title).toString('base64url').slice(0, 20)}`, title, summary: description || 'Ringkasan singkat tidak disediakan oleh feed; buka berita asli untuk membaca isi lengkap.', url: link, image, publishedAt, publisher: source.name, publisherUrl: source.url, domain, category, official, source: 'Google News RSS · agregasi hasil berita' });
  }
  return rows;
}
function queries(category, region, search) {
  const suffix = [region, search].filter(Boolean).join(' ');
  const base = {
    cuaca: 'cuaca Indonesia BMKG cuaca ekstrem hujan lebat angin kencang gelombang tinggi',
    bencana: 'bencana Indonesia BNPB banjir longsor gempa kebakaran hutan',
    gunung: 'gunung Indonesia PVMBG aktivitas gunung api erupsi jalur pendakian',
  };
  const categories = category === 'semua' ? ['cuaca', 'bencana', 'gunung'] : [category];
  const results = [];
  for (const key of categories) {
    if (key === 'gunung' && category === 'gunung') {
      results.push(
        { category: key, query: `PVMBG MAGMA aktivitas status gunung api level siaga waspada awas erupsi ${suffix}`.trim() },
        { category: key, query: `jalur pendakian gunung dibuka ditutup kondisi jalur basecamp longsor banjir ${suffix}`.trim() },
        { category: key, query: `berita pendakian gunung kecelakaan cuaca ekstrem evakuasi kawasan konservasi ${suffix}`.trim() }
      );
    } else {
      results.push({ category: key, query: `${base[key]} ${suffix}`.trim() });
    }
  }
  return results;
}
async function fetchFeed(query, category) {
  const url = new URL('https://news.google.com/rss/search');
  url.search = new URLSearchParams({ q: query, hl: 'id', gl: 'ID', ceid: 'ID:id' }).toString();
  const response = await fetch(url, { headers: { Accept: 'application/rss+xml, application/xml, text/xml', 'User-Agent': 'FikriWeather/4.0 (weather and disaster news)' }, signal: AbortSignal.timeout(7500) });
  if (!response.ok) throw new Error(`RSS HTTP ${response.status}`);
  return parseFeed(await response.text(), category);
}
exports._test = { decodeXml, parseFeed, queries, norm };
exports.handler = async event => {
  const q = event.queryStringParameters || {};
  const category = String(q.category || 'semua').toLowerCase();
  if (!['semua', 'cuaca', 'bencana', 'gunung'].includes(category)) return json(400, { ok: false, error: 'Kategori berita tidak dikenali.' }, 'no-store');
  const region = clean(q.region);
  const search = clean(q.q);
  const limit = Math.max(3, Math.min(30, Number.parseInt(q.limit || '18', 10) || 18));
  const key = `${category}|${norm(region)}|${norm(search)}|${limit}`;
  const cached = CACHE.get(key);
  if (cached && Date.now() - cached.at < CACHE_TTL) return json(200, cached.value);
  const feedQueries = queries(category, region, search);
  const settled = await Promise.allSettled(feedQueries.map(item => fetchFeed(item.query, item.category)));
  const feeds = settled.map((result, index) => result.status === 'fulfilled'
    ? { category: feedQueries[index].category, ok: true, count: result.value.length }
    : { category: feedQueries[index].category, ok: false, error: String(result.reason?.message || 'Feed tidak berhasil diakses') });
  const all = settled.flatMap(result => result.status === 'fulfilled' ? result.value : []);
  const seen = new Set();
  const unique = all.filter(item => {
    const key = norm(item.title);
    if (!key || seen.has(key)) return false;
    seen.add(key); return true;
  }).filter(item => {
    if (!item.publishedAt) return true;
    const age = Date.now() - Date.parse(item.publishedAt);
    return age >= -6 * 60 * 60 * 1000 && age <= 45 * 24 * 60 * 60 * 1000;
  }).sort((a, b) => (Date.parse(b.publishedAt || '') || 0) - (Date.parse(a.publishedAt || '') || 0)).slice(0, limit);
  const value = { ok: feeds.some(feed => feed.ok), category, region: region || null, query: search || null, articles: unique, count: unique.length, feeds, fetchedAt: new Date().toISOString(), source: 'Google News RSS; setiap item mencantumkan penerbit dan tautan artikel. Feed agregator bukan pengganti pengumuman resmi instansi.' };
  if (feeds.some(feed => feed.ok)) { CACHE.set(key, { at: Date.now(), value }); if (CACHE.size > 200) CACHE.delete(CACHE.keys().next().value); }
  return json(feeds.some(feed => feed.ok) ? 200 : 502, value, feeds.some(feed => feed.ok) ? 'public, max-age=300, stale-while-revalidate=600' : 'no-store');
};
