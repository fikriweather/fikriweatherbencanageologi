 'use strict';
exports.handler=async event=>{
 const q=event.queryStringParameters||{},type=String(q.type||'').toLowerCase(),ids=String(q.ids||'').toUpperCase().split(',').map(x=>x.trim()).filter(Boolean);
 const h={'Content-Type':'application/json; charset=utf-8','Cache-Control':'public, max-age=120, stale-while-revalidate=60','Access-Control-Allow-Origin':'*','X-Content-Type-Options':'nosniff'};
 if(!['metar','taf'].includes(type)||!ids.length||ids.length>10||ids.some(x=>!/^[A-Z0-9]{4}$/.test(x)))return{statusCode:400,headers:h,body:JSON.stringify({error:'Permintaan METAR/TAF tidak valid.'})};
 try{const u=`https://aviationweather.gov/api/data/${type}?ids=${encodeURIComponent(ids.join(','))}&format=json`;const r=await fetch(u,{headers:{'User-Agent':'FikriWeather/2.0 (weather dashboard)','Accept':'application/json'}});const body=await r.text();if(r.status===204)return{statusCode:200,headers:h,body:'[]'};if(!r.ok)return{statusCode:r.status,headers:h,body:JSON.stringify({error:'AviationWeather.gov tidak dapat diakses.',status:r.status,detail:body.slice(0,180)})};JSON.parse(body);return{statusCode:200,headers:h,body};}catch(e){return{statusCode:502,headers:h,body:JSON.stringify({error:'Feed METAR/TAF gagal diambil.',detail:e.message})}}
};
