 'use strict';
const {db,addNotification}=require('./lib/fw-server.cjs');
exports.config={schedule:'*/10 * * * *'};
const localParts=()=>{const p=new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Jakarta',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).formatToParts(new Date());return Object.fromEntries(p.map(x=>[x.type,x.value]));};
const displayWeatherCondition=value=>/\bgerimis\b|\bdrizzle\b/i.test(String(value||''))?'Mendung':String(value||'').trim();
const keyForQuake=x=>[x?.Tanggal,x?.Jam,x?.Magnitude,x?.Lintang,x?.Bujur].join('|');
async function getState(userId,category){const r=await db('user_notification_state',{query:`select=state_key&user_id=eq.${encodeURIComponent(userId)}&category=eq.${encodeURIComponent(category)}&limit=1`});return r?.[0]?.state_key||'';}
async function setState(userId,category,stateKey){await db('user_notification_state',{method:'POST',query:'on_conflict=user_id,category',body:{user_id:userId,category,state_key:stateKey,last_sent_at:new Date().toISOString()},prefer:'resolution=merge-duplicates,return=minimal'});}
exports.handler=async()=>{const now=localParts();let users=await db('user_preferences',{query:'select=user_id,notification_settings,location&order=updated_at.desc&limit=500'});users=users||[];const summary={checked:users.length,quakeNotices:0,rainNotices:0,forecastNotices:0,failures:0};
 let quake=null;try{const r=await fetch('https://data.bmkg.go.id/DataMKG/TEWS/autogempa.json');if(r.ok)quake=(await r.json())?.Infogempa?.gempa||null;}catch{summary.failures++}
 for(const u of users){const n=u.notification_settings||{},id=u.user_id;try{
  if(n.quake&&quake){const key=keyForQuake(quake);if(key&&key!=='||||'&&key!==await getState(id,'quake')){await addNotification(id,'quake','Gempa bumi terbaru BMKG',`M ${quake.Magnitude||'—'} · ${quake.Wilayah||'wilayah tidak tercantum'} · ${quake.Tanggal||''} ${quake.Jam||''}. Ikuti informasi resmi BMKG.`,'/#earthquake');await setState(id,'quake',key);summary.quakeNotices++;}}
  const wantsWeather=n.rain||n.forecast5h||n.today||n.tomorrow;if(!wantsWeather)continue;
  if(!u.location||!Number.isFinite(Number(u.location.lat))||!Number.isFinite(Number(u.location.lon)))continue;
  const adm4=u.location.adm4;let hourly=null,daily=null,dailySource='BMKG',source='';
  if(adm4&&/^\d{2}\.\d{2}\.\d{2}\.\d{4}$/.test(adm4)){
    try{const r=await fetch(`https://api.bmkg.go.id/publik/prakiraan-cuaca?adm4=${encodeURIComponent(adm4)}`);if(r.ok){const d=await r.json(),flat=(d.data||[]).flatMap(v=>v.cuaca||[]).flat();const next=flat.filter(x=>x.local_datetime).sort((a,b)=>a.local_datetime.localeCompare(b.local_datetime));hourly=next;source='BMKG';
      const byDay=new Map();for(const x of next){const day=String(x.local_datetime||'').slice(0,10);if(!day)continue;const a=byDay.get(day)||{time:day,lo:Infinity,hi:-Infinity,conditions:[],rain:null,rainDesc:false};const temp=Number(x.t);if(Number.isFinite(temp)){a.lo=Math.min(a.lo,temp);a.hi=Math.max(a.hi,temp)}if(x.tp!==null&&x.tp!==undefined&&Number.isFinite(Number(x.tp)))a.rain=(a.rain??0)+Number(x.tp);if(x.weather_desc)a.conditions.push(String(x.weather_desc));if(/hujan|gerimis|petir/i.test(String(x.weather_desc||'')))a.rainDesc=true;byDay.set(day,a)}daily=[...byDay.values()].sort((a,b)=>a.time.localeCompare(b.time)).map(a=>({time:a.time,temperature_2m_min:Number.isFinite(a.lo)?a.lo:null,temperature_2m_max:Number.isFinite(a.hi)?a.hi:null,precipitation_probability_max:null,precipitation_sum:a.rain,condition:a.conditions.length?displayWeatherCondition(a.conditions[0]):'Kondisi tidak tercantum'}));}}catch{}
  }
  if(!hourly){const u0=u.location;const url=`https://api.open-meteo.com/v1/forecast?latitude=${encodeURIComponent(u0.lat)}&longitude=${encodeURIComponent(u0.lon)}&timezone=Asia%2FJakarta&forecast_days=2&hourly=precipitation_probability,precipitation,weather_code&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,precipitation_sum`;const r=await fetch(url);if(!r.ok)throw Error('Prakiraan cadangan tidak tersedia');const d=await r.json();hourly=(d.hourly?.time||[]).map((t,i)=>({local_datetime:t.replace('T',' '),tp:d.hourly.precipitation_probability?.[i],rain:d.hourly.precipitation?.[i],weather_code:d.hourly.weather_code?.[i]}));daily=d.daily;dailySource='Open-Meteo';source='Open-Meteo (pelengkap; kode ADM4 BMKG belum tersimpan)';}
  const nowMs=Date.now();const future=hourly.filter(x=>{const t=Date.parse(String(x.local_datetime).replace(' ','T')+'+07:00');return Number.isFinite(t)&&t>=nowMs-3*60*1000&&t<=nowMs+5*60*60*1000});const next5=future;const rainSignal=next5.some(x=>Number(x.tp??x.p??0)>=60||Number(x.rain??x.precipitation??0)>=0.3||/hujan|gerimis|petir/i.test(String(x.weather_desc||'')));
  const wetAt=next5.find(x=>Number(x.tp??x.p??0)>=60||Number(x.rain??x.precipitation??0)>=0.3);const localDay=`${now.year}-${now.month}-${now.day}`;
  if(n.rain&&rainSignal){const rainKey=localDay+'|'+(wetAt?.local_datetime||wetAt?.utc_datetime||'rain');if(rainKey!==await getState(id,'rain')){await addNotification(id,'rain','Potensi hujan di lokasi tersimpan',`Ada sinyal hujan dalam prakiraan lima jam ke depan. Sumber: ${source}. Periksa prakiraan dan radar sebelum beraktivitas.`,'/#forecast');await setState(id,'rain',rainKey);summary.rainNotices++;}}
  if(n.forecast5h&&next5.length){const sig=next5.map(x=>`${x.local_datetime}:${x.tp??x.p??''}:${x.rain??''}:${x.weather_desc??x.weather_code??''}`).join('|');const fk=localDay+'|'+sig;if(fk!==await getState(id,'forecast5h')){await addNotification(id,'forecast5h','Prakiraan lima jam diperbarui',`Prakiraan lima jam untuk ${u.location.place||'lokasi tersimpan'} diperbarui. Sumber: ${source}.`,'/#forecast');await setState(id,'forecast5h',fk);summary.forecastNotices++;}}
  if(daily){
   const rows=Array.isArray(daily)?daily:(daily.time||[]).map((day,i)=>({time:day,precipitation_probability_max:daily.precipitation_probability_max?.[i],temperature_2m_max:daily.temperature_2m_max?.[i],temperature_2m_min:daily.temperature_2m_min?.[i],precipitation_sum:daily.precipitation_sum?.[i]}));
   for(const [cat,idx,label] of [['today',0,'hari ini'],['tomorrow',1,'besok']]){
    if(!n[cat]||!rows[idx]?.time)continue;
    const row=rows[idx],day=row.time,p=row.precipitation_probability_max,hi=row.temperature_2m_max,lo=row.temperature_2m_min,rain=row.precipitation_sum;
    const dk=day+`|${p??''}|${hi??''}|${lo??''}|${rain??''}`;
    if(dk!==await getState(id,cat)&&((cat==='today'&&now.hour==='06')||(cat==='tomorrow'&&now.hour==='18'))){
     const fields=[];if(lo!==null&&lo!==undefined&&hi!==null&&hi!==undefined)fields.push(`suhu ${lo}–${hi}°C`);if(p!==null&&p!==undefined)fields.push(`peluang hujan ${p}%`);if(rain!==null&&rain!==undefined)fields.push(`curah hujan ${rain} mm`);if(row.condition)fields.push(row.condition);
     await addNotification(id,cat,`Prakiraan cuaca ${label}`,`${fields.join(' · ')||'Ringkasan terbaru tersedia'}. Sumber: ${dailySource}.`,'/#forecast');await setState(id,cat,dk);
    }
   }
  }
 }catch(e){summary.failures++;}}
 return{statusCode:200,body:JSON.stringify({ok:true,at:new Date().toISOString(),...summary})};};
