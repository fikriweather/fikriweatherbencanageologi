'use strict';

const CACHE = new Map();
const response = (statusCode, body, cache = 'no-store') => ({
  statusCode,
  headers: {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': cache,
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
    'X-Content-Type-Options': 'nosniff'
  },
  body: JSON.stringify(body)
});
const number = value => value !== null && value !== undefined && value !== '' && Number.isFinite(Number(value)) ? Number(value) : null;
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
const clean = value => String(value || '').trim();

function normalizeAddress(payload) {
  const address = payload?.address || {};
  const locality = [
    address.village || address.hamlet || address.suburb || address.neighbourhood || address.town || address.city_district,
    address.city || address.municipality || address.county || address.state_district,
    address.state
  ].map(clean).filter(Boolean).filter((value, index, values) => values.indexOf(value) === index);
  const road = clean(address.road || address.pedestrian || address.footway || address.path || address.residential);
  const display = clean(payload?.display_name);
  return {
    display,
    road,
    locality: locality.join(', '),
    village: clean(address.village || address.hamlet || address.suburb || address.neighbourhood || address.town),
    city: clean(address.city || address.municipality || address.county || address.state_district),
    province: clean(address.state),
    country: clean(address.country)
  };
}

exports.handler = async event => {
  if (event.httpMethod === 'OPTIONS') return response(204, {});
  if (event.httpMethod && event.httpMethod !== 'POST') return response(405, { ok: false, error: 'Gunakan POST untuk mencari nama wilayah rute.' });
  let body;
  try { body = JSON.parse(event.body || '{}'); }
  catch { return response(400, { ok: false, error: 'Isi permintaan bukan JSON yang valid.' }); }
  const incoming = body?.points;
  if (!Array.isArray(incoming) || incoming.length < 1 || incoming.length > 4) {
    return response(400, { ok: false, error: 'Pencarian alamat rute menerima 1 sampai 4 titik ringkasan.' });
  }
  const points = [];
  for (let i = 0; i < incoming.length; i++) {
    const lat = number(incoming[i]?.lat), lon = number(incoming[i]?.lon);
    if (lat === null || lon === null || lat < -12.5 || lat > 7.5 || lon < 93 || lon > 143) {
      return response(400, { ok: false, error: `Koordinat alamat rute ${i + 1} tidak valid atau berada di luar Indonesia.` });
    }
    points.push({ id: String(incoming[i]?.id || `A${i + 1}`).slice(0, 20), lat, lon });
  }
  const now = Date.now();
  const locations = [];
  let lastRequestAt = 0;
  for (const point of points) {
    const key = `${point.lat.toFixed(4)},${point.lon.toFixed(4)}`;
    const cached = CACHE.get(key);
    if (cached && now - cached.at < 30 * 86400000) {
      locations.push({ id: point.id, ...cached.value, cache: true });
      continue;
    }
    const wait = Math.max(0, 1050 - (Date.now() - lastRequestAt));
    if (wait) await sleep(wait);
    lastRequestAt = Date.now();
    try {
      const url = `https://nominatim.openstreetmap.org/reverse?format=jsonv2&addressdetails=1&zoom=16&lat=${point.lat}&lon=${point.lon}`;
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 1300);
      let payload;
      try {
        const result = await fetch(url, {
          headers: {
            Accept: 'application/json',
            'Accept-Language': 'id',
            'User-Agent': 'FikriWeather/2.4.4 (https://fikriweatherramalanmeteorologi.netlify.app/; route location labels)'
          },
          signal: controller.signal
        });
        if (!result.ok) throw new Error(`Nominatim HTTP ${result.status}`);
        payload = await result.json();
      } finally { clearTimeout(timer); }
      const value = normalizeAddress(payload);
      CACHE.set(key, { at: now, value });
      locations.push({ id: point.id, ...value, cache: false });
    } catch (error) {
      locations.push({ id: point.id, display: '', road: '', locality: '', error: error.message });
    }
  }
  if (CACHE.size > 1500) {
    const oldest = [...CACHE.entries()].sort((a, b) => a[1].at - b[1].at).slice(0, CACHE.size - 1500);
    oldest.forEach(([key]) => CACHE.delete(key));
  }
  return response(200, {
    ok: true,
    locations,
    meta: {
      source: 'OpenStreetMap Nominatim',
      attribution: '© OpenStreetMap contributors',
      note: 'Nama wilayah/alamat adalah hasil reverse geocoding terdekat, bukan alamat rumah atau titik jalan yang dijamin persis.'
    }
  }, 'public, max-age=3600, stale-while-revalidate=86400');
};
