'use strict';

const magma = require('./lib/magma-volcano.cjs');
const json=(statusCode,body,cache='public, max-age=120, stale-while-revalidate=120')=>({statusCode,headers:{'Content-Type':'application/json; charset=utf-8','Cache-Control':cache,'Access-Control-Allow-Origin':'*','X-Content-Type-Options':'nosniff'},body:JSON.stringify(body)});
exports._test={parseMagma:magma.parseMagma,parseRecentActivityReports:magma.parseRecentActivityReports,parseActivityDetail:magma.parseActivityDetail,cleanLevel:magma.cleanLevel};
exports.handler=async event=>{
 const source=String(event.queryStringParameters?.source||'').toLowerCase();
 try{
  if(source==='quake'){
   const r=await fetch('https://data.bmkg.go.id/DataMKG/TEWS/autogempa.json',{headers:{'User-Agent':'FikriWeather/4.0'}});if(!r.ok)throw Error('BMKG HTTP '+r.status);const data=await r.json();return json(200,{source:'BMKG',fetchedAt:new Date().toISOString(),data});
  }
  if(source==='quakes'){
   const urls=[
    {name:'BMKG · daftar M≥5',url:'https://data.bmkg.go.id/DataMKG/TEWS/gempaterkini.json'},
    {name:'BMKG · gempa dirasakan',url:'https://data.bmkg.go.id/DataMKG/TEWS/gempadirasakan.json'},
    {name:'BMKG · gempa terbaru',url:'https://data.bmkg.go.id/DataMKG/TEWS/autogempa.json'}
   ];
   const settled=await Promise.allSettled(urls.map(async item=>{
    const response=await fetch(item.url,{headers:{'User-Agent':'FikriWeather/4.0','Accept':'application/json'},signal:AbortSignal.timeout(9000)});
    if(!response.ok)throw new Error('BMKG HTTP '+response.status);
    return {...item,data:await response.json(),fetchedAt:new Date().toISOString()};
   }));
   const feeds=settled.map((result,index)=>result.status==='fulfilled'
    ?{...result.value,ok:true}
    :{name:urls[index].name,url:urls[index].url,ok:false,error:String(result.reason?.message||'Feed tidak berhasil diakses')});
   if(!feeds.some(feed=>feed.ok))return json(502,{ok:false,source:'BMKG',fetchedAt:new Date().toISOString(),feeds,error:'Seluruh feed gempa BMKG gagal diakses.'},'no-store');
   return json(200,{ok:true,source:'BMKG',fetchedAt:new Date().toISOString(),feeds},'public, max-age=60, stale-while-revalidate=120');
  }
  if(source==='volcano'){
   const status=await magma.getStatus({force:String(event.queryStringParameters?.refresh||'')==='1'});
   const detailName=String(event.queryStringParameters?.detail||'').trim();
   if(detailName){
    const found=magma.findReport(status.reports,detailName);
    if(!found)return json(404,{ok:false,error:`${detailName} tidak tercantum pada daftar tingkat aktivitas PVMBG/MAGMA yang berhasil dibaca.`,source:status.source,fetchedAt:status.fetchedAt,complete:!!status.complete,partial:!!status.partial},'no-store');
    let detail=null;
    try{detail=await magma.getReportDetail(found);}catch(e){detail={detailError:'Rincian laporan belum berhasil dibaca; status resmi pada daftar tetap ditampilkan.',sourceError:String(e.message||e).slice(0,180)};}
    return json(200,{ok:true,source:status.source,sourceUrl:status.sourceUrl,fetchedAt:status.fetchedAt,stale:!!status.stale,report:found,detail,complete:!!status.complete,partial:!!status.partial},'public, max-age=60, stale-while-revalidate=180');
   }
   return json(200,status,'public, max-age=60, stale-while-revalidate=180');
  }
  return json(400,{error:'Sumber tidak dikenal. Gunakan source=quake atau source=volcano.'},'no-store');
 }catch(e){const message=source==='quake'||source==='quakes'?'Feed gempa BMKG belum dapat diakses.':'Sumber resmi PVMBG/MAGMA belum dapat diakses.';return json(502,{ok:false,error:message,detail:e.message,source},'no-store');}
};
