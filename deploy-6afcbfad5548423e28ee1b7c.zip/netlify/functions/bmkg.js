 'use strict';
exports.handler = async event => {
  const adm4 = String(event.queryStringParameters?.adm4 || '');
  const headers = {'Content-Type':'application/json; charset=utf-8','Cache-Control':'public, max-age=600, stale-while-revalidate=300','Access-Control-Allow-Origin':'*','X-Content-Type-Options':'nosniff'};
  if (!/^\d{2}\.\d{2}\.\d{2}\.\d{4}$/.test(adm4)) return {statusCode:400,headers,body:JSON.stringify({error:'Kode ADM4 tidak valid.'})};
  try {
    const r = await fetch('https://api.bmkg.go.id/publik/prakiraan-cuaca?adm4='+encodeURIComponent(adm4), {headers:{'User-Agent':'FikriWeather/2.0 (+https://fikriweather.example)'}});
    const body = await r.text();
    if (!r.ok) return {statusCode:r.status,headers,body:JSON.stringify({error:'BMKG tidak dapat diakses.',status:r.status,detail:body.slice(0,240)})};
    JSON.parse(body);
    return {statusCode:200,headers,body};
  } catch(e) { return {statusCode:502,headers,body:JSON.stringify({error:'Gagal mengambil prakiraan BMKG.',detail:e.message})}; }
};
