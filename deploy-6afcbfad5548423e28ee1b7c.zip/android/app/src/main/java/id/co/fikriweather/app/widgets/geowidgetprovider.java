package id.co.fikriweather.app.widgets;

public final class GeoWidgetProvider extends FikriWidgetProvider {
    @Override protected String kind() { return "geo"; }
    @Override protected String title() { return "FIKRI GEO MONITOR"; }
}
