package id.co.fikriweather.app.widgets;

public final class ComboWidgetProvider extends FikriWidgetProvider {
    @Override protected String kind() { return "combo"; }
    @Override protected String title() { return "FIKRI WEATHER + GEO MONITOR"; }
}
