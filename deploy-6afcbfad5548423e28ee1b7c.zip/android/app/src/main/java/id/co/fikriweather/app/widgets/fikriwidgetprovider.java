package id.co.fikriweather.app.widgets;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.View;
import android.widget.RemoteViews;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import id.co.fikriweather.app.MainActivity;
import id.co.fikriweather.app.R;

public abstract class FikriWidgetProvider extends AppWidgetProvider {
    public static final String ACTION_REFRESH = "id.co.fikriweather.app.widget.REFRESH";
    public static final String ACTION_PREVIOUS = "id.co.fikriweather.app.widget.PREVIOUS";
    public static final String ACTION_NEXT = "id.co.fikriweather.app.widget.NEXT";
    public static final String ACTION_OPEN = "id.co.fikriweather.app.widget.OPEN";
    public static final String EXTRA_FORCE_REFRESH = "force_refresh";
    private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor();

    protected abstract String kind();
    protected abstract String title();
    protected int layoutResource() { return R.layout.widget_fikri_weather; }

    @Override public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        requestUpdate(context, ids, false);
    }

    @Override public void onReceive(Context context, Intent intent) {
        String action = intent == null ? null : intent.getAction();
        if (ACTION_OPEN.equals(action)) {
            Intent open = new Intent(context, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            context.startActivity(open);
            return;
        }
        if (ACTION_REFRESH.equals(action) || ACTION_NEXT.equals(action) || ACTION_PREVIOUS.equals(action)) {
            AppWidgetManager manager = AppWidgetManager.getInstance(context);
            int id = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID);
            if (ACTION_REFRESH.equals(action) && id != AppWidgetManager.INVALID_APPWIDGET_ID) {
                // A manual refresh from any widget refreshes all installed Fikri Weather widgets.
                WidgetRefreshUtil.requestAll(context, true);
                return;
            }
            int[] ids = id == AppWidgetManager.INVALID_APPWIDGET_ID
                    ? manager.getAppWidgetIds(new ComponentName(context, getClass())) : new int[]{id};
            if (ACTION_NEXT.equals(action) || ACTION_PREVIOUS.equals(action)) {
                SharedPreferences prefs = context.getSharedPreferences("fikri_widget_data", Context.MODE_PRIVATE);
                int old = prefs.getInt("page_" + id, 0);
                int next = ACTION_NEXT.equals(action) ? Math.min(8, old + 4) : Math.max(0, old - 4);
                prefs.edit().putInt("page_" + id, next).apply();
                requestUpdate(context, ids, false);
            } else {
                boolean force = intent.getBooleanExtra(EXTRA_FORCE_REFRESH, true);
                requestUpdate(context, ids, force);
            }
            return;
        }
        super.onReceive(context, intent);
    }

    private void requestUpdate(Context context, int[] ids, boolean force) {
        if (ids == null || ids.length == 0) return;
        final int[] safeIds = ids.clone();
        final AppWidgetManager manager = AppWidgetManager.getInstance(context);
        final PendingResult pending = goAsync();
        EXECUTOR.execute(() -> {
            try {
                boolean includeGeo = "geo".equals(kind()) || "combo".equals(kind());
                WidgetSnapshot data = WidgetDataRepository.load(context.getApplicationContext(), force, includeGeo);
                for (int id : safeIds) {
                    try { manager.updateAppWidget(id, buildViews(context, id, data)); }
                    catch (Exception ignored) { }
                }
            } catch (Exception ignored) {
            } finally { pending.finish(); }
        });
    }

    private RemoteViews buildViews(Context context, int widgetId, WidgetSnapshot data) {
        boolean geo = "geo".equals(kind());
        boolean combo = "combo".equals(kind());
        boolean now = "now".equals(kind());
        boolean geoOnly = geo;
        boolean showWeather = !geoOnly;
        boolean showMetrics = !geoOnly && !now;
        boolean showForecast = !geoOnly && !now;
        boolean showGeo = geo || combo;
        RemoteViews views = new RemoteViews(context.getPackageName(), layoutResource());
        views.setInt(R.id.widgetRoot, "setBackgroundResource", geo ? R.drawable.widget_bg_geo : R.drawable.widget_bg_weather);

        views.setTextViewText(R.id.widgetTitle, title());
        views.setTextViewText(R.id.widgetDate, data.date);
        views.setTextViewText(R.id.widgetTime, data.time);
        views.setTextViewText(R.id.currentIcon, data.currentIcon);
        views.setTextViewText(R.id.currentTemp, data.hasWeather ? data.temperature : "—°C");
        views.setTextViewText(R.id.currentCondition, data.condition);
        views.setTextViewText(R.id.currentFeels, data.feelsLike);
        views.setTextViewText(R.id.currentPlace, data.place);
        views.setTextViewText(R.id.widgetSource, sourceText(data, showGeo));

        if (now) {
            views.setTextViewText(R.id.widgetSource, "Sumber: " + data.source + (data.stale ? " · cache terakhir" : ""));
        } else {
            views.setTextViewText(R.id.rainChance, data.rainChance);
            views.setTextViewText(R.id.currentHumidity, data.humidity);
            views.setTextViewText(R.id.currentWind, data.wind);
            views.setTextViewText(R.id.quakeMagnitude, "M " + data.earthquakeMagnitude.replace(" M", ""));
            views.setTextViewText(R.id.quakeText, data.earthquakeText);
            views.setTextViewText(R.id.volcanoName, data.volcanoName);
            views.setTextViewText(R.id.volcanoStatus, data.volcanoStatus);
            views.setTextViewText(R.id.tsunamiStatus, "Tsunami · " + data.tsunamiStatus);
            views.setTextViewText(R.id.floodStatus, "Banjir · " + data.floodStatus);
            views.setTextViewText(R.id.landslideStatus, "Longsor · " + data.landslideStatus);
            applyHazardStyle(views, R.id.tsunamiStatus, data.tsunamiStatus);
            applyHazardStyle(views, R.id.floodStatus, data.floodStatus);
            applyHazardStyle(views, R.id.landslideStatus, data.landslideStatus);
            views.setViewVisibility(R.id.widgetLocationLine, geoOnly ? View.VISIBLE : View.GONE);
            views.setTextViewText(R.id.widgetLocationLine, "Lokasi: " + data.place);
            setVisibility(views, R.id.weatherCurrentGroup, showWeather);
            setVisibility(views, R.id.weatherMetricsGroup, showMetrics);
            setVisibility(views, R.id.forecastGroup, showForecast);
            setVisibility(views, R.id.geoGroup, showGeo);
            setVisibility(views, R.id.hazardGroup, showGeo);
        }

        if (geoOnly) {
            views.setTextViewText(R.id.widgetTitle, "FIKRI GEO MONITOR");
            views.setInt(R.id.quakeCard, "setBackgroundResource", R.drawable.widget_card_warm);
            views.setInt(R.id.volcanoCard, "setBackgroundResource", R.drawable.widget_card_warm);
        }

        if (showForecast) {
            SharedPreferences prefs = context.getSharedPreferences("fikri_widget_data", Context.MODE_PRIVATE);
            int offset = prefs.getInt("page_" + widgetId, 0);
            int total = data.forecast.size();
            int end = Math.min(total, offset + 4);
            views.setTextViewText(R.id.pageLabel, total == 0 ? "— / 10" : (offset + 1) + "–" + end + " / 10");
            int[] timeIds = {R.id.forecastTime0,R.id.forecastTime1,R.id.forecastTime2,R.id.forecastTime3};
            int[] iconIds = {R.id.forecastIcon0,R.id.forecastIcon1,R.id.forecastIcon2,R.id.forecastIcon3};
            int[] tempIds = {R.id.forecastTemp0,R.id.forecastTemp1,R.id.forecastTemp2,R.id.forecastTemp3};
            int[] conditionIds = {R.id.forecastCondition0,R.id.forecastCondition1,R.id.forecastCondition2,R.id.forecastCondition3};
            int[] cardIds = {R.id.forecastCard0,R.id.forecastCard1,R.id.forecastCard2,R.id.forecastCard3};
            for (int i = 0; i < 4; i++) {
                int index = offset + i;
                boolean visible = index < total;
                setVisibility(views, cardIds[i], visible);
                if (!visible) continue;
                WidgetSnapshot.ForecastSlot f = data.forecast.get(index);
                views.setTextViewText(timeIds[i], f.time);
                views.setTextViewText(iconIds[i], f.icon);
                views.setTextViewText(tempIds[i], f.temperature);
                views.setTextViewText(conditionIds[i], shortCondition(f.condition));
            }
            views.setOnClickPendingIntent(R.id.actionPrevious, broadcast(context, widgetId, ACTION_PREVIOUS, 1));
            views.setOnClickPendingIntent(R.id.actionNext, broadcast(context, widgetId, ACTION_NEXT, 2));
        }

        views.setOnClickPendingIntent(R.id.actionRefresh, broadcast(context, widgetId, ACTION_REFRESH, 3));
        views.setOnClickPendingIntent(R.id.actionLocation, openApp(context, widgetId, 4));
        views.setOnClickPendingIntent(R.id.actionDetail, openApp(context, widgetId, 5));
        views.setOnClickPendingIntent(R.id.widgetRoot, openApp(context, widgetId, 6));
        return views;
    }


    private static void applyHazardStyle(RemoteViews views, int viewId, String status) {
        String value = status == null ? "" : status.trim().toUpperCase(java.util.Locale.ROOT);
        int background = R.drawable.widget_badge_neutral;
        int color = android.graphics.Color.rgb(82, 101, 119);
        if (value.startsWith("NORMAL")) {
            background = R.drawable.widget_badge_green;
            color = android.graphics.Color.rgb(23, 107, 67);
        } else if (value.startsWith("BERPOTENSI")) {
            background = R.drawable.widget_badge_yellow;
            color = android.graphics.Color.rgb(133, 97, 11);
        } else if (value.startsWith("SIAGA")) {
            background = R.drawable.widget_badge_orange;
            color = android.graphics.Color.rgb(154, 79, 22);
        } else if (value.startsWith("BAHAYA")) {
            background = R.drawable.widget_badge_red;
            color = android.graphics.Color.rgb(166, 50, 43);
        }
        views.setInt(viewId, "setBackgroundResource", background);
        views.setTextColor(viewId, color);
    }

    private static String sourceText(WidgetSnapshot data, boolean showGeo) {
        if (showGeo) return (data.hasBmkg ? "BMKG" : "BMKG belum tersedia") + " · PVMBG/MAGMA · BNPB/BPBD" + (data.stale ? " · cache terakhir" : "");
        return (data.source == null ? "Sumber belum tersedia" : data.source) + (data.stale ? " · cache terakhir" : "") + " · " + data.updatedAt;
    }

    private static String shortCondition(String value) {
        if (value == null) return "—";
        String s = value.trim();
        if (s.equalsIgnoreCase("Hujan disertai petir")) return "Petir";
        if (s.toLowerCase(java.util.Locale.ROOT).contains("gerimis")) return "Mendung";
        if (s.equalsIgnoreCase("Cerah berawan")) return "Cerah awan";
        if (s.equalsIgnoreCase("Berawan tebal")) return "Mendung";
        return s;
    }

    private static void setVisibility(RemoteViews views, int id, boolean visible) {
        views.setViewVisibility(id, visible ? View.VISIBLE : View.GONE);
    }

    private PendingIntent broadcast(Context context, int widgetId, String action, int code) {
        Intent intent = new Intent(context, getClass()).setAction(action);
        intent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId);
        return PendingIntent.getBroadcast(context, widgetId * 10 + code, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private PendingIntent openApp(Context context, int widgetId, int code) {
        Intent intent = new Intent(context, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        return PendingIntent.getActivity(context, widgetId * 10 + code, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
}
