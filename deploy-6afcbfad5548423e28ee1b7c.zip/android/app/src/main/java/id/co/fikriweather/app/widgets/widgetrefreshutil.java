package id.co.fikriweather.app.widgets;

import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;

public final class WidgetRefreshUtil {
    private WidgetRefreshUtil() {}
    public static void requestAll(Context context, boolean force) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        Class<?>[] providers = new Class<?>[] { WeatherWidgetProvider.class, GeoWidgetProvider.class, ComboWidgetProvider.class, NowWidgetProvider.class };
        boolean forceNext = force;
        for (Class<?> provider : providers) {
            int[] ids = manager.getAppWidgetIds(new ComponentName(context, provider));
            if (ids.length == 0) continue;
            try {
                Intent intent = new Intent(context, provider).setAction(FikriWidgetProvider.ACTION_REFRESH);
                // Only the first installed widget forces the network request. The remaining
                // widgets consume the same freshly cached snapshot instead of duplicating calls.
                intent.putExtra(FikriWidgetProvider.EXTRA_FORCE_REFRESH, forceNext);
                forceNext = false;
                context.sendBroadcast(intent);
            } catch (Exception ignored) { }
        }
    }
}
