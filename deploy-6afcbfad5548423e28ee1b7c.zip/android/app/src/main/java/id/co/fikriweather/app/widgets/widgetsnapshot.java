package id.co.fikriweather.app.widgets;

import java.util.ArrayList;
import java.util.List;

public final class WidgetSnapshot {
    public String place = "Lokasi belum dipilih";
    public String date = "—";
    public String time = "—";
    public String temperature = "—";
    public String condition = "DATA BELUM TERSEDIA";
    public String feelsLike = "Terasa —";
    public String humidity = "—";
    public String wind = "—";
    public String rainChance = "—";
    public String source = "Sumber belum tersedia";
    public String updatedAt = "Belum diperbarui";
    public String currentIcon = "🌤️";
    public String earthquakeMagnitude = "—";
    public String earthquakeText = "DATA BELUM TERSEDIA";
    public String volcanoName = "DATA BELUM TERSEDIA";
    public String volcanoStatus = "Status resmi belum tersedia";
    public String tsunamiStatus = "DATA BELUM TERSEDIA";
    public String floodStatus = "DATA BELUM TERSEDIA";
    public String landslideStatus = "DATA BELUM TERSEDIA";
    public boolean hasWeather;
    public boolean hasBmkg;
    public boolean hasGeo;
    public boolean stale;
    public final List<ForecastSlot> forecast = new ArrayList<>();

    public static final class ForecastSlot {
        public String time = "—";
        public String temperature = "—";
        public String condition = "Data belum tersedia";
        public String icon = "—";
        public String source = "—";
    }
}
