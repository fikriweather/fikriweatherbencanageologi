package id.co.fikriweather.app.widgets;

import android.content.Context;
import android.content.SharedPreferences;
import android.webkit.JavascriptInterface;

/** Receives only a user-selected/current device location from the trusted Fikri Weather WebView. */
public final class WidgetLocationBridge {
    private final Context appContext;
    public WidgetLocationBridge(Context context) { appContext = context.getApplicationContext(); }

    @JavascriptInterface
    public void saveLocation(double latitude, double longitude, String place, String adm4, String mode) {
        if (!Double.isFinite(latitude) || !Double.isFinite(longitude) || Math.abs(latitude) > 90 || Math.abs(longitude) > 180) return;
        SharedPreferences.Editor editor = appContext.getSharedPreferences("fikri_widget_data", Context.MODE_PRIVATE).edit();
        editor.remove("snapshot_json").remove("snapshot_at").remove("snapshot_location_key");
        editor.putLong("lat", Double.doubleToLongBits(latitude));
        editor.putLong("lon", Double.doubleToLongBits(longitude));
        if (place != null && !place.trim().isEmpty()) editor.putString("place", place.trim());
        editor.putString("location_mode", "gps".equalsIgnoreCase(mode) ? "gps" : "manual");
        if (adm4 != null && adm4.matches("\\d{2}\\.\\d{2}\\.\\d{2}\\.\\d{4}")) editor.putString("adm4", adm4);
        else editor.remove("adm4");
        editor.apply();
        WidgetDataRepository.invalidate();
        WidgetRefreshUtil.requestAll(appContext, false);
    }
}
