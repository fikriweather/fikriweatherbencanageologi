package id.co.fikriweather.app.widgets;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Build;
import android.text.TextUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.text.ParseException;
import java.util.Calendar;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

import id.co.fikriweather.app.BuildConfig;

/** One shared, short-lived cache for all launcher widgets. BMKG slots always outrank model slots. */
public final class WidgetDataRepository {
    private static final String PREFS = "fikri_widget_data";
    private static final String CACHE_KEY = "snapshot_json";
    private static final String CACHE_TIME = "snapshot_at";
    private static final long CACHE_TTL_MS = 10 * 60 * 1000L;
    private static final Object LOCK = new Object();
    private static volatile WidgetSnapshot memoryCache;
    private static volatile long memoryCacheAt;

    private WidgetDataRepository() {}

    public static void invalidate() { synchronized (LOCK) { memoryCache = null; memoryCacheAt = 0L; } }

    public static WidgetSnapshot load(Context context, boolean force, boolean withGeo) {
        synchronized (LOCK) {
            long now = System.currentTimeMillis();
            SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            LocationInfo activeLocation = location(context);
            String activeLocationKey = locationKey(activeLocation);
            String cachedLocationKey = prefs.getString("snapshot_location_key", "");
            // A widget cache is valid only for the coordinates that produced it. This check
            // runs before the memory cache is consulted so a GPS move cannot show old-place data.
            if (!TextUtils.equals(activeLocationKey, cachedLocationKey)) {
                prefs.edit().remove(CACHE_KEY).remove(CACHE_TIME).remove("snapshot_location_key").apply();
                memoryCache = null;
                memoryCacheAt = 0L;
            }
            if (!force && memoryCache != null && now - memoryCacheAt < CACHE_TTL_MS) {
                if (withGeo) attachGeoIfNeeded(context, memoryCache);
                return memoryCache;
            }
            if (!force) {
                String saved = prefs.getString(CACHE_KEY, null);
                long savedAt = prefs.getLong(CACHE_TIME, 0L);
                if (saved != null && now - savedAt < CACHE_TTL_MS) {
                    try {
                        memoryCache = fromJson(new JSONObject(saved));
                        memoryCacheAt = savedAt;
                        if (withGeo) attachGeoIfNeeded(context, memoryCache);
                        return memoryCache;
                    } catch (Exception ignored) { }
                }
            }
            WidgetSnapshot previous = readSaved(context);
            try {
                WidgetSnapshot fresh = fetch(context, withGeo);
                if (fresh.hasWeather || fresh.hasGeo) {
                    fresh.stale = false;
                    JSONObject json = toJson(fresh);
                    prefs.edit().putString(CACHE_KEY, json.toString())
                            .putLong(CACHE_TIME, now)
                            .putString("snapshot_location_key", activeLocationKey)
                            .apply();
                    memoryCache = fresh;
                    memoryCacheAt = now;
                    return fresh;
                }
                throw new IllegalStateException("Sumber tidak mengembalikan data yang dapat digunakan.");
            } catch (Exception error) {
                // Never fall back to a cached snapshot belonging to a different location.
                if (previous != null && TextUtils.equals(activeLocationKey, cachedLocationKey)) {
                    previous.stale = true;
                    previous.updatedAt = "Data tersimpan · pembaruan gagal";
                    memoryCache = previous;
                    memoryCacheAt = now;
                    return previous;
                }
                WidgetSnapshot unavailable = new WidgetSnapshot();
                stampClock(unavailable);
                if (activeLocation != null) unavailable.place = activeLocation.place;
                unavailable.updatedAt = "Tidak dapat mengambil data";
                unavailable.source = "BMKG/model tidak terjangkau";
                memoryCache = unavailable;
                memoryCacheAt = now;
                return unavailable;
            }
        }
    }

    private static String locationKey(LocationInfo location) {
        if (location == null) return "";
        return String.format(Locale.US, "%.3f,%.3f", location.latitude, location.longitude);
    }

    private static WidgetSnapshot readSaved(Context context) {
        try {
            String raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(CACHE_KEY, null);
            return raw == null ? null : fromJson(new JSONObject(raw));
        } catch (Exception ignored) { return null; }
    }

    private static WidgetSnapshot fetch(Context context, boolean withGeo) throws Exception {
        WidgetSnapshot out = new WidgetSnapshot();
        stampClock(out);
        LocationInfo loc = location(context);
        if (loc == null) {
            out.place = "Aktifkan/pilih lokasi di aplikasi";
            out.updatedAt = "Lokasi belum tersedia";
            return out;
        }
        out.place = loc.place;

        JSONObject bmkg = null;
        String adm4 = loc.adm4;
        if (TextUtils.isEmpty(adm4)) {
            try {
                JSONObject resolved = requestJson(siteUrl("/.netlify/functions/adm4?lat=" + enc(loc.lat) + "&lon=" + enc(loc.lon)), 4500);
                adm4 = resolved.optString("adm4", "");
                String village = joinNonEmpty(resolved.optString("village"), resolved.optString("district"), resolved.optString("regency"));
                if (!TextUtils.isEmpty(village)) out.place = village;
                if (!TextUtils.isEmpty(adm4)) {
                    context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("adm4", adm4).putString("place", out.place).apply();
                }
            } catch (Exception ignored) { }
        }
        if (!TextUtils.isEmpty(adm4)) {
            try { bmkg = requestJson(siteUrl("/.netlify/functions/bmkg?adm4=" + enc(adm4)), 5500); }
            catch (Exception ignored) { }
        }

        JSONObject model = null;
        String modelUrl = "https://api.open-meteo.com/v1/forecast?latitude=" + enc(loc.lat)
                + "&longitude=" + enc(loc.lon)
                + "&timezone=auto&forecast_days=4"
                + "&current=temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,weather_code,wind_speed_10m"
                + "&hourly=temperature_2m,relative_humidity_2m,apparent_temperature,precipitation_probability,precipitation,weather_code,wind_speed_10m"
                + "&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,precipitation_sum";
        try { model = requestJson(modelUrl, 6500); } catch (Exception ignored) { }

        List<BmkgSlot> bmkgSlots = parseBmkg(bmkg);
        JSONObject currentModel = model == null ? new JSONObject() : model.optJSONObject("current");
        JSONObject hourly = model == null ? new JSONObject() : model.optJSONObject("hourly");
        long now = System.currentTimeMillis();
        BmkgSlot currentBmkg = closestBmkg(bmkgSlots, now);
        boolean useBmkg = currentBmkg != null && Math.abs(currentBmkg.epochMs - now) <= 90 * 60 * 1000L;

        Double modelTemp = num(currentModel == null ? null : currentModel.opt("temperature_2m"));
        Double modelHum = num(currentModel == null ? null : currentModel.opt("relative_humidity_2m"));
        Double modelFeels = num(currentModel == null ? null : currentModel.opt("apparent_temperature"));
        Double modelWind = num(currentModel == null ? null : currentModel.opt("wind_speed_10m"));
        Double modelRain = nearestHourlyNumber(hourly, "precipitation_probability", now);
        int modelCode = nearestHourlyInt(hourly, "weather_code", now, weatherCode(currentModel == null ? null : currentModel.opt("weather_code")));

        if (useBmkg) {
            out.temperature = display(currentBmkg.temp != null ? currentBmkg.temp : modelTemp, "°C");
            out.condition = !TextUtils.isEmpty(currentBmkg.condition) ? displayWeatherCondition(currentBmkg.condition) : weatherText(modelCode);
            out.humidity = display(currentBmkg.humidity != null ? currentBmkg.humidity : modelHum, "%");
            out.wind = display(currentBmkg.wind != null ? currentBmkg.wind : modelWind, " km/j");
            out.currentIcon = weatherIcon(out.condition, modelCode);
            out.hasBmkg = true;
            out.source = "BMKG · peluang hujan dari model pelengkap";
        } else if (model != null) {
            out.temperature = display(modelTemp, "°C");
            out.condition = weatherText(modelCode);
            out.humidity = display(modelHum, "%");
            out.wind = display(modelWind, " km/j");
            out.currentIcon = weatherIcon(out.condition, modelCode);
            out.source = "Model pelengkap · BMKG tidak menyediakan slot saat ini";
        }
        out.feelsLike = "Terasa " + display(modelFeels, "°C");
        out.rainChance = display(modelRain, "%");
        out.hasWeather = model != null || useBmkg;

        // Build the 10-hour strip. Use only exact BMKG slots (within 20 minutes); model hours fill the official 3-hour gaps.
        for (int i = 0; i < 10; i++) {
            long target = nextHourEpoch(now, i);
            BmkgSlot bm = closestBmkg(bmkgSlots, target);
            WidgetSnapshot.ForecastSlot slot = new WidgetSnapshot.ForecastSlot();
            boolean bmkgMatch = bm != null && Math.abs(bm.epochMs - target) <= 20 * 60 * 1000L;
            if (bmkgMatch) {
                slot.time = formatTime(bm.epochMs);
                slot.temperature = display(bm.temp, "°");
                slot.condition = !TextUtils.isEmpty(bm.condition) ? displayWeatherCondition(bm.condition) : "Kondisi belum tersedia";
                slot.icon = weatherIcon(slot.condition, 0);
                slot.source = "BMKG";
            } else {
                int ix = nearestHourlyIndex(hourly, target);
                if (ix >= 0) {
                    slot.time = formatTime(target);
                    slot.temperature = display(arrayNum(hourly, "temperature_2m", ix), "°");
                    int code = arrayInt(hourly, "weather_code", ix, 0);
                    slot.condition = weatherText(code);
                    slot.icon = weatherIcon(slot.condition, code);
                    slot.source = "Model pelengkap";
                } else {
                    slot.time = formatTime(target);
                    slot.condition = "DATA BELUM TERSEDIA";
                    slot.source = "Tidak tersedia";
                }
            }
            out.forecast.add(slot);
        }

        // Geo is fetched only for the GEO and combined widgets to avoid needless network work.
        if (withGeo) { try { loadGeo(context, out, loc); context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putLong("geo_attempt_at", System.currentTimeMillis()).apply(); } catch (Exception ignored) { } }
        stampClock(out);
        return out;
    }

    private static void stampClock(WidgetSnapshot out) {
        Date now = new Date();
        out.date = new SimpleDateFormat("EEEE, d MMMM yyyy", new Locale("id", "ID")).format(now);
        out.time = new SimpleDateFormat("HH:mm z", new Locale("id", "ID")).format(now);
        out.updatedAt = "Diperbarui " + new SimpleDateFormat("HH:mm", new Locale("id", "ID")).format(now);
    }

    private static void attachGeoIfNeeded(Context context, WidgetSnapshot snapshot) {
        if (snapshot == null || snapshot.hasGeo) return;
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        long attempted = prefs.getLong("geo_attempt_at", 0L);
        if (System.currentTimeMillis() - attempted < CACHE_TTL_MS) return;
        LocationInfo loc = location(context); if (loc == null) return;
        try {
            loadGeo(context, snapshot, loc);
            prefs.edit().putLong("geo_attempt_at", System.currentTimeMillis()).putString(CACHE_KEY, toJson(snapshot).toString()).apply();
            memoryCache = snapshot;
        } catch (Exception ignored) { prefs.edit().putLong("geo_attempt_at", System.currentTimeMillis()).apply(); }
    }

    private static void loadGeo(Context context, WidgetSnapshot out, LocationInfo loc) throws Exception {
        JSONObject quakeEnvelope = requestJson(siteUrl("/.netlify/functions/public-data?source=quake"), 4500);
        JSONObject earthquake = quakeEnvelope.optJSONObject("data");
        JSONObject quake = earthquake == null ? null : earthquake.optJSONObject("Infogempa");
        quake = quake == null ? null : quake.optJSONObject("gempa");
        if (quake != null) {
            out.earthquakeMagnitude = quake.optString("Magnitude", "—") + " M";
            String region = quake.optString("Wilayah", "Lokasi gempa tidak tersedia");
            String depth = quake.optString("Kedalaman", "—");
            String distance = distanceFromQuake(loc, quake);
            out.earthquakeText = region + " · " + depth + (distance == null ? "" : " · " + distance);
            out.hasGeo = true;
        }
        JSONObject volcanoEnvelope = requestJson(siteUrl("/.netlify/functions/public-data?source=volcano"), 4500);
        JSONArray reports = volcanoEnvelope.optJSONArray("reports");
        Volcano volcano = nearestKnownVolcano(loc);
        if (reports != null && volcano != null) {
            String key = normalize(volcano.name);
            for (int i = 0; i < reports.length(); i++) {
                JSONObject report = reports.optJSONObject(i);
                if (report == null) continue;
                String name = normalize(report.optString("name", ""));
                if (name.equals(key) || (key.equals("sindoro") && name.equals("sundoro"))) {
                    out.volcanoName = volcano.name + " · " + Math.round(volcano.distanceKm) + " km";
                    out.volcanoStatus = report.optString("level", "Status resmi belum tersedia");
                    out.hasGeo = true;
                    break;
                }
            }
        }
        // The same cached national InaRISK endpoint powers the website and GEO widgets.
        // These are baseline susceptibility classes; absence of a BMKG alert is not NORMAL.
        out.tsunamiStatus = "DATA BELUM TERSEDIA";
        out.floodStatus = "DATA BELUM TERSEDIA";
        out.landslideStatus = "DATA BELUM TERSEDIA";
        try {
            JSONObject risk = requestJson(siteUrl("/.netlify/functions/hazard-risk?lat=" + enc(loc.lat) + "&lon=" + enc(loc.lon)), 9000);
            JSONObject hazards = risk.optJSONObject("hazards");
            if (hazards != null) {
                JSONObject flood = hazards.optJSONObject("flood");
                JSONObject landslide = hazards.optJSONObject("landslide");
                JSONObject tsunami = hazards.optJSONObject("tsunami");
                if (flood != null) out.floodStatus = safeHazardStatus(flood.optString("status", ""));
                if (landslide != null) out.landslideStatus = safeHazardStatus(landslide.optString("status", ""));
                if (tsunami != null) out.tsunamiStatus = safeHazardStatus(tsunami.optString("status", ""));
                if (risk.optInt("availableCount", 0) > 0) out.hasGeo = true;
            }
        } catch (Exception ignored) {
            // Keep the three explicit unavailable labels; never substitute a guessed NORMAL.
        }
    }

    private static String safeHazardStatus(String value) {
        if ("NORMAL".equals(value) || "BERPOTENSI".equals(value) || "SIAGA".equals(value) || "BAHAYA".equals(value)) return value;
        return "DATA BELUM TERSEDIA";
    }

    private static String distanceFromQuake(LocationInfo loc, JSONObject quake) {
        try {
            String latText = quake.optString("Lintang", "").trim();
            String lonText = quake.optString("Bujur", "").trim();
            Double lat = coordinate(latText, true), lon = coordinate(lonText, false);
            if (lat == null || lon == null) return null;
            float[] result = new float[1];
            Location.distanceBetween(loc.latitude, loc.longitude, lat, lon, result);
            return Math.round(result[0] / 1000f) + " km";
        } catch (Exception ignored) { return null; }
    }

    private static Double coordinate(String input, boolean latitude) {
        try {
            String s = input.toUpperCase(Locale.ROOT).replace(',', '.').trim();
            java.util.regex.Matcher m = java.util.regex.Pattern.compile("([-+]?\\d+(?:\\.\\d+)?)\\s*(LS|LU|BT|BB)?").matcher(s);
            if (!m.find()) return null;
            double v = Double.parseDouble(m.group(1));
            String dir = m.group(2) == null ? "" : m.group(2);
            if ("LS".equals(dir) || "BB".equals(dir)) v = -Math.abs(v);
            if ("LU".equals(dir) || "BT".equals(dir)) v = Math.abs(v);
            return v;
        } catch (Exception ignored) { return null; }
    }

    private static Volcano nearestKnownVolcano(LocationInfo loc) {
        // Coordinates are a curated locator catalogue; status is only shown when matched to an official MAGMA report.
        Volcano[] list = new Volcano[] {
            new Volcano("Merapi", -7.5407, 110.4460), new Volcano("Merbabu", -7.4540, 110.4400),
            new Volcano("Slamet", -7.2420, 109.2080), new Volcano("Sumbing", -7.3840, 110.0700),
            new Volcano("Sindoro", -7.3010, 109.9920), new Volcano("Lawu", -7.6270, 111.1920),
            new Volcano("Kelud", -7.9300, 112.3080), new Volcano("Bromo", -7.9420, 112.9500),
            new Volcano("Semeru", -8.1080, 112.9220), new Volcano("Anak Krakatau", -6.1020, 105.4230),
            new Volcano("Marapi", -0.3810, 100.4730), new Volcano("Sinabung", 3.1700, 98.3920),
            new Volcano("Ibu", 1.4880, 127.6320), new Volcano("Lewotobi Laki-laki", -8.5380, 122.7680)
        };
        Volcano best = null;
        for (Volcano v : list) {
            float[] distance = new float[1];
            Location.distanceBetween(loc.latitude, loc.longitude, v.lat, v.lon, distance);
            v.distanceKm = distance[0] / 1000.0;
            if (best == null || v.distanceKm < best.distanceKm) best = v;
        }
        return best;
    }

    private static List<BmkgSlot> parseBmkg(JSONObject response) {
        List<BmkgSlot> slots = new ArrayList<>();
        if (response == null) return slots;
        JSONArray items = response.optJSONArray("data");
        if (items == null) return slots;
        for (int i = 0; i < items.length(); i++) {
            JSONObject item = items.optJSONObject(i);
            JSONArray groups = item == null ? null : item.optJSONArray("cuaca");
            if (groups == null) continue;
            for (int j = 0; j < groups.length(); j++) {
                JSONArray row = groups.optJSONArray(j);
                if (row == null) continue;
                for (int k = 0; k < row.length(); k++) {
                    JSONObject x = row.optJSONObject(k);
                    if (x == null) continue;
                    String utc = x.optString("utc_datetime", "").trim();
                    long epoch = parseBmkgEpoch(utc);
                    if (epoch <= 0) continue;
                    BmkgSlot slot = new BmkgSlot();
                    slot.epochMs = epoch;
                    slot.temp = num(x.opt("t"));
                    slot.humidity = num(x.opt("hu"));
                    slot.wind = num(x.opt("ws"));
                    slot.condition = x.optString("weather_desc", "").trim();
                    slots.add(slot);
                }
            }
        }
        return slots;
    }

    private static long parseBmkgEpoch(String utc) {
        if (TextUtils.isEmpty(utc)) return -1;
        String value = utc.trim().replace(' ', 'T');
        for (String pattern : new String[]{"yyyy-MM-dd'T'HH:mm:ss.SSSX", "yyyy-MM-dd'T'HH:mm:ssX", "yyyy-MM-dd'T'HH:mm:ss"}) {
            try {
                SimpleDateFormat parser = new SimpleDateFormat(pattern, Locale.US);
                parser.setLenient(false);
                parser.setTimeZone(TimeZone.getTimeZone("UTC"));
                Date parsed = parser.parse(value);
                if (parsed != null) return parsed.getTime();
            } catch (ParseException ignored) { }
        }
        return -1;
    }

    private static BmkgSlot closestBmkg(List<BmkgSlot> slots, long target) {
        BmkgSlot nearest = null, previous = null;
        long delta = Long.MAX_VALUE, previousEpoch = Long.MIN_VALUE;
        for (BmkgSlot slot : slots) {
            long d = Math.abs(slot.epochMs - target);
            if (d < delta || (d == delta && slot.epochMs <= target)) { nearest = slot; delta = d; }
            if (slot.epochMs <= target && slot.epochMs > previousEpoch) { previous = slot; previousEpoch = slot.epochMs; }
        }
        if (nearest != null && delta <= 90 * 60 * 1000L) return nearest;
        if (previous != null && target - previousEpoch <= 3 * 60 * 60 * 1000L) return previous;
        return null;
    }

    private static int nearestHourlyIndex(JSONObject hourly, long epoch) {
        JSONArray times = hourly == null ? null : hourly.optJSONArray("time");
        if (times == null) return -1;
        int best = -1; long delta = Long.MAX_VALUE;
        for (int i = 0; i < times.length(); i++) {
            long value = parseModelEpoch(times.optString(i, ""));
            long d = Math.abs(value - epoch);
            if (value > 0 && d < delta) { best = i; delta = d; }
        }
        return delta <= 55 * 60 * 1000L ? best : -1;
    }

    private static long nextHourEpoch(long now, int offset) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(now);
        boolean roundUp = calendar.get(Calendar.MINUTE) > 0 || calendar.get(Calendar.SECOND) > 0 || calendar.get(Calendar.MILLISECOND) > 0;
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        if (roundUp) calendar.add(Calendar.HOUR_OF_DAY, 1);
        calendar.add(Calendar.HOUR_OF_DAY, offset);
        return calendar.getTimeInMillis();
    }

    private static long parseModelEpoch(String value) {
        if (TextUtils.isEmpty(value)) return -1;
        String normalized = value.trim();
        for (String pattern : new String[]{"yyyy-MM-dd'T'HH:mm:ssX", "yyyy-MM-dd'T'HH:mmX", "yyyy-MM-dd'T'HH:mm"}) {
            try {
                SimpleDateFormat parser = new SimpleDateFormat(pattern, Locale.US);
                parser.setLenient(false);
                parser.setTimeZone(TimeZone.getDefault());
                Date parsed = parser.parse(normalized);
                if (parsed != null) return parsed.getTime();
            } catch (ParseException ignored) { }
        }
        return -1;
    }

    private static Double nearestHourlyNumber(JSONObject hourly, String key, long now) {
        int ix = nearestHourlyIndex(hourly, now);
        return ix < 0 ? null : arrayNum(hourly, key, ix);
    }

    private static int nearestHourlyInt(JSONObject hourly, String key, long now, int fallback) {
        int ix = nearestHourlyIndex(hourly, now);
        return ix < 0 ? fallback : arrayInt(hourly, key, ix, fallback);
    }

    private static Double arrayNum(JSONObject object, String key, int index) {
        JSONArray array = object == null ? null : object.optJSONArray(key);
        return array == null || index >= array.length() ? null : num(array.opt(index));
    }

    private static int arrayInt(JSONObject object, String key, int index, int fallback) {
        Double v = arrayNum(object, key, index);
        return v == null ? fallback : (int) Math.round(v);
    }

    private static String displayWeatherCondition(String value) {
        if (value == null) return "Kondisi belum tersedia";
        return value.toLowerCase(Locale.ROOT).contains("gerimis") || value.toLowerCase(Locale.ROOT).contains("drizzle") ? "Mendung" : value;
    }
    private static int weatherCode(Object value) { Double v = num(value); return v == null ? -1 : (int) Math.round(v); }
    private static String weatherText(int code) {
        if (code == 0) return "Cerah";
        if (code == 1 || code == 2) return "Cerah berawan";
        if (code == 3) return "Berawan";
        if (code == 45 || code == 48) return "Berkabut";
        if (code >= 51 && code <= 57) return "Mendung";
        if (code >= 61 && code <= 67 || code >= 80 && code <= 82) return "Hujan";
        if (code >= 95) return "Hujan disertai petir";
        return "Kondisi belum tersedia";
    }
    private static String weatherIcon(String condition, int code) {
        String s = condition == null ? "" : condition.toLowerCase(Locale.ROOT);
        if (s.contains("petir") || s.contains("badai") || code >= 95) return "⛈️";
        if (s.contains("hujan lebat") || s.contains("hujan sedang") || s.contains("hujan") || code >= 61 && code <= 82) return "🌧️";
        if (s.contains("gerimis") || code >= 51 && code <= 57) return "☁️";
        if (s.contains("kabut") || code == 45 || code == 48) return "🌫️";
        if (s.contains("cerah") || code == 0 || code == 1 || code == 2) return "🌤️";
        if (s.contains("berawan") || code == 3) return "☁️";
        return "🌤️";
    }

    private static JSONObject requestJson(String urlText, int timeoutMs) throws Exception {
        HttpURLConnection connection = null;
        try {
            connection = (HttpURLConnection) new URL(urlText).openConnection();
            connection.setConnectTimeout(timeoutMs);
            connection.setReadTimeout(timeoutMs);
            connection.setRequestMethod("GET");
            connection.setRequestProperty("Accept", "application/json");
            connection.setRequestProperty("User-Agent", "FikriWeatherAndroidWidget/2.4.7");
            connection.setUseCaches(false);
            int code = connection.getResponseCode();
            InputStream stream = code >= 200 && code < 300 ? connection.getInputStream() : connection.getErrorStream();
            if (stream == null) throw new IllegalStateException("HTTP " + code);
            StringBuilder body = new StringBuilder();
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
                String line; while ((line = reader.readLine()) != null) body.append(line);
            }
            if (code < 200 || code >= 300) throw new IllegalStateException("HTTP " + code);
            return new JSONObject(body.toString());
        } finally { if (connection != null) connection.disconnect(); }
    }

    private static String siteUrl(String path) { return BuildConfig.WEBSITE_URL + path; }
    private static String enc(String value) throws Exception { return URLEncoder.encode(value, "UTF-8"); }
    private static String enc(double value) throws Exception { return enc(String.format(Locale.US, "%.6f", value)); }

    private static LocationInfo location(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        double lat = Double.NaN, lon = Double.NaN;
        String place = prefs.getString("place", "");
        String adm4 = prefs.getString("adm4", "");
        boolean gpsMode = "gps".equalsIgnoreCase(prefs.getString("location_mode", "gps"));
        if (prefs.contains("lat") && prefs.contains("lon")) {
            lat = Double.longBitsToDouble(prefs.getLong("lat", Double.doubleToLongBits(Double.NaN)));
            lon = Double.longBitsToDouble(prefs.getLong("lon", Double.doubleToLongBits(Double.NaN)));
        }
        if (gpsMode) {
            try {
                boolean fine = Build.VERSION.SDK_INT < 23 || context.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
                boolean coarse = Build.VERSION.SDK_INT < 23 || context.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
                if (fine || coarse) {
                    LocationManager manager = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
                    Location best = null;
                    for (String provider : new String[]{LocationManager.NETWORK_PROVIDER, LocationManager.GPS_PROVIDER, LocationManager.PASSIVE_PROVIDER}) {
                        try {
                            Location candidate = manager.getLastKnownLocation(provider);
                            if (candidate != null && (best == null || candidate.getTime() > best.getTime())) best = candidate;
                        } catch (SecurityException ignored) { }
                    }
                    if (best != null) {
                        long age = Math.max(0L, System.currentTimeMillis() - best.getTime());
                        boolean noSavedFix = !valid(lat, lon);
                        if (age <= (noSavedFix ? 24L : 6L) * 60L * 60L * 1000L) {
                            boolean moved = noSavedFix;
                            if (!noSavedFix) {
                                float[] distance = new float[1];
                                Location.distanceBetween(lat, lon, best.getLatitude(), best.getLongitude(), distance);
                                moved = distance[0] >= 150f;
                            }
                            lat = best.getLatitude(); lon = best.getLongitude();
                            place = "Lokasi perangkat";
                            if (moved) adm4 = "";
                            SharedPreferences.Editor update = prefs.edit()
                                    .putLong("lat", Double.doubleToLongBits(lat))
                                    .putLong("lon", Double.doubleToLongBits(lon))
                                    .putString("place", place);
                            if (moved) update.remove("adm4");
                            update.apply();
                        }
                    }
                }
            } catch (Exception ignored) { }
        }
        if (!valid(lat, lon)) return null;
        return new LocationInfo(lat, lon, TextUtils.isEmpty(place) ? "Lokasi perangkat" : place, adm4);
    }

    private static boolean valid(double lat, double lon) { return Double.isFinite(lat) && Double.isFinite(lon) && Math.abs(lat) <= 90 && Math.abs(lon) <= 180; }
    private static Double num(Object value) { if (value == null || value == JSONObject.NULL) return null; try { double n = value instanceof Number ? ((Number)value).doubleValue() : Double.parseDouble(String.valueOf(value)); return Double.isFinite(n) ? n : null; } catch (Exception ignored) { return null; } }
    private static String display(Double value, String suffix) { return value == null ? "—" : String.format(Locale.US, "%.0f%s", value, suffix); }
    private static String formatTime(long epoch) { return new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date(epoch)); }
    private static String joinNonEmpty(String... parts) { List<String> values = new ArrayList<>(); for (String p : parts) if (!TextUtils.isEmpty(p) && !values.contains(p)) values.add(p); return TextUtils.join(", ", values); }
    private static String normalize(String value) { return (value == null ? "" : value).toLowerCase(Locale.ROOT).replace("-", " ").replaceAll("[^a-z0-9 ]", "").replaceAll("\\s+", " ").trim(); }

    private static JSONObject toJson(WidgetSnapshot s) throws Exception {
        JSONObject root = new JSONObject();
        root.put("place", s.place); root.put("date", s.date); root.put("time", s.time); root.put("temperature", s.temperature);
        root.put("condition", s.condition); root.put("feelsLike", s.feelsLike); root.put("humidity", s.humidity); root.put("wind", s.wind);
        root.put("rainChance", s.rainChance); root.put("source", s.source); root.put("updatedAt", s.updatedAt); root.put("currentIcon", s.currentIcon);
        root.put("earthquakeMagnitude", s.earthquakeMagnitude); root.put("earthquakeText", s.earthquakeText); root.put("volcanoName", s.volcanoName);
        root.put("volcanoStatus", s.volcanoStatus); root.put("tsunamiStatus", s.tsunamiStatus); root.put("floodStatus", s.floodStatus);
        root.put("landslideStatus", s.landslideStatus); root.put("hasWeather", s.hasWeather); root.put("hasBmkg", s.hasBmkg); root.put("hasGeo", s.hasGeo);
        JSONArray array = new JSONArray();
        for (WidgetSnapshot.ForecastSlot f : s.forecast) { JSONObject x = new JSONObject(); x.put("time", f.time); x.put("temperature", f.temperature); x.put("condition", f.condition); x.put("icon", f.icon); x.put("source", f.source); array.put(x); }
        root.put("forecast", array); return root;
    }

    private static WidgetSnapshot fromJson(JSONObject root) {
        WidgetSnapshot s = new WidgetSnapshot();
        s.place=root.optString("place",s.place); s.date=root.optString("date",s.date); s.time=root.optString("time",s.time); s.temperature=root.optString("temperature",s.temperature);
        s.condition=root.optString("condition",s.condition); s.feelsLike=root.optString("feelsLike",s.feelsLike); s.humidity=root.optString("humidity",s.humidity); s.wind=root.optString("wind",s.wind);
        s.rainChance=root.optString("rainChance",s.rainChance); s.source=root.optString("source",s.source); s.updatedAt=root.optString("updatedAt",s.updatedAt); s.currentIcon=root.optString("currentIcon",s.currentIcon);
        s.earthquakeMagnitude=root.optString("earthquakeMagnitude",s.earthquakeMagnitude); s.earthquakeText=root.optString("earthquakeText",s.earthquakeText); s.volcanoName=root.optString("volcanoName",s.volcanoName);
        s.volcanoStatus=root.optString("volcanoStatus",s.volcanoStatus); s.tsunamiStatus=root.optString("tsunamiStatus",s.tsunamiStatus); s.floodStatus=root.optString("floodStatus",s.floodStatus); s.landslideStatus=root.optString("landslideStatus",s.landslideStatus);
        s.hasWeather=root.optBoolean("hasWeather"); s.hasBmkg=root.optBoolean("hasBmkg"); s.hasGeo=root.optBoolean("hasGeo");
        JSONArray a=root.optJSONArray("forecast"); if(a!=null)for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x==null)continue;WidgetSnapshot.ForecastSlot f=new WidgetSnapshot.ForecastSlot();f.time=x.optString("time",f.time);f.temperature=x.optString("temperature",f.temperature);f.condition=x.optString("condition",f.condition);f.icon=x.optString("icon",f.icon);f.source=x.optString("source",f.source);s.forecast.add(f);} return s;
    }

    private static final class BmkgSlot { long epochMs; Double temp, humidity, wind; String condition; }
    private static final class LocationInfo { final double latitude,longitude;final String place,adm4;LocationInfo(double lat,double lon,String p,String a){latitude=lat;longitude=lon;place=p;adm4=a;} }
    private static final class Volcano { final String name;final double lat,lon;double distanceKm;Volcano(String n,double a,double o){name=n;lat=a;lon=o;} }
}
