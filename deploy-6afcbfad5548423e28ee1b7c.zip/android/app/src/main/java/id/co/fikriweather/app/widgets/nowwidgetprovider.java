package id.co.fikriweather.app.widgets;

public final class NowWidgetProvider extends FikriWidgetProvider {
    @Override protected String kind() { return "now"; }
    @Override protected String title() { return "FIKRI WEATHER NOW"; }
    @Override protected int layoutResource() { return id.co.fikriweather.app.R.layout.widget_fikri_now; }
}
