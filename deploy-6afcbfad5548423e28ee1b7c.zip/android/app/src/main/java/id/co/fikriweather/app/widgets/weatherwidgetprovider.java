package id.co.fikriweather.app.widgets;

public final class WeatherWidgetProvider extends FikriWidgetProvider {
    @Override protected String kind() { return "weather"; }
    @Override protected String title() { return "FIKRI WEATHER"; }
}
