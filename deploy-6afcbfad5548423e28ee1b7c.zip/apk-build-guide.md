# Panduan APK Fikri Weather

## Apa yang dibangun

APK memakai Android WebView native untuk membuka website Fikri Weather yang sudah di-deploy melalui HTTPS. URL website ditanam pada konfigurasi build agar permintaan `/.netlify/functions/`, sesi login, dan cookie tetap memakai origin website yang sama. Data akun dan cuaca tetap dilayani Netlify/Supabase serta sumber cuaca. Paket 2.4.7 mempertahankan dan memperbaiki empat widget layar utama: FIKRI WEATHER (4×2), FIKRI GEO MONITOR (4×2), FIKRI WEATHER + GEO MONITOR (4×3), dan FIKRI WEATHER NOW (4×1). 

## Cara termudah: GitHub Actions

1. Push seluruh isi proyek ke repository GitHub. Jangan ikutkan `.env`, kredensial, `node_modules`, atau hasil build lokal.
2. Pastikan website sudah live menggunakan HTTPS.
3. Di GitHub, buka **Actions** → **Build Fikri Weather APK** → **Run workflow**.
4. Isi `site_url` dengan origin saja, contoh `https://fikri-weather.netlify.app`.
5. Setelah job selesai, unduh artifact **fikri-weather-android-debug-apk** pada halaman run.
6. Ekstrak artifact dan instal `app-debug.apk` pada perangkat Android untuk pengujian.

## Build lokal

Persyaratan: Node.js 22+, JDK 17+, Gradle 8.13, Android Studio, Android SDK, platform-tools, Android API 36, dan build-tools 36.0.0. Kombinasi Android Gradle Plugin 8.13 memerlukan Gradle 8.13; lihat tabel kompatibilitas resmi Android.

Linux/macOS:

```bash
npm run check
FW_SITE_URL=https://fikri-weather.netlify.app npm run android:build
```

Windows PowerShell:

```powershell
npm run check
$env:FW_SITE_URL="https://fikri-weather.netlify.app"
npm run android:build
```

Hasil: `android/app/build/outputs/apk/debug/app-debug.apk`.

## Widget layar utama

- Setelah APK terpasang, tekan lama layar utama Android → **Widget** → **Fikri Weather**, lalu tarik widget yang diinginkan ke layar. Nama dan ukuran persis yang disediakan launcher dapat berbeda sedikit antarmerek.
- Izinkan akses lokasi di aplikasi, lalu gunakan lokasi GPS atau pilih lokasi manual/favorit. Perubahan lokasi dari aplikasi diteruskan ke keempat widget.
- Tombol **Update** pada salah satu widget meminta pembaruan seluruh widget. Pembaruan berkala disetel 30 menit, tetapi Android dapat menundanya untuk menghemat baterai.
- Widget 1 dan 3 memiliki navigasi 4 kartu per halaman untuk menelusuri 10 jam prakiraan.

## Catatan penting

- Masukkan alamat HTTPS utama website, tanpa path, query, atau fragmen.
- APK memakai website yang di-host; perubahan pada website akan ikut tampil tanpa membuat APK baru selama domain tetap sama.
- APK membutuhkan internet untuk data prakiraan dan fitur server. `offline.html` hanyalah layar bantuan saat koneksi/website tidak tersedia, bukan salinan offline seluruh dashboard.
- APK yang dibuat workflow adalah **debug APK**, bukan APK release bertanda tangan untuk Google Play. Publikasi Play Store memerlukan release keystore dan konfigurasi signing terpisah.
- Fitur lokasi meminta izin lokasi Android. Dukungan push/notifikasi latar belakang pada WebView berbeda dari Chrome/PWA dan tidak dijamin; gunakan PWA/Chrome Android untuk pengalaman notifikasi web yang lebih teruji.
