# Fikri Weather — paket pengembangan

Proyek ini mempertahankan halaman Fikri Weather yang sudah diunggah dan menambahkan tampilan loading, panel Portal MBG, akun pengguna, notifikasi, percakapan privat, dashboard admin, backend Netlify Functions, database Supabase, serta dukungan PWA.

## Hotfix analisis risiko lokasi (14 November 2026)

- Pembacaan indeks InaRISK memakai nilai mosaic pada satu piksel tepat koordinat terpilih dengan renderer yang sama seperti peta. Kelas raster mentah tetap tersedia sebagai konteks peta.
- Status analisis menggunakan NORMAL, BERPOTENSI, SIAGA, dan BAHAYA. Kelas raster tinggi menjadi SIAGA, bukan BAHAYA otomatis; BAHAYA memerlukan pemicu yang lebih kuat atau peringatan resmi yang cocok.
- Skrining longsor tidak lagi menganggap elevasi tinggi sebagai bukti lereng rawan. Kemiringan dan relief medan dihitung dari kisi DEM 3×3 yang berpusat pada titik pilihan dengan jarak sampel sekitar 100 m; hujan prakiraan 24/72 jam, hujan historis 3/7 hari yang cakupannya lengkap, dan kelembapan tanah menjadi indikator pendamping.
- Ambang pemicu hujan longsor mengikuti referensi BMKG/Sabo (lebih dari 56 mm/hari dan 128 mm/3 hari untuk kondisi sangat rawan), tetapi skor gabungan tetap merupakan skrining heuristik dan bukan probabilitas kejadian atau pengganti peta zona gerakan tanah Badan Geologi.
- Titik yang DEM-nya menunjukkan medan lokal datar tidak dinaikkan menjadi potensi longsor hanya karena hujan atau kelas raster yang lebih luas. Nilai raster asli tetap ditampilkan agar perbedaan sumber dapat diperiksa.
- Indikator hujan harian yang hilang tidak diperlakukan sebagai nol. Periode historis 3 dan 7 hari hanya dihitung dari tanggal berurutan yang benar-benar tersedia. Pemicu hujan longsor memeriksa pasangan ambang harian dan akumulasi 3 hari dari prakiraan, atau dari riwayat 3 hari yang lengkap.
- Kelas InaRISK pada piksel tepat tetap dihormati walaupun estimasi medan lokal datar; label status pada panel diterjemahkan menjadi NORMAL, BERPOTENSI, SIAGA, dan BAHAYA. Label kelas asli layer peta dijelaskan terpisah.
- Perubahan hanya menyentuh panel analisis risiko, fungsi Netlify `hazard-risk.js`, dan dokumentasi/tes regresi terkait. `npm run check` lulus. Uji ini adalah pemeriksaan kode dan skenario sintetis, bukan validasi lapangan/kejadian historis atau verifikasi live semua endpoint eksternal.

## Perbaikan terarah 2.4.7 (14 November 2026)

- Memperbaiki lingkup parser waktu pada analisis bencana lokasi; pemrosesan data tidak lagi bergantung pada helper `iso()` milik skrip lain.
- Setiap sumber analisis diproses secara independen dengan timeout. Indeks InaRISK, peringatan CAP BMKG, feed gempa BMKG, hujan pelengkap, kelembapan tanah, dan elevasi tetap dapat menampilkan hasilnya masing-masing meskipun sumber lain gagal.
- Akumulasi hujan menggunakan slot per jam yang benar-benar tersedia. Slot yang terbaca ditampilkan sebagai cakupan; total harian kalender tidak disamakan dengan periode 24/72 jam bergulir. Nilai historis menunjukkan jumlah hari yang berhasil dibaca.
- Elevasi kosong tidak dikonversi menjadi 0; kemiringan hanya dihitung saat kelima titik elevasi tersedia. Hujan tidak digunakan sebagai pemicu untuk menaikkan indeks tsunami.
- Field status tsunami BMKG dipisahkan dari informasi gempa dirasakan. Teks gempa dirasakan tidak lagi ditempatkan sebagai status tsunami. Parser waktu menerima singkatan bulan BMKG dan DateTime ISO; selisih waktu event/diterima dihitung dari timestamp.
- Legenda InaRISK tetap menjadi elemen di bawah peta dan tidak lagi dipasang sebagai kontrol overlay Leaflet. Kartu indikator dan catatan aktivitas diperbaiki khusus untuk tampilan sempit.
- Alias wilayah DIY pada reverse geocoding BMKG ditambahkan agar peringatan dapat dicocokkan ke provinsi yang benar.
- Cache shell PWA dinaikkan ke v12; Android versionCode 11 dan versionName 2.4.7.
- Uji `npm run check` mencakup pemeriksaan kode, 15 skenario TanyaFikriCuaca, widget, cuaca, dan tes regresi baru untuk analisis lokasi/gempa/layout. Ini bukan pengganti uji browser langsung atau verifikasi ketersediaan layanan eksternal.
- Paket ini adalah source ZIP; APK belum dibangun dan website live tidak di-deploy atau diubah langsung.

## Perbaikan terarah 2.4.6 (14 November 2026)

- Cakupan perubahan dibatasi pada widget Android, panel risiko banjir/longsor, peta geologi dan layer InaRISK, Jemuran, rekomendasi aktivitas luar ruang, serta judul Persiapan Berkegiatan di Luar. Menu lain tidak dimaksudkan untuk diubah.
- Empat AppWidgetProvider didaftarkan di manifest beserta empat metadata provider; ukuran 4×2, 4×2, 4×3, dan 4×1. Pembaruan periodik 30 menit mengikuti batas sistem Android.
- Analisis lokasi hanya membaca indeks banjir dan longsor InaRISK BNPB. Nilai hasil raster function diprioritaskan agar hasil titik konsisten dengan renderer peta; pembacaan area memakai sampel 3×3 sel raster 100 m dan kelas tertinggi. Kelas rendah/sedang/tinggi dipisahkan dari peringatan aktif BMKG. Jika data raster tidak tersedia, tampilkan DATA BELUM TERSEDIA tanpa membuat skor dari cuaca/topografi.
- Catatan lisensi: metadata Portal Satu Data BNPB untuk dataset bahaya InaRISK menyebut hak cipta BNPB dan mensyaratkan izin tertulis sebelum data dikutip/disalin/digunakan. Minta persetujuan BNPB sebelum mengaktifkan atau mempublikasikan pemakaian data raster ini pada domain publik.
- Peta risiko memakai ImageServer nasional dengan fallback gambar WGS84 dan legenda kelas. Peta gempa menampilkan marker SVG kuning/merah yang dapat diketuk.
- Jemuran membedakan slot RELATIF MENDUKUNG, WASPADA / LAMBAT KERING, dan HINDARI / SEGERA ANGKAT berdasarkan hujan, kelembapan, angin, awan, dan radiasi.
- Jogging, lari, jalan kaki, dan bersepeda mencari jendela cuaca yang memenuhi syarat pada pagi serta sore/malam, dengan alasan dan waktu alternatif. Daftar perlengkapan menyesuaikan kondisi pada waktu aktivitas terdekat dan tidak menyarankan perlindungan UV pada malam hari.
- Pengujian proyek dan skenario fitur dijalankan melalui `npm run check`. Ini adalah uji kode lokal, bukan bukti ketersediaan API eksternal setiap saat atau uji instalasi pada perangkat Samsung.
- APK tidak disertakan di paket source ini. Build APK memerlukan Gradle dan Android SDK; panduan GitHub Actions tersedia di `APK-BUILD-GUIDE.md`. Website live tidak di-deploy otomatis dari proses ini.

## Struktur

- `index.html` — website utama.
- `netlify/functions/` — API server untuk login admin/pengguna, BMKG, pencarian lokasi Indonesia, peringatan dini BMKG CAP, MAGMA, METAR/TAF, asisten cuaca berbasis aturan, notifikasi pengguna, dan push khusus admin (`admin-notifications.js`).
- `supabase/schema.sql` — tabel database dan pengaturan akses.
- `service-worker.js`, `manifest.webmanifest`, `icon-*` — PWA dan notifikasi push.
- `.env.example` — daftar nama variabel server; tidak berisi rahasia.

## Menjalankan di komputer

Website tidak dapat memakai autentikasi server jika `index.html` dibuka dengan `file://`. Jalankan lewat Netlify Dev atau server HTTPS.

1. Pasang Node.js 22 atau lebih baru (dibutuhkan untuk pemeriksaan dan build Android).
2. Di folder proyek jalankan `npm install`.
3. Buat proyek Supabase.
4. Buka SQL Editor di Supabase, lalu jalankan seluruh isi `supabase/schema.sql`. Jika proyek sudah memakai schema versi sebelumnya, jalankan ulang file yang sudah diperbarui agar tabel `admin_push_subscriptions` dan `admin_notifications` ikut dibuat.
5. Buat situs Netlify dan hubungkan folder/repository proyek ini. `netlify.toml` sudah mengatur direktori fungsi.
6. Di Netlify → Site configuration → Environment variables, isi variabel berikut:
   - `SUPABASE_URL` — URL proyek Supabase.
   - `SUPABASE_SERVICE_ROLE_KEY` — service-role key Supabase. **Hanya untuk environment server Netlify; jangan pernah masukkan ke HTML, JavaScript publik, atau repository.**
   - `SUPABASE_MEDIA_BUCKET=fw-media`
   - `SITE_ORIGIN` — origin website, misalnya `https://fikri-weather.netlify.app` (tanpa garis miring terakhir).
   - `ADMIN_SECRET_CODE` — buat kode admin yang panjang dan acak. Kode hanya disimpan di environment server Netlify dan diverifikasi oleh `admin-auth.js`; jangan menyalinnya ke HTML/JavaScript, file `.env` publik, atau repository. Jika pernah memakai kode yang dulu tertanam di HTML, segera ganti dengan kode baru.
   - Tanya Fikri Weather menggunakan aturan berbasis menu/data situs dan tidak membutuhkan `OPENAI_API_KEY`.
7. Deploy ulang website. Login admin hanya menggunakan satu kode rahasia yang dikirim ke server untuk diverifikasi. Tidak ada username/password maupun email admin. Backend membuat sesi admin HttpOnly sehingga fungsi privat tidak hanya mengandalkan status di browser.

## TanyaFikriCuaca dan Dashboard Terpadu (12 November 2026)

- `tanyafikricuaca` berjalan sebagai asisten cuaca mandiri berbasis NLP deterministik, pengelolaan konteks, basis pengetahuan meteorologi, dan mesin aturan. Fitur ini **tidak menggunakan OpenAI API, ChatGPT, atau API key AI berbayar**. Jawaban dibangun dari data cuaca yang dikirim website ke fungsi Netlify; jika data/variabel tidak tersedia, asisten menyatakannya dan tidak membuat angka pengganti. Sistem ini bukan model bahasa generatif umum dan sengaja dibatasi pada cuaca serta fitur Fikri Weather.
- Asisten mengenali variasi bahasa Indonesia sehari-hari, sejumlah typo/singkatan, waktu relatif, dan pertanyaan lanjutan seperti “Besok hujan?” → “Kalau sore?”. Konteks cuaca aktif (lokasi, prakiraan per jam, dan prakiraan harian) dikirim dari halaman yang sedang dibuka.
- Riwayat percakapan lokal disimpan pada sesi browser. Penyimpanan ke akun Supabase **opsional** dan hanya dilakukan setelah pengguna mengaktifkan pilihan simpan serta login. Data tersimpan dibatasi per akun; pengguna dapat memilih percakapan tersimpan atau menghapus riwayat akunnya.
- Untuk database Supabase yang sudah digunakan, jalankan `supabase/migrations/20261112_assistant_conversations.sql` melalui SQL Editor. Instalasi baru dapat menjalankan `supabase/schema.sql` yang telah diperbarui. Jangan menaruh service-role key di browser.
- Dashboard yang sudah ada kini memuat ringkasan analisis, kartu geser prakiraan 4 hari (96 jam) dan 15 hari ke depan (hari ini + 15 tanggal), rekomendasi aktivitas/lingkungan/pertanian, perlengkapan yang perlu dibawa, saran waktu kegiatan, dan peringatan yang cocok dengan lokasi. **Tidak ada menu navigasi baru**; halaman prakiraan dan menu lama tetap dipertahankan.
- Kartu dashboard menggunakan data aktual yang berhasil dimuat. Variabel seperti kualitas udara/AQI atau kelembapan tanah dapat ditandai belum tersedia bila tidak disediakan sistem; indikator banjir/kekeringan merupakan skrining berbasis data pendukung, bukan peringatan resmi atau jaminan kejadian. Data sumber dan waktu pengambilan tetap tersedia untuk audit internal, sedangkan nama penyedia tidak ditampilkan pada ringkasan dashboard.
- Pengujian lokal: `npm run test:assistant` menjalankan skenario intent, konteks lanjutan, kelengkapan intent cuaca, konteks lanjutan, dan penanganan data kosong, dan penanganan data kosong. `npm run check` menjalankan pemeriksaan proyek sekaligus seluruh tes asisten.

## Pembaruan dashboard, wisata, AQI, dan peta (12 November 2026)

- Indikator proses diposisikan di kiri atas layar.
- Kartu Jemuran, Rute & Hujan, serta Pertanian & Irigasi memiliki tombol langsung ke halaman yang sudah tersedia; tidak menambah item navigasi.
- Aktivitas jogging, lari, jalan kaki, dan bersepeda menggunakan slot prakiraan per jam yang memenuhi ambang hujan, suhu, dan angin. Kartu Android dibuat lebih ringkas dan menampilkan rentang waktu satu jam, kondisi prakiraan, serta slot alternatif bila tersedia. Ini rekomendasi model, bukan jaminan kondisi lapangan.
- Pencarian wisata menyediakan kategori alam/pegunungan, pantai/bahari, air terjun/danau, budaya/sejarah, museum, rekreasi, religi, kuliner, agrowisata, petualangan, belanja, kebun binatang, pemandian air panas, gua/geowisata, kebun raya, waterpark, seni/pertunjukan, dan desa wisata. Hasil memakai koordinat peta; jam operasional hanya ditampilkan jika memang ada pada data destinasi.
- Analisis wisata menggunakan tanggal dan jam lokal tujuan, bukan memaksa semua lokasi memakai WIB. Cuaca titik tujuan memakai prakiraan per jam hingga 4 hari dan slot BMKG tepat bila tersedia. AQI wisata dicocokkan ke rentang waktu lokal yang dipilih.
- Data kualitas udara diambil dari Open-Meteo Air Quality / CAMS Global (US AQI, European AQI, PM2.5, PM10, ozon jika tersedia). Model global ini sekitar 45 km dan interval 3 jam; ia bukan sensor kualitas udara di pinggir jalan. Nilai tidak dibuat jika API gagal.
- Peta tematik menggunakan ArcGIS–Leaflet dynamic MapServer layer untuk raster InaRISK BNPB; bila permintaan dynamic layer gagal, website mencoba fallback export image WGS84. Status memuat/berhasil/gagal ditampilkan. Layer bahaya banjir dan tanah longsor memakai layer nasional terdaftar; riwayat hidrometeorologi memakai layanan tingkat kabupaten 2015–2024.
- Radar BMKG nasional dan Radar Area Hujan Yogyakarta kini dicoba ditampilkan langsung di halaman melalui iframe ke halaman resmi BMKG. Jika kebijakan keamanan frame dari BMKG/browser menolak penyematan lintas situs, tombol Buka di tab baru tetap disediakan; aplikasi tidak dapat melewati kebijakan X-Frame-Options/CSP milik BMKG. Radar alternatif tetap diberi label jelas sebagai alternatif, bukan data BMKG.

## Rilis 2.4.0 — peta bencana, aktivitas, rute, radar, dan gempa (12 November 2026)

- Peta InaRISK memakai dynamic layer ArcGIS–Leaflet dan fallback raster WGS84 untuk layer banjir serta tanah longsor nasional.
- Peta gempa memproses tiga feed BMKG melalui fungsi Netlify, menghapus duplikasi, mengurai koordinat BMKG, dan menampilkan marker interaktif sesuai magnitudo.
- Kartu jogging, lari, jalan kaki, dan bersepeda dipadatkan; waktu ditampilkan sebagai rentang 1 jam dengan kondisi prakiraan serta alternatif jika memenuhi indikator.
- Analisis cuaca sepanjang rute membatasi hingga enam titik sampel, mempertahankan titik awal dan tujuan, dan memberikan daftar kandidat tempat umum terpetakan di sekitar titik yang memiliki sinyal hujan. Perkiraan durasi bukan lalu lintas langsung, dan titik sampel bukan pengamatan seluruh ruas jalan.
- Radar BMKG nasional dan Area Hujan Yogyakarta ditanamkan melalui iframe resmi. Penyematan bergantung pada kebijakan frame BMKG dan browser; jika ditolak, hanya halaman resmi di tab baru yang dapat digunakan.
- Pemeriksaan lokal dijalankan dengan `npm run check`; ini tidak menggantikan pengujian live pada domain Netlify dan ketersediaan layanan eksternal.

## Rilis 2.4.1 — kondisi terkini dan perencana cuaca penerbangan (12 November 2026)

- Kartu kondisi saat ini tidak lagi mengambil slot prakiraan BMKG per 3 jam dan menyebutnya sebagai kondisi teramati. BMKG tetap menjadi acuan prakiraan lokal pada slot yang diterbitkan; model Open-Meteo Best Match ditampilkan sebagai estimasi kondisi terkini dengan timestamp.
- Dashboard mencari hingga lima bandara terdekat dari katalog koordinat, meminta METAR melalui proxy Netlify, lalu memilih pengamatan yang berumur maksimal 90 menit dan berada dalam radius 60 km. Jika METAR memuat fenomena hujan/petir/kabut, label kondisi dapat memakai laporan bandara terdekat dan selalu menampilkan nama stasiun, jarak, waktu, serta umur laporan. Pengamatan di bandara bukan sensor tepat di lokasi pengguna.
- Data Open-Meteo `minutely_15` tidak lagi diperlakukan sebagai nowcast 15-menit untuk Indonesia. Dokumentasi Open-Meteo menyatakan di luar Eropa Tengah dan Amerika Utara nilai 15-menit diinterpolasi dari data per jam. Radar BMKG dan portal pengamatan BMKG tetap ditautkan untuk verifikasi spasial.
- Menu Bandara/Penerbangan menambahkan Perencana Rute & Cuaca dengan 43 pilihan bandara Indonesia dari katalog proyek, waktu keberangkatan lokal, durasi perjalanan, 5–17 titik lintasan, ETA tiap titik, peta Leaflet, tabel cuaca per waktu, ringkasan multi-model, dan ekspor CSV.
- Backend `netlify/functions/flight-route-forecast.js` memvalidasi koordinat Indonesia dan ETA, mengambil prakiraan multi-koordinat Open-Meteo Best Match/ECMWF/GFS, mencocokkan slot jam dengan waktu melintas, menampilkan rentang peluang hujan antarmodel, membatasi cache, dan mengembalikan status tidak tersedia jika seluruh model gagal. Tidak ada angka cuaca pengganti.
- Klasifikasi titik rute tidak menganggap nilai `null` sebagai nol; variabel yang tidak tersedia menghasilkan status “Data tidak cukup”, bukan label cuaca yang dibuat-buat.
- Rute pada peta adalah garis geodesik ilustratif, bukan airway/flight plan operasional. Cuaca rute adalah prakiraan permukaan model, bukan cuaca flight level. Informasi ini tidak menggantikan METAR/SPECI, TAF, SIGMET, SIGWX, Wind/Temp, prakiraan Cb, briefing BMKG Aviation, ATC, atau prosedur operator.
- Uji backend menutup validasi rute, agregasi multi-model, cache, serta kegagalan sumber. `npm run check` harus dijalankan sebelum deploy.

## Web Push

Notifikasi push saat halaman tidak terbuka memerlukan HTTPS, izin pengguna, akun pengguna, preferensi kategori aktif, service worker, serta VAPID key. Browser/OS dapat menunda atau memblokir push berdasarkan izin, koneksi, mode hemat baterai, atau force-stop. Jalankan `npx web-push generate-vapid-keys`, kemudian simpan `VAPID_PUBLIC_KEY`, `VAPID_PRIVATE_KEY`, dan `VAPID_SUBJECT` sebagai environment variables Netlify. Jangan masukkan private key ke frontend. Pengguna perlu login lalu menekan **Aktifkan notifikasi perangkat**. Admin juga perlu login dengan kode, membuka Panel Developer, lalu menekan **Aktifkan notifikasi admin** pada setiap perangkat admin yang ingin menerima push. Push admin dikirim untuk pendaftaran akun baru, saran baru, dan pesan lanjutan dalam percakapan saran.

Fungsi `weather-notifications.js` dijadwalkan setiap 10 menit oleh Netlify (bukan tiap detik). Push akan dikirim setelah fungsi terjadwal mendeteksi pemicu dan server/provider menerima permintaan. Fungsi ini memeriksa feed gempa BMKG, sinyal hujan/prakiraan, dan mengirim notifikasi untuk akun yang memilih kategori terkait serta memiliki lokasi tersimpan. Prakiraan berdasarkan koordinat menggunakan Open-Meteo apabila kode ADM4 BMKG tidak tersedia; sumbernya ditulis sebagai sumber pelengkap, bukan data BMKG. Fungsi jadwal berjalan pada deploy produksi yang sudah dipublikasikan; periksa tab Functions di Netlify untuk melihat status dan log eksekusinya.

## Data dan batasan yang perlu diketahui

- **BMKG**: endpoint prakiraan publik BMKG menggunakan kode ADM4 desa/kelurahan. Data BMKG yang dipublikasikan pada portal terbuka memiliki 8 slot per hari (3 jam) dan diperbarui dua kali sehari. Sistem tidak menginterpolasi slot yang tidak tersedia dan tidak menyebut model sebagai data BMKG.
- **Pemetaan ADM4 seluruh Indonesia**: resolver melakukan reverse geocoding, mencari hierarki provinsi–kabupaten/kota–kecamatan–desa, lalu menguji kandidat kode ke endpoint resmi prakiraan BMKG. Hanya kode yang benar-benar mengembalikan struktur prakiraan BMKG yang dipakai sebagai sumber BMKG. Pencarian kode wilayah memakai hierarki administrasi Wilayah.web.id (Kepmendagri 2025) sebagai kandidat, lalu menguji setiap kode pada endpoint prakiraan BMKG dan mencocokkan nama desa serta kecamatan/kabupaten yang dikembalikan BMKG. BMKG merujuk kode ADM4 Kepmendagri 2022, sehingga perbedaan versi dapat menyebabkan beberapa titik belum cocok; bila tidak cocok, sistem memakai fallback berlabel dan tidak menebak kode. Jika kode tidak cocok/tidak tersedia, data model diberi label sumber pelengkap dan tidak disamarkan sebagai BMKG. Tidak ada sistem pihak ketiga yang bisa menjamin BMKG menerbitkan data bagi setiap titik di setiap saat.
- **Analisis banjir/longsor**: pencarian lokasi, GPS, dan koordinat manual membaca indeks raster InaRISK untuk banjir dan longsor. Nilai hasil pemrosesan raster (rendering rule) diprioritaskan agar kelas titik sesuai dengan layer peta. Pembacaan menguji sembilan sel 100 m di sekitar koordinat dan menampilkan nilai tertinggi, nilai pusat, serta jumlah sel yang berhasil terbaca. Prakiraan/historis hujan, kelembapan tanah, elevasi, dan perkiraan lereng hanya ditampilkan sebagai data pendukung terpisah; tidak dirangkai menjadi skor risiko. Bila raster gagal dibaca, tampilkan DATA BELUM TERSEDIA dan jangan menurunkan status dari data pendukung. Peringatan aktif hanya mengikuti dokumen resmi BMKG yang cocok dengan lokasi. Prakiraan Gerakan Tanah Bulanan (PVMBG) tetap dibuka melalui Portal MBG resmi; layer tersebut tidak disamakan dengan indeks InaRISK. Portal, peta dan laporan resmi tetap menjadi rujukan untuk kelas/kejadian.
- **Gunung api**: endpoint server membaca daftar resmi Tingkat Aktivitas MAGMA berdasarkan kelompok Level IV, III, II, dan I, lalu mengambil nama gunung, wilayah, level, serta tautan laporan PVMBG pada setiap entri. Profil menampilkan seluruh gunung yang tercantum pada daftar resmi, bukan hanya daftar contoh lokal. Saat kartu dipilih, backend mengambil rincian laporan terbaru (pengamatan visual, tinggi asap bila dicantumkan, keterangan, klimatologi, kegempaan, dan rekomendasi). Status yang tidak terdapat pada daftar MAGMA ditandai tidak tercantum, bukan otomatis dianggap Normal. Jika format MAGMA berubah atau server gagal, status terakhir yang berhasil dimuat tidak dihapus dan kegagalan diperlihatkan.
- **Portal MBG dan Radar BMKG**: peta tematik MBG ditampilkan melalui layer geospasial publik BNPB/InaRISK, disertai tautan ke Portal MBG resmi untuk prakiraan gerakan tanah bulanan PVMBG dan laporan Badan Geologi. Radar BMKG dibuka melalui tautan resmi setelah pengguna menekan tombol; portal tidak di-iframe dan tidak dibuka otomatis. Peta overlay bahaya memakai ArcGIS–Leaflet Dynamic Map Layer terlebih dahulu, dengan fallback REST export image WGS84. Jika layanan BNPB gagal mengirim layer melalui kedua jalur, status gagal akan ditampilkan dan peta dasar tetap dapat digunakan.
- **Peringatan dini BMKG**: pembacaan CAP dimulai dari RSS provinsi yang sesuai dengan hasil reverse-geocoding lokasi. Peringatan hanya ditampilkan jika koordinat masuk ke poligon CAP atau nama administrasi yang tepat ditemukan di `areaDesc`. Judul/deskripsi umum tidak digunakan sebagai satu-satunya alasan kecocokan. Jika provinsi lokasi tidak dapat diverifikasi, sistem tidak mengambil alert dari provinsi lain dan menampilkan bahwa pencocokan belum dapat dilakukan. Feed CAP BMKG mencakup peringatan dari provinsi hingga kecamatan dan diperbarui setiap saat; atribusi BMKG ditampilkan.
- **Gempa**: peta menggabungkan tiga feed publik BMKG (gempa terkini M≥5, gempa dirasakan, dan gempa terbaru), menghapus duplikasi, lalu memetakan kejadian yang menyertakan koordinat valid. Marker kuning digunakan untuk M<5/data tanpa magnitudo, merah untuk M≥5; ketuk marker untuk rincian magnitudo, wilayah, waktu, kedalaman, koordinat, feed, dan waktu pertama diterima browser. Parser menerima koordinat desimal LS/LU/BB/BT serta format derajat-menit-detik. Waktu kejadian BMKG dan waktu browser menerima respons adalah dua waktu berbeda. Saat browser pertama kali memperoleh suatu kejadian, waktu penerimaan disimpan per identitas gempa di `localStorage` dan dipakai kembali saat halaman dibuka ulang; waktu tidak dihitung ulang dari waktu sekarang. Riwayat lokal dapat hilang bila data situs/browser dihapus dan tidak otomatis tersinkron antarperangkat. Jika notifikasi gempa diaktifkan, halaman yang terbuka memeriksa feed BMKG setiap 1 menit dan mengumumkan kejadian baru satu kali. Pemeriksaan browser tidak berjalan ketika browser/perangkat tertutup. Push akun dari server tetap memakai jadwal Netlify 10 menit dan dapat tertunda oleh jaringan, browser, atau sistem operasi; ini bukan peringatan dini resmi dan bukan penerimaan instan dari BMKG.
- **Notifikasi lokal**: kategori hujan/gempa di browser juga dapat diperiksa selama halaman terbuka dan izin diberikan. Suara tidak dapat dipaksa otomatis oleh browser; pratinjau memerlukan interaksi pengguna. Suara sistem pada push background mengikuti dukungan/aturan perangkat.
- **Akun**: akun, preferensi, pengumuman, pesan privat, dan riwayat notifikasi disimpan di Supabase. Semua akses privat melewati fungsi server dan cookie HttpOnly. User password di-hash menggunakan scrypt.

## Keamanan penting

Kode admin tidak ditanam di JavaScript publik. Frontend hanya mengirim input login ke `admin-auth.js`; fungsi server memeriksa `ADMIN_SECRET_CODE` dari environment Netlify, membatasi percobaan yang gagal, lalu membuat sesi HttpOnly. Setelah pembaruan paket ini, ganti/rotasi kode admin di Netlify karena versi terdahulu pernah menyimpan kode tersebut di source frontend. Jangan menambahkan file `.env` asli ke ZIP atau repository, dan jangan membagikan service-role key Supabase.

## Sumber resmi/pendukung

- BMKG prakiraan cuaca terbuka (seluruh desa/kelurahan, ADM4): https://data.bmkg.go.id/prakiraan-cuaca/
- BMKG peringatan dini cuaca CAP: https://data.bmkg.go.id/peringatan-dini-cuaca/
- Pencarian wilayah Indonesia: OpenStreetMap Nominatim (dengan atribusi OpenStreetMap).
- Data kandidat kode wilayah: Wilayah.web.id; seluruh kode dikonfirmasi ulang melalui API BMKG.
- BMKG feed gempa: https://data.bmkg.go.id/DataMKG/TEWS/autogempa.json
- MAGMA PVMBG — tingkat aktivitas: https://magma.esdm.go.id/v1/gunung-api/tingkat-aktivitas
- Portal MBG — Badan Geologi: https://vsi.esdm.go.id/portalmbg/
- InaRISK WebGIS — layer Histori Banjir, Flood100 GloFAS, dan Prakiraan Gerakan Tanah Bulanan (PVMBG): https://inarisk.bnpb.go.id/webgis/
- AviationWeather.gov Data API: https://aviationweather.gov/data/api/
- Open-Meteo: https://open-meteo.com/

## Paket dan deployment

ZIP ini adalah source project yang siap dikonfigurasi dan di-deploy. Website dinamis belum dapat berfungsi lintas perangkat sampai Supabase, environment Netlify, VAPID, serta deploy HTTPS selesai dikonfigurasi. Jalankan `npm run check` untuk pemeriksaan sintaks frontend/backend. Permintaan prakiraan utama kini berjalan bersamaan dengan pemetaan wilayah/BMKG; data harian 16 tanggal (hari ini + 15 hari) memakai respons prakiraan utama dan model pelengkap yang tersedia, sehingga tidak membuat satu permintaan duplikat. Hasil model pembanding juga memasok peluang hujan sekaligus variabel lain. Cache browser hanya berlaku untuk endpoint cuaca publik yang diizinkan, memiliki masa berlaku per sumber, dibatasi jumlahnya, dan dapat dipakai sebagai cadangan saat jaringan gagal. Data cache yang sudah kedaluwarsa ditandai sebagai cadangan; bukan dilabeli sebagai kondisi real-time.

## Ketepatan prakiraan dan kondisi aktual

- Slot prakiraan lokal BMKG diprioritaskan jika wilayah ADM4 cocok dan datanya tersedia. Slot BMKG tidak diubah menjadi seolah-olah prakiraan per jam; jam di antaranya dan variabel yang tidak diterbitkan BMKG dilengkapi model Open-Meteo dengan label sumber tersendiri.
- Rata-rata model bukan pengamatan langsung. Curah hujan, peluang hujan, radar/satelit, dan prakiraan harian dapat berbeda karena cakupan waktu, resolusi, dan pembaruan sumber. Tidak ada prakiraan yang dapat dijamin tepat 100% untuk setiap titik dan jam.
- Cache dipakai untuk mempercepat tampilan dan membantu saat koneksi terputus. Setiap pemakaian cache mempunyai batas usia; status halaman menandai cache dan data lama, bukan menyebutnya real-time.
- Panel evaluasi membandingkan prakiraan tersimpan dengan laporan pengamatan pengguna pada jam dan koordinat yang sama. Skor itu evaluasi lokal berbasis laporan, bukan verifikasi stasiun BMKG atau jaminan akurasi seluruh Indonesia.

## AI tanya Fikri Weather

Tanya Fikri Weather menggunakan endpoint `netlify/functions/assistant.js` dengan aturan berbasis topik cuaca dan menu website. Asisten tidak memanggil OpenAI atau API AI berbayar. Jawabannya terbatas pada cakupan cuaca dan fitur Fikri Weather; informasi terkini hanya disebut bila tersedia pada konteks dashboard, dan pengguna diarahkan memeriksa sumber resmi untuk verifikasi.

## Navigasi dan tampilan

Halaman Ringkasan tidak menampilkan sidebar; tombol Menu membuka navigasi sementara bila dibutuhkan. Halaman lain memakai sidebar tetap yang dapat diciutkan pada desktop dan drawer pada HP. Tab Masuk dan Daftar akun dipisahkan dengan benar; hanya satu form tampil pada satu waktu. Animasi masuk menu berbeda dan ringan serta menghormati pengaturan reduced motion perangkat.


## Data PVMBG dan pembaruan gunung api

- Peta analisis lokasi memakai layanan ArcGIS REST BNPB/InaRISK. Pilih **Bahaya Banjir**, **Bahaya Tanah Longsor**, atau **Riwayat Banjir/Hidrometeorologi 2015–2024**. Untuk prakiraan gerakan tanah bulanan PVMBG, gunakan Portal MBG resmi. Lokasi/koordinat yang dipilih ditampilkan di atas peta agar dapat dicocokkan. Hasil panel peta tetap mengikuti data dan layanan resmi; browser atau server portal dapat membatasi penyematan sehingga tautan buka langsung disediakan.
- MAGMA Indonesia/PVMBG memuat informasi aktivitas gunung api dan laporan kejadian gerakan tanah/longsor. Fikri Weather memeriksa ulang daftar status setiap 15 menit ketika halaman terlihat, saat tab kembali aktif, atau ketika tombol Perbarui ditekan. Tombol rincian pada setiap profil meminta laporan aktivitas untuk gunung tersebut langsung dari tautan resmi yang diberikan daftar MAGMA. Interval pemeriksaan ini bukan janji bahwa PVMBG menerbitkan status baru setiap 15 menit.
- Untuk bencana banjir, PVMBG bukan sumber pemantauan curah hujan/tinggi muka air. Fikri Weather tetap memakai BMKG untuk peringatan cuaca dan data hujan, serta layer riwayat/banjir InaRISK untuk konteks peta. PVMBG digunakan untuk gerakan tanah/longsor dan aktivitas gunung api.
- Peta PVMBG bulanan belum otomatis menghasilkan angka kelas per titik dari frontend karena paket ini tidak menggunakan endpoint query PVMBG yang terdokumentasi. Pengguna perlu mencocokkan titik terpilih pada layer peta resmi; tampilan panel tidak mengklaim telah membaca kelas poligon bila tidak tersedia.

## Push khusus administrator

Jalankan ulang `supabase/schema.sql` setelah update agar tabel `admin_push_subscriptions` dan `admin_notifications` dibuat. Setelah deploy HTTPS dan pengaturan VAPID selesai, login admin, buka Panel Developer, dan tekan **Aktifkan notifikasi admin**. Sistem dapat mengirim push dan menyimpan riwayat saat ada akun baru, saran baru, atau pesan lanjutan pengguna. Push tidak akan aktif hanya dengan memasukkan kode admin; izin browser dan VAPID tetap dibutuhkan.


## Peta langsung BNPB/PVMBG dan portal BMKG (pembaruan antarmuka)

- Dua peta yang sebelumnya memakai iframe InaRISK kini memakai Leaflet + Esri Leaflet dan ArcGIS REST MapServer publik BNPB. Ini menghindari kotak iframe kosong akibat pembatasan frame lintas situs.
- Peta tematik MBG menampilkan layer bahaya gunung api, longsor, gempabumi, dan tsunami. Sumber layer ditandai sebagai InaRISK BNPB; tombol Portal MBG tetap membuka portal resmi Badan Geologi/PVMBG.
- Peta banjir/longsor menampilkan layer bahaya banjir, bahaya tanah longsor, dan riwayat hidrometeorologi/banjir. Peta nasional menunjukkan sebaran bahaya dasar; bukan pengukuran kondisi kejadian real-time. Layer prakiraan gerakan tanah bulanan PVMBG tetap dirujuk melalui Portal MBG resmi dan tidak dilabeli sebagai layer BNPB yang berbeda.
- Portal Radar BMKG kini diarahkan langsung ke `https://www.bmkg.go.id/cuaca/radar`. Layanan ArcGIS MapServer radar lama membutuhkan autentikasi saat diperiksa sehingga tidak dipanggil sebagai peta publik. Bila kebijakan frame BMKG/browser tidak mengizinkan iframe, tombol sumber resmi tetap tersedia; HTML tidak dapat memaksa pihak ketiga mengizinkan penyematan.
- Peta dasar memakai OpenStreetMap. Jika jaringan memblokir tile atau layanan ArcGIS, status error terlihat dan tidak diganti data tiruan.
- Tombol header Menu sekarang menampilkan ikon dan teks. Tombol Akun diganti menjadi Profil dan tetap membuka halaman Akun.

## Catatan menjalankan versi deploy

Jangan menguji kemampuan backend dengan membuka berkas dari File Manager Android (`content://...`) atau `file://`. URL fungsi `/.netlify/functions/...`, service worker, login, database, dan Web Push membutuhkan website yang sudah di-deploy melalui Netlify HTTPS. Deploy ulang folder ini dan lakukan pengujian peta serta notifikasi pada URL HTTPS. Fungsi notifikasi terjadwal berjalan di server Netlify, bukan membuat ponsel tetap menjalankan halaman; jadwal dan penerimaan push tetap tunduk pada konfigurasi VAPID, izin perangkat, koneksi, serta kebijakan baterai browser/OS.


## Pembaruan antarmuka peta dan tombol (versi terbaru)

- Tombol di header dipaksa menampilkan ikon **Menu** dan label **Profil** pada layar kecil maupun besar yang memakai mode Ringkasan. Tombol Profil membuka halaman akun.
- Kartu peta MBG dikecualikan dari accordion otomatis agar peta langsung terlihat saat halaman Bencana Geologi dibuka. Portal MBG resmi juga dicoba di dalam panel yang dapat dibuka; jika server ESDM menolak iframe, gunakan tautan resmi. Peta InaRISK di luar panel Portal MBG tetap tampil sebagai peta pendamping yang berasal dari BNPB, bukan data PVMBG bulanan.
- Layer ArcGIS memakai opsi `layers: [0]` sesuai dokumentasi Esri Leaflet; sebelumnya pemanggilan `setLayers` menggunakan bentuk argumen yang tidak sesuai dan dapat membuat layer tidak muncul.
- Bila file dibuka dari `content://` atau `file://` di HP, peringatan akan muncul. Mode file lokal tidak dapat menjalankan fungsi Netlify, autentikasi/database, service worker, atau Web Push. Deploy ZIP ke Netlify dan buka melalui HTTPS agar fitur online berfungsi.


## Perbaikan status gunung api dan pencocokan peringatan BMKG

- Parser Tingkat Aktivitas MAGMA menggunakan struktur daftar level dan tautan laporan per gunung. Status dan wilayah diambil dari halaman resmi; tautan laporan masing-masing gunung digunakan untuk mengambil pengamatan, data kegempaan, dan rekomendasi ketika pengguna membuka rinciannya.
- Profil dan tabel menampilkan daftar gunung dari feed MAGMA yang berhasil diparsing. Nama yang tidak ada pada daftar saat ini ditandai `Tidak tercantum pada daftar tingkat aktivitas terbaru`; aplikasi tidak menyimpulkan Level I dari ketiadaan entri.
- Jika permintaan pembaruan MAGMA gagal, daftar status terakhir yang berhasil dimuat tidak dikosongkan. Waktu pemeriksaan dipisahkan dari waktu penerbitan laporan.
- Peringatan BMKG dicocokkan berdasarkan poligon CAP atau nama wilayah administrasi di `areaDesc`. Tidak ada fallback ke delapan item feed teratas dari provinsi acak. Lokasi yang provinsinya tidak terverifikasi akan menampilkan status pencocokan belum tersedia, bukan pesan seolah-olah tidak ada peringatan.

### Verifikasi parser status MAGMA dan lokasi CAP BMKG (8 November 2026)

- Parser MAGMA sekarang membaca tiap tautan laporan di bawah kelompok Level IV, III, II, dan I. Pemisahan nama gunung memakai tanda pemisah terakhir agar nama berhubung tanda hubung seperti **Lewotobi Laki-laki** tidak terpotong.
- Pemeriksaan sintetik mencakup markup HTML biasa dan heading yang terbagi beberapa elemen HTML; seluruh level dan tautan laporan tetap terpetakan.
- Detail per gunung diambil saat diminta dari URL laporan resmi yang disediakan oleh MAGMA, bukan dari ringkasan atau status buatan.
- Parser CAP BMKG hanya mengeluarkan peringatan jika koordinat masuk ke poligon CAP atau nama administrasi terpilih ditemukan persis sebagai unit wilayah dalam `areaDesc`. Judul/deskripsi umum saja tidak digunakan untuk menempelkan peringatan ke lokasi.
- Jika provinsi lokasi tidak terverifikasi atau feed provinsi tidak ada, antarmuka menyatakan pencocokan belum tersedia. Data peringatan provinsi lain tidak dicampurkan.


## Build aplikasi Android (APK)

Proyek menyediakan aplikasi Android WebView native dan GitHub Actions. APK ini membuka website Fikri Weather yang sudah di-host lewat HTTPS; jadi backend Netlify, akun Supabase, data langsung, dan perbaikan website tetap berasal dari website yang sama. APK bukan salinan offline/native dari seluruh layanan. Koneksi internet dibutuhkan untuk data terbaru; halaman fallback hanya memberi informasi ketika koneksi terputus.

1. Deploy website lebih dahulu ke Netlify/custom domain dan pastikan halaman utama serta `/.netlify/functions/` berfungsi.
2. Unggah seluruh isi ZIP ini ke repository GitHub. Jangan unggah `.env`, service-role key, VAPID private key, atau kode admin.
3. Buka tab **Actions** → workflow **Build Fikri Weather APK** → **Run workflow**.
4. Masukkan alamat origin HTTPS website, misalnya `https://fikri-weather.netlify.app` (tanpa path setelah domain). Jalankan workflow.
5. Setelah selesai, buka hasil run dan unduh artifact `fikri-weather-android-debug-apk`. Di dalamnya terdapat `app-debug.apk`.

Build lokal dapat dijalankan pada komputer yang memasang Node.js 22+, JDK 17+, Gradle 8.13, Android Studio/Android SDK (API 24+): jalankan `npm run check`, lalu `FW_SITE_URL=https://domain-website-anda npm run android:build`. Di Windows PowerShell: `$env:FW_SITE_URL="https://domain-website-anda"; npm run android:build`. File akan dibuat di `android/app/build/outputs/apk/debug/app-debug.apk`. Untuk publikasi Play Store dibutuhkan signing keystore release tersendiri; workflow ini menghasilkan APK debug untuk pengujian/instalasi langsung.

Fitur lokasi pada APK meminta izin lokasi Android. Dukungan push/notifikasi latar belakang pada WebView tidak dijamin sama dengan Chrome/PWA; untuk notifikasi web yang paling konsisten, gunakan versi website melalui Chrome Android dan tambahkan ke layar utama. Jika menggunakan domain baru atau berpindah domain, buat ulang APK dengan origin yang benar.


## Perubahan versi 2.4.2 (12 November 2026)

- Dashboard memprioritaskan slot prakiraan BMKG untuk kondisi, suhu, kelembapan, dan angin. Data model digunakan untuk variabel yang tidak tersedia di BMKG serta jam-jam di antara slot 3-jam, dengan atribusi sumber terpisah.
- Model cadangan meminta variabel current, hourly, dan daily. Bila Best Match gagal, model lain yang berhasil dapat mengisi prakiraan dan kartu-kartu yang didukung. Nilai yang tetap tidak tersedia tidak dibuat-buat.
- Peta rute penerbangan menggunakan marker bernomor berwarna hijau/kuning/merah/abu-abu. A/B menandai asal/tujuan dan garis lintasan putus-putus menjelaskan arah urutan titik.
- Menu dan modul lain dipertahankan.



## Perubahan versi 2.4.6 (14 November 2026)

- Mempertahankan menu dan fitur website yang tidak termasuk permintaan perubahan. Pembaruan dibatasi pada panel potensi bencana, peta risiko/gempa, Jemuran, rekomendasi aktivitas, persiapan berkegiatan di luar, dan integrasi empat widget Android.
- Peta banjir, longsor, dan tsunami memakai raster ImageServer nasional InaRISK BNPB dan raster function produk yang sesuai; legenda menampilkan kelas resmi rendah/sedang/tinggi (0–0,333; 0,334–0,666; 0,667–1). Panel analisis koordinat membaca nilai raster per titik melalui endpoint Netlify dengan cache 10 menit.
- Kelas RENDAH/SEDANG/TINGGI mewakili kelas kerawanan dasar InaRISK. SIAGA/BAHAYA hanya berasal dari peringatan resmi BMKG yang cocok; data yang tidak terbaca tetap DATA BELUM TERSEDIA. Nilai indeks bukan peringatan dini.
- Jemuran tidak lagi menganggap data kosong sebagai waktu mendukung. Hujan kuat hanya ditandai bila peluang dan jumlah/kondisi hujan saling mendukung; kelembapan malam memicu Waspada/lambat kering jika data hujannya tersedia dan tidak menunjukkan hujan kuat. Siang hari tetap Relatif Mendukung ketika ada data dan tidak ada sinyal hujan kuat.
- Rekomendasi Jogging, Lari, Jalan Kaki, dan Bersepeda mencari jendela pagi (04.00–12.00) dan sore/malam (15.00–22.00) dari prakiraan; kartu menjelaskan kondisi hujan, suhu, angin, UV, serta pengingat keselamatan malam hari. Label perlengkapan diubah menjadi “Persiapan Berkegiatan di Luar” dan daftar menyesuaikan kondisi waktu yang dekat.
- Penanda titik gempa memakai SVG berwarna kontras dan popup; layer bencana menampilkan penanda lokasi analisis serta legenda. Cache shell PWA dinaikkan ke v11; Android versionCode 10, versi 2.4.6.
- APK belum dibangun dalam lingkungan ini karena Gradle dan Android SDK tidak terpasang. Website live tidak diubah oleh pembuatan paket source ini; perubahan website baru aktif setelah source di-deploy.

## Perubahan versi 2.4.5 (13 November 2026)

- Menambahkan empat widget layar utama Android: FIKRI WEATHER (4×2), FIKRI GEO MONITOR (4×2), FIKRI WEATHER + GEO MONITOR (4×3), dan FIKRI WEATHER NOW (4×1). Widget cuaca memakai tema biru-putih; GEO MONITOR memakai krem-oranye.
- Widget 1 dan 3 menampilkan empat kartu prakiraan horizontal per halaman dan tombol navigasi untuk menelusuri 10 jam. Setiap widget menampilkan tanggal/waktu perangkat, lokasi, sumber data, serta tombol Update, Lokasi, dan Detail.
- Menambahkan bridge lokasi GPS/manual/favorit dari WebView ke widget, snapshot bersama, cache 10 menit, invalidasi saat lokasi berubah, dan pembaruan terjadwal 30 menit dengan tombol pembaruan manual. Android/launcher dapat menunda pembaruan berkala.
- Menghapus pengaruh observasi METAR bandara dari ringkasan cuaca umum. Kondisi tabel tetap berasal dari sumber utama BMKG pada slot resminya atau model pelengkap pada jam tanpa slot BMKG; pengayaan awan/curah hujan tidak lagi menulis ulang label kondisi. METAR/TAF tetap pada menu Bandara/Penerbangan.
- Memperluas prakiraan per jam menjadi 4 hari (96 jam) dan prakiraan harian menjadi hari ini + 15 hari berikutnya. BMKG diprioritaskan pada cakupan lokal dan slot 3 jam; jam perantara, variabel yang tidak diterbitkan, serta hari setelah cakupan BMKG ditandai sebagai model pelengkap.
- Status bencana tanpa sumber tervalidasi tetap DATA BELUM TERSEDIA, tidak diubah menjadi NORMAL.
- Mengubah permukaan awal APK menjadi terang biru-putih dan menaikkan cache shell PWA ke v10.
- Pemeriksaan lokal: `npm run check` lulus; seluruh 18 file XML Android lolos parser. APK belum dibangun dalam lingkungan ini karena Gradle/Android SDK dan origin HTTPS `FW_SITE_URL` yang benar tidak tersedia.

## Perubahan versi 2.4.4 (13 November 2026)

- Memperbaiki error JavaScript `num is not defined` pada scope dashboard utama; pembaca numerik kini tersedia di modul cuaca utama sehingga proses render kartu cuaca, tabel prakiraan 4 hari, grafik, evaluasi, dan rekomendasi aktivitas tidak berhenti di tengah.
- Peta perjalanan darat kini memakai interpolasi sepanjang geometri jalan OSRM hingga 48 titik cuaca (target jarak sekitar 18 km), bukan maksimal enam titik.
- Prakiraan titik rute diambil secara batch multi-koordinat. BMKG digunakan bila titik benar-benar memiliki kode ADM4 yang tervalidasi; variabel yang tidak disediakan BMKG dilengkapi model Open-Meteo dan sumbernya dicatat per variabel.
- Setiap titik rute memiliki marker bernomor hijau/kuning/merah/abu-abu, kondisi cuaca termasuk mendung/hujan ringan/sedang/lebat/petir, peluang hujan, curah hujan, suhu, kelembapan, angin, dan ETA. Ketika seluruh sumber gagal, marker menjadi abu-abu dan tidak ada nilai yang dibuat.
- Nama ruas jalan diambil dari langkah OSRM; nama desa/kota dan alamat ringkasan diambil dari endpoint reverse-geocoding server dengan cache dan atribusi OpenStreetMap.
- Saran singgah menggunakan tempat bernama yang terpetakan di OpenStreetMap (misalnya SPBU, kafe, restoran, parkir, dan layanan jalan), disertai alamat, jarak ke jalur, dan jam buka hanya bila tercatat.
- Menu, tata letak, dan modul lain tidak dirombak. Cache shell PWA v9, Android versionCode 8, versi aplikasi 2.4.4.

## Perubahan versi 2.4.3 (12 November 2026)
- Memperbaiki cache negatif ADM4 agar kegagalan pencarian kode BMKG tidak membuat lokasi terkunci tanpa BMKG selama 24 jam.
- Mengisi nilai yang kosong pada slot BMKG dari model yang tersedia, dengan prioritas dan label sumber tetap jelas.
- Memastikan prakiraan harian dan total curah hujan menggunakan field valid dari model alternatif bila sumber utama kosong.
- Kode cuaca WMO serta arah angin tidak dirata-ratakan sebagai angka.
- Garis rute penerbangan ikut berubah warna sesuai status titik: hijau, kuning, merah, atau abu-abu; backend memilih slot Best Match lalu fallback model per titik dan per variabel.
- Versi cache shell PWA v8, Android versionCode 7, versi aplikasi 2.4.3.

- Versi 2.4.3 juga memperbaiki pemanggilan Open-Meteo Best Match di backend rute (tanpa `models=null`), menampilkan sumber per variabel pada titik rute, serta memakai slot hourly sebagai cadangan ketika field current provider kosong.
